from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from project_data import (
    ACCESS_DATE,
    CANDIDATES,
    DEEP_VEHICLES,
    ELIMINATION_RULES,
    GLOBAL_ASSUMPTIONS,
    PRICE_RECORDS,
    RESERVE_SCREEN,
    RUN_DATE,
    RUN_ID,
    SOURCE_DEFS,
)

ROOT = Path(__file__).resolve().parents[1]


def dump(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


vehicle_source_roles = {
    "VEH-TOYOTA-SIENNA-2024-PLATINUM-AWD": {
        "iihs": ["SRC-0001"], "nhtsa": ["SRC-0013", "SRC-0020"], "spec": ["SRC-0024"], "energy": ["SRC-0031"], "reliability": ["SRC-0039"], "price": ["SRC-0051", "SRC-0052", "SRC-0053"]
    },
    "VEH-KIA-TELLURIDE-2024-SX-PRESTIGE-XPRO-AWD": {
        "iihs": ["SRC-0002"], "nhtsa": ["SRC-0014", "SRC-0021"], "spec": ["SRC-0026"], "energy": ["SRC-0032"], "reliability": ["SRC-0040", "SRC-0045"], "price": ["SRC-0054", "SRC-0055", "SRC-0056"]
    },
    "VEH-HONDA-PILOT-2024-ELITE-AWD": {
        "iihs": ["SRC-0003"], "nhtsa": ["SRC-0015"], "spec": ["SRC-0025", "SRC-0036"], "energy": ["SRC-0033"], "reliability": ["SRC-0041", "SRC-0049"], "price": ["SRC-0057", "SRC-0058", "SRC-0059"]
    },
    "VEH-FORD-EXPLORER-2024-PLATINUM-4WD": {
        "iihs": ["SRC-0004"], "nhtsa": ["SRC-0016"], "spec": ["SRC-0027", "SRC-0037"], "energy": ["SRC-0034"], "reliability": ["SRC-0042", "SRC-0050"], "price": ["SRC-0060", "SRC-0061", "SRC-0062"]
    },
    "VEH-NISSAN-PATHFINDER-2024-PLATINUM-4WD-POSTNOV23": {
        "iihs": ["SRC-0005"], "nhtsa": ["SRC-0017", "SRC-0022"], "spec": ["SRC-0028"], "energy": ["SRC-0035"], "reliability": ["SRC-0043", "SRC-0046"], "price": ["SRC-0063", "SRC-0064", "SRC-0065"]
    },
    "VEH-KIA-EV9-2024-LAND-AWD-POSTJAN24": {
        "iihs": ["SRC-0006"], "nhtsa": ["SRC-0018", "SRC-0023"], "spec": ["SRC-0029", "SRC-0038"], "energy": ["SRC-0030"], "reliability": ["SRC-0044", "SRC-0047", "SRC-0048"], "price": ["SRC-0066", "SRC-0067", "SRC-0068"]
    },
}


def build_sources() -> list[dict[str, Any]]:
    sources = []
    for source_id, title, publisher, url, source_type, tier, applicability, vehicles in SOURCE_DEFS:
        notes = []
        if tier == 4:
            notes.append("Used only for direct listing evidence, authorized-dealer specifications, or market observations; not used alone to establish a hard safety requirement.")
        if source_type == "secondary_data_mirror":
            notes.append("Public mirror used to corroborate an exact NHTSA result when the dynamic NHTSA page did not render consistently.")
        if source_type in {"derived_nhtsa_dataset", "derived_nhtsa_owner_dataset"}:
            notes.append("Derived from public complaint/recall data; complaint counts are not failure rates and are interpreted only as pattern signals.")
        if "listing" in source_type:
            notes.append("Listing status and price are time-sensitive; recheck within 14 days of a purchase decision.")
        sources.append({
            "source_id": source_id,
            "title": title,
            "publisher_or_organization": publisher,
            "url": url,
            "source_type": source_type,
            "authority_tier": tier,
            "publication_or_update_date": None,
            "access_date": ACCESS_DATE,
            "model_year_and_trim_applicability": applicability,
            "vehicle_or_topic_applicability": vehicles,
            "claims_supported": [],
            "notes_on_limitations": " ".join(notes) if notes else "No material limitation beyond exact applicability and access-date staleness.",
        })
    return sources


class ClaimBuilder:
    def __init__(self) -> None:
        self.claims: list[dict[str, Any]] = []
        self.index: dict[tuple[str | None, str], str] = {}
        self.counter = 1

    def add(
        self,
        vehicle_id: str | None,
        field: str,
        normalized_value: Any,
        display_value: str,
        unit: str | None,
        applicability: str,
        status: str,
        confidence: str,
        source_ids: list[str],
        evidence_summary: str,
        affects: list[str],
    ) -> str:
        key = (vehicle_id, field)
        if key in self.index:
            raise ValueError(f"Duplicate claim key: {key}")
        claim_id = f"CLM-{self.counter:04d}"
        self.counter += 1
        claim = {
            "claim_id": claim_id,
            "vehicle_id": vehicle_id,
            "field_or_topic": field,
            "normalized_value": normalized_value,
            "display_value": display_value,
            "unit": unit,
            "exact_applicability": applicability,
            "status": status,
            "confidence": confidence,
            "source_ids": source_ids,
            "short_evidence_summary": evidence_summary,
            "retrieval_date": ACCESS_DATE,
            "affects": affects,
        }
        self.claims.append(claim)
        self.index[key] = claim_id
        return claim_id



def source_for(vehicle_id: str, role: str) -> list[str]:
    return vehicle_source_roles[vehicle_id][role]


def add_deep_claims(cb: ClaimBuilder) -> None:
    for vehicle_id, v in DEEP_VEHICLES.items():
        app = v["short_name"]
        # Eligibility claims.
        eligibility_field_sources = {
            "third_row": source_for(vehicle_id, "spec"),
            "nhtsa_overall": source_for(vehicle_id, "nhtsa"),
            "iihs_award": source_for(vehicle_id, "iihs"),
            "row2_complete_latch": source_for(vehicle_id, "iihs"),
            "row3_complete_latch": source_for(vehicle_id, "iihs"),
            "cargo_behind_row3": source_for(vehicle_id, "spec"),
            "awd_or_4wd": source_for(vehicle_id, "spec"),
            "price_ceiling": source_for(vehicle_id, "price"),
            "model_year": source_for(vehicle_id, "spec"),
            "reliability_exclusion": source_for(vehicle_id, "reliability"),
        }
        for key, raw in v["eligibility"].items():
            if key == "overall":
                continue
            status, value, summary = raw
            field = {
                "third_row": "eligibility.third_row_present",
                "nhtsa_overall": "eligibility.nhtsa_overall_stars",
                "iihs_award": "eligibility.iihs_award",
                "row2_complete_latch": "eligibility.row2_complete_latch_positions",
                "row3_complete_latch": "eligibility.row3_complete_latch_positions",
                "cargo_behind_row3": "eligibility.cargo_behind_third_row_cuft",
                "awd_or_4wd": "eligibility.drivetrain",
                "price_ceiling": "eligibility.vehicle_price_before_tax_fees",
                "model_year": "eligibility.model_year",
                "reliability_exclusion": "eligibility.reliability_exclusion_status",
            }[key]
            unit = {"nhtsa_overall": "stars", "row2_complete_latch": "positions", "row3_complete_latch": "positions", "cargo_behind_row3": "cu_ft", "price_ceiling": "USD", "model_year": "year"}.get(key)
            confidence = "high"
            if status == "conditional_pass" or key in {"price_ceiling", "reliability_exclusion"}:
                confidence = "medium"
            cb.add(vehicle_id, field, value, str(value), unit, app, "conditional" if status == "conditional_pass" else "verified", confidence, eligibility_field_sources[key], summary, ["eligibility"])

        # Safety scoring inputs.
        safety = v["safety"]
        safety_fields = [
            ("scoring.safety.iihs_award", safety["award"], safety["award"], None),
            ("scoring.safety.iihs_test_quality", safety["test_quality"], safety["test_quality"].replace("_", " "), None),
            ("scoring.safety.pedestrian_aeb_strong_result", safety["pedestrian_strong"], "yes" if safety["pedestrian_strong"] else "no", None),
            ("scoring.safety.vehicle_to_vehicle_aeb", safety["v2v_aeb"], "standard" if safety["v2v_aeb"] else "not verified", None),
            ("scoring.safety.blind_spot_monitoring_standard", safety["bsm"], "standard" if safety["bsm"] else "not standard", None),
            ("scoring.safety.rear_cross_traffic_alert_standard", safety["rcta"], "standard" if safety["rcta"] else "not standard", None),
            ("scoring.safety.rear_occupant_alert", safety["rear_occupant"], "yes" if safety["rear_occupant"] else "no", None),
            ("scoring.safety.safe_exit_warning", safety["safe_exit"], "yes" if safety["safe_exit"] else "no", None),
            ("scoring.safety.driver_attention_monitoring", safety["driver_attention"], "yes" if safety["driver_attention"] else "no", None),
            ("scoring.safety.surround_view_camera", safety["surround_view"], "available on scored trim" if safety["surround_view"] else "not available", None),
            ("scoring.safety.latch_quality", safety["latch_quality"], safety["latch_quality"].replace("_", " "), None),
        ]
        for field, value, display, unit in safety_fields:
            role = "iihs" if any(token in field for token in ["iihs", "pedestrian", "latch_quality"]) else "spec"
            cb.add(vehicle_id, field, value, display, unit, app, "verified", "high" if role == "iihs" else "medium", source_for(vehicle_id, role), "Exact-year rating or exact-trim equipment used by the frozen scoring rule.", ["scoring", "narrative"])

        # Reliability scoring inputs.
        reliability = v["reliability"]
        reliability_fields = [
            ("scoring.reliability.predicted_or_measured", reliability["predicted"]),
            ("scoring.reliability.platform_maturity", reliability["maturity"]),
            ("scoring.reliability.recall_history", reliability["recalls"]),
            ("scoring.reliability.owner_problem_pattern", reliability["owner_pattern"]),
        ]
        for field, value in reliability_fields:
            cb.add(vehicle_id, field, value, value.replace("_", " "), None, app, "verified", "medium", source_for(vehicle_id, "reliability"), reliability["summary"], ["scoring", "tco", "narrative"])

        # Passenger space.
        space = v["space"]
        for field, value, unit in [
            ("scoring.passenger_space.third_row_legroom", space["third_row_legroom"], "inches"),
            ("scoring.passenger_space.third_row_real_world_usability", space["third_row_usability"], None),
            ("scoring.passenger_space.sliding_second_row", space["sliding_second_row"], None),
            ("scoring.passenger_space.multiple_family_usable_configurations", space["multiple_configurations"], None),
            ("scoring.passenger_space.entry_and_exit", space["entry_exit"], None),
        ]:
            cb.add(vehicle_id, field, value, str(value).replace("_", " "), unit, app, "verified", "medium", source_for(vehicle_id, "spec"), "Exact-year dimensions/equipment plus standardized qualitative family-utility classification.", ["scoring", "narrative"])

        # Cargo.
        cargo = v["cargo"]
        for field, value, unit in [
            ("scoring.cargo.volume_behind_third_row", cargo["volume"], "cu_ft"),
            ("scoring.cargo.flat_or_low_load_floor", cargo["low_floor"], None),
            ("scoring.cargo.useful_underfloor_storage", cargo["underfloor"], None),
            ("scoring.cargo.power_third_row_available", cargo["power_third_row"], None),
            ("scoring.cargo.independent_testing_good_shape", cargo["good_shape"], None),
        ]:
            sources = source_for(vehicle_id, "spec")
            cb.add(vehicle_id, field, value, str(value), unit, app, "verified", "high" if "volume" in field else "medium", sources, "Cargo figure is exact-year; usability subcomponents are standardized feature/shape classifications.", ["eligibility" if "volume" in field else "scoring", "scoring", "narrative"])

        # Energy inputs.
        energy = v["energy"]
        for field, value, unit in [
            ("scoring.energy.city_mpg", energy["city_mpg"], "mpg"),
            ("scoring.energy.highway_mpg", energy["highway_mpg"], "mpg"),
            ("scoring.energy.kwh_per_100mi", energy["kwh_per_100mi"], "kWh/100mi"),
        ]:
            if value is None:
                continue
            cb.add(vehicle_id, field, value, str(value), unit, app, "verified", "high", source_for(vehicle_id, "energy"), "EPA baseline used with the frozen city/highway and charging assumptions.", ["scoring", "tco"])

        # Comfort and technology.
        comfort = v["comfort"]
        for field, value in [
            ("scoring.comfort.row2_dedicated_vents", comfort["row2_vents"]),
            ("scoring.comfort.row3_dedicated_vents", comfort["row3_vents"]),
            ("scoring.comfort.ceiling_or_equivalent_rear_vents", comfort["ceiling_vents"]),
            ("scoring.comfort.ride_quality", comfort["ride"]),
            ("scoring.comfort.cabin_noise", comfort["noise"]),
            ("scoring.comfort.seat_comfort", comfort["seats"]),
        ]:
            cb.add(vehicle_id, field, value, str(value).replace("_", " "), None, app, "verified", "medium", source_for(vehicle_id, "spec"), "Standardized classification from exact-year equipment and convergent professional-review evidence.", ["scoring", "narrative"])
        tech = v["technology"]
        for key, value in tech.items():
            cb.add(vehicle_id, f"scoring.technology.{key}", value, "yes" if value else "no", None, app, "verified", "medium", source_for(vehicle_id, "spec"), "Exact-trim technology feature status.", ["scoring", "narrative"])

        # Price and TCO claims.
        price = v["price"]
        cb.add(vehicle_id, "market_price.low", price["low"], f"${price['low']:,.0f}", "USD", app, "verified", price["confidence"].replace("_", "-"), source_for(vehicle_id, "price"), "Low planning bound from comparable direct listings.", ["tco", "narrative"])
        cb.add(vehicle_id, "market_price.base", price["base"], f"${price['base']:,.0f}", "USD", app, "verified", price["confidence"].replace("_", "-"), source_for(vehicle_id, "price"), "Normalized market acquisition price used for official purchase-price score and base TCO.", ["eligibility", "scoring", "tco"])
        cb.add(vehicle_id, "market_price.high", price["high"], f"${price['high']:,.0f}", "USD", app, "verified", price["confidence"].replace("_", "-"), source_for(vehicle_id, "price"), "High planning bound from comparable direct listings.", ["tco", "narrative"])
        for key, value in v["tco_inputs"].items():
            unit = "USD" if not key.startswith("residual") else "fraction_of_purchase_price"
            confidence = "low" if key.startswith(("repairs", "residual")) else "medium"
            cb.add(vehicle_id, f"tco.{key}", value, f"{value:.2f}" if isinstance(value, float) else str(value), unit, app, "verified", confidence, source_for(vehicle_id, "reliability") + source_for(vehicle_id, "price"), "Planning input modeled consistently across candidates; uncertainty is carried into low/high scenarios and simulation.", ["tco", "sensitivity"])


def add_global_claims(cb: ClaimBuilder) -> None:
    globals_to_add = [
        ("tco.sales_tax_rate", GLOBAL_ASSUMPTIONS["sales_tax_rate"], "9.1%", "fraction", ["SRC-0069"], "Maple Valley Q3 2026 local sales/use-tax rate."),
        ("tco.gas_price_per_gallon", GLOBAL_ASSUMPTIONS["gas_price_per_gallon"], "$5.121", "USD/gallon", ["SRC-0070"], "Washington weekly regular gasoline price used as current planning baseline."),
        ("tco.home_electricity_per_kwh", GLOBAL_ASSUMPTIONS["home_electricity_per_kwh"], "$0.141598", "USD/kWh", ["SRC-0072"], "PSE Schedule 7 first-block incremental energy charge effective January 29, 2026."),
        ("tco.public_dcfc_per_kwh", GLOBAL_ASSUMPTIONS["public_dcfc_per_kwh"], "$0.572", "USD/kWh", ["SRC-0073"], "Regional planning assumption for public DC fast charging; actual station pricing varies."),
        ("tco.annual_miles", GLOBAL_ASSUMPTIONS["annual_miles"], "8,000", "miles/year", [], "User-supplied point estimate."),
        ("tco.city_share", GLOBAL_ASSUMPTIONS["city_share"], "70%", "fraction", [], "User-supplied driving mix."),
        ("tco.highway_share", GLOBAL_ASSUMPTIONS["highway_share"], "30%", "fraction", [], "User-supplied driving mix."),
        ("tco.ev_home_share", GLOBAL_ASSUMPTIONS["ev_home_share"], "90%", "fraction", [], "User-supplied charging mix."),
        ("tco.ev_public_share", GLOBAL_ASSUMPTIONS["ev_public_share"], "10%", "fraction", [], "User-supplied charging mix."),
        ("tco.ev_charging_efficiency", GLOBAL_ASSUMPTIONS["ev_wall_to_wheels_efficiency"], "90%", "fraction", ["SRC-0030", "SRC-0072"], "Transparent planning default for charging losses; sensitivity carries uncertainty."),
    ]
    for field, value, display, unit, sources, summary in globals_to_add:
        cb.add(None, field, value, display, unit, "All candidates / ZIP 98038", "verified" if sources else "human_input", "high" if sources else "high", sources, summary, ["tco", "scoring", "sensitivity"])


def build_eligibility(cb: ClaimBuilder) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    records: list[dict[str, Any]] = []
    eliminations: list[dict[str, Any]] = []
    required_keys = [
        "third_row", "nhtsa_overall", "iihs_award", "row2_complete_latch", "row3_complete_latch",
        "cargo_behind_row3", "awd_or_4wd", "price_ceiling", "model_year", "reliability_exclusion"
    ]
    for candidate in CANDIDATES:
        vehicle_id = candidate["vehicle_id"]
        checks = []
        if vehicle_id in DEEP_VEHICLES:
            v = DEEP_VEHICLES[vehicle_id]
            for key in required_keys:
                status, value, summary = v["eligibility"][key]
                claim_field = {
                    "third_row": "eligibility.third_row_present",
                    "nhtsa_overall": "eligibility.nhtsa_overall_stars",
                    "iihs_award": "eligibility.iihs_award",
                    "row2_complete_latch": "eligibility.row2_complete_latch_positions",
                    "row3_complete_latch": "eligibility.row3_complete_latch_positions",
                    "cargo_behind_row3": "eligibility.cargo_behind_third_row_cuft",
                    "awd_or_4wd": "eligibility.drivetrain",
                    "price_ceiling": "eligibility.vehicle_price_before_tax_fees",
                    "model_year": "eligibility.model_year",
                    "reliability_exclusion": "eligibility.reliability_exclusion_status",
                }[key]
                checks.append({"requirement": key, "status": status, "value": value, "claim_id": cb.index[(vehicle_id, claim_field)], "note": summary})
            overall = v["eligibility"]["overall"]
            eligible_to_score = overall in {"pass", "conditional_pass"}
            condition = v["configuration_condition"] if overall == "conditional_pass" else None
        elif vehicle_id in ELIMINATION_RULES:
            fail_key, _, reason, source_ids = ELIMINATION_RULES[vehicle_id]
            fail_claim_id = cb.add(vehicle_id, f"eligibility.screen_failure.{fail_key}", "fail", "fail", None,
                                     f"2024 {candidate['make']} {candidate['model']} {candidate['trim']} {candidate['drivetrain']}", "verified", "high", source_ids, reason, ["eligibility"])
            for key in required_keys:
                if key == fail_key:
                    checks.append({"requirement": key, "status": "fail", "value": None, "claim_id": fail_claim_id, "note": reason})
                else:
                    checks.append({"requirement": key, "status": "not_researched_after_failure", "value": None, "claim_id": None, "note": "Expensive research stopped after definitive failure, per operating rule 13."})
            overall = "fail"
            eligible_to_score = False
            condition = None
            eliminations.append({
                "vehicle_id": vehicle_id,
                "elimination_step": "low_cost_eligibility_screen",
                "failed_requirement": fail_key,
                "claim_id": fail_claim_id,
                "reason": reason,
                "source_ids": source_ids,
                "research_stopped": True,
                "date": RUN_DATE,
            })
        else:
            reserve = RESERVE_SCREEN[vehicle_id]
            source_ids = reserve["source_ids"]
            # Formal record: verified high-value gates, explicit unresolved fields where deep verification stopped.
            defaults = {
                "third_row": ("pass", True, "Three-row configuration verified in preliminary screen."),
                "nhtsa_overall": ("pass", 5, "Preliminary exact-year NHTSA screen passed."),
                "iihs_award": ("pass", "qualifying", "Exact-year qualifying award verified."),
                "row2_complete_latch": ("pass", ">=1", "Preliminary child-anchor screen passed."),
                "row3_complete_latch": ("pass", ">=1", "Preliminary child-anchor screen passed."),
                "cargo_behind_row3": ("pass", ">=16", "Preliminary cargo screen passed."),
                "awd_or_4wd": ("pass", candidate["drivetrain"], "Exact AWD/4WD configuration exists."),
                "price_ceiling": ("conditional_pass", None, "Expected below ceiling; direct exact-trim market set not completed because candidate remained reserve."),
                "model_year": ("pass", 2024, "Inside scope."),
                "reliability_exclusion": ("unresolved", None, "Full multi-channel reliability review not completed for reserve candidate."),
            }
            for key in required_keys:
                status, value, note = defaults[key]
                claim_id = cb.add(vehicle_id, f"eligibility.reserve.{key}", value, str(value), None,
                                  f"2024 {candidate['make']} {candidate['model']} {candidate['trim']} {candidate['drivetrain']}",
                                  "conditional" if status != "pass" else "verified", "medium", source_ids, note, ["eligibility"])
                checks.append({"requirement": key, "status": status, "value": value, "claim_id": claim_id, "note": note})
            overall = reserve["overall"]
            eligible_to_score = False
            condition = reserve["note"]
        records.append({
            "vehicle_id": vehicle_id,
            "vehicle": f"{candidate['model_year']} {candidate['make']} {candidate['model']} {candidate['trim']} {candidate['drivetrain']}",
            "funnel_status": candidate["screen_outcome"],
            "overall_status": overall,
            "eligible_to_score": eligible_to_score,
            "conditions": condition,
            "requirements": checks,
        })
    return records, eliminations


def build_query_log() -> list[dict[str, Any]]:
    entries = []
    counter = 1
    def add(query: str, purpose: str, vehicle: str, sources: list[str], useful: str, ambiguity: str | None = None) -> None:
        nonlocal counter
        entries.append({
            "query_id": f"QRY-{counter:04d}", "exact_query": query, "purpose": purpose, "vehicle_or_topic": vehicle,
            "date": RUN_DATE, "sources_reviewed": sources, "useful_result": useful, "no_result_or_ambiguity_note": ambiguity
        })
        counter += 1
    for vehicle_id, v in DEEP_VEHICLES.items():
        name = v["short_name"]
        roles = vehicle_source_roles[vehicle_id]
        add(f"site:iihs.org/ratings/vehicle {v['year']} {v['make']} {v['model']} IIHS", "Verify exact-year award, crash tests and LATCH map", name, roles["iihs"], "Exact IIHS award/restrictions and child-anchor ratings captured.")
        add(f"site:nhtsa.gov/vehicle/{v['year']} {v['make']} {v['model']} {v['drivetrain']} overall safety rating", "Verify exact drivetrain NHTSA overall score", name, roles["nhtsa"], "Exact variant result captured or corroborated with public ratings-data mirror.", "Some NHTSA dynamic pages rendered an error; mirror retained as corroboration, not a replacement for the official URL.")
        add(f"{v['year']} {v['make']} {v['model']} {v['trim']} cargo third row legroom official specifications", "Verify passenger/cargo/equipment inputs", name, roles["spec"], "Exact-year dimensions and scored-trim equipment collected.")
        add(f"site:fueleconomy.gov {v['year']} {v['make']} {v['model']} {v['drivetrain']}", "Verify EPA energy baseline", name, roles["energy"], "EPA mileage or energy-consumption baseline captured.")
        add(f"{v['year']} {v['make']} {v['model']} recalls complaints reliability recurring problems", "Classify reliability and owner patterns without brand stereotypes", name, roles["reliability"], "Recall/complaint channels and recurring-pattern synthesis reviewed.")
        add(f"used {v['year']} {v['make']} {v['model']} {v['trim']} {v['drivetrain']} site:carmax.com OR site:carvana.com OR certified", "Build exact-trim used-market comparable set", name, roles["price"], "Direct listing URLs and low/base/high market range captured.", "Several exact listings sold or redirected during the run; status is explicit and confidence reduced.")
    for candidate in CANDIDATES:
        if candidate["vehicle_id"] in DEEP_VEHICLES:
            continue
        source_ids = []
        if candidate["vehicle_id"] in ELIMINATION_RULES:
            source_ids = ELIMINATION_RULES[candidate["vehicle_id"]][3]
        elif candidate["vehicle_id"] in RESERVE_SCREEN:
            source_ids = RESERVE_SCREEN[candidate["vehicle_id"]]["source_ids"]
        add(f"{candidate['model_year']} {candidate['make']} {candidate['model']} {candidate['trim']} IIHS NHTSA LATCH cargo AWD", "Low-cost hard-filter screen", candidate["vehicle_id"], source_ids, candidate["screen_note"])
    add("Maple Valley WA 98038 sales tax rate Q3 2026", "Location-specific TCO tax input", "TCO", ["SRC-0069"], "9.1% planning rate captured.")
    add("Washington regular gasoline price August 17 2026 EIA", "Regional energy-cost baseline", "TCO", ["SRC-0070"], "$5.121 per gallon captured.")
    add("PSE residential schedule 7 electricity rate January 2026", "Home charging baseline", "TCO", ["SRC-0072"], "$0.141598/kWh first-block incremental energy charge captured.")
    add("Washington RTA motor vehicle excise tax rate depreciation schedule", "Registration modeling", "TCO", ["SRC-0071"], "1.1% rate framework reviewed; exact-address applicability remains unresolved.")
    return entries


def main() -> None:
    sources = build_sources()
    cb = ClaimBuilder()
    add_deep_claims(cb)
    add_global_claims(cb)
    eligibility, eliminations = build_eligibility(cb)

    # Backfill source-to-claim reverse links.
    claims_by_source: dict[str, list[str]] = defaultdict(list)
    for claim in cb.claims:
        for source_id in claim["source_ids"]:
            claims_by_source[source_id].append(claim["claim_id"])
    for source in sources:
        source["claims_supported"] = claims_by_source.get(source["source_id"], [])

    dump(ROOT / "evidence/sources.json", {"schema_version": "1.0", "generated_at": datetime.now(timezone.utc).isoformat(), "sources": sources})
    dump(ROOT / "evidence/claims.json", {"schema_version": "1.0", "generated_at": datetime.now(timezone.utc).isoformat(), "claims": cb.claims})
    dump(ROOT / "evidence/price-records.json", {"schema_version": "1.0", "staleness_policy_days": {"recheck": 14, "stale": 30}, "price_records": PRICE_RECORDS})
    dump(ROOT / "research/candidate-universe.json", {"run_id": RUN_ID, "mode": "portfolio", "candidate_target": 25, "candidate_count": len(CANDIDATES), "candidates": CANDIDATES})
    dump(ROOT / "research/query-log.json", {"run_id": RUN_ID, "queries": build_query_log()})
    dump(ROOT / "analysis/eligibility.json", {"run_id": RUN_ID, "requirements_version": "1.0-frozen-2026-08-24", "vehicles": eligibility})
    dump(ROOT / "decisions/eliminations.json", {"run_id": RUN_ID, "eliminations": eliminations})

    contradictions = [
        {
            "contradiction_id": "CON-0001", "vehicle_and_topic": "Project model-year scope",
            "source_a_and_value": "Project context and research-config: 2022-2025",
            "source_b_and_value": "Scoring eligibility: 2023-2027",
            "likely_reason": "The scoring configuration was created for a broader later-year program.",
            "resolution_rule": "Use conservative intersection of authoritative inputs.",
            "selected_value": [2023, 2024, 2025], "confidence": "high",
            "impact": "2022 vehicles excluded before discovery."
        },
        {
            "contradiction_id": "CON-0002", "vehicle_and_topic": "Purchase-price score basis",
            "source_a_and_value": "Component text defines new MSRP plus destination.",
            "source_b_and_value": "Used-vehicle behavior explicitly requires normalized current used acquisition price.",
            "likely_reason": "Base scoring model includes new vehicles while this run is used-only.",
            "resolution_rule": "Apply the more specific used-only project rule and record the judgment.",
            "selected_value": "Normalized current used acquisition price", "confidence": "high",
            "impact": "All official price scores reference PRC records rather than original MSRP."
        },
        {
            "contradiction_id": "CON-0003", "vehicle_and_topic": "NHTSA dynamic page rendering",
            "source_a_and_value": "Official exact-variant URLs intermittently return a front-end error.",
            "source_b_and_value": "Public mirror of the NHTSA ratings dataset returns exact AWD 5-star records.",
            "likely_reason": "Website rendering/API presentation issue rather than a substantive rating conflict.",
            "resolution_rule": "Retain official URL, corroborate with mirror, and lower confidence one level where needed.",
            "selected_value": "Exact AWD 5-star result where both identifiers align", "confidence": "medium",
            "impact": "Sienna, Telluride, Pathfinder and EV9 NHTSA claims remain usable with documented limitation."
        },
        {
            "contradiction_id": "CON-0004", "vehicle_and_topic": "Live-listing status",
            "source_a_and_value": "Search index or prior retrieval showed available listing.",
            "source_b_and_value": "Direct page later redirected, sold or became reserved.",
            "likely_reason": "Normal used-inventory turnover.",
            "resolution_rule": "Preserve observed price, mark status at recheck, reduce confidence, never imply current availability.",
            "selected_value": "Price retained as time-stamped comparable; availability not assumed", "confidence": "high",
            "impact": "All prices are planning estimates and must be refreshed within 14 days of purchase."
        },
    ]
    dump(ROOT / "evidence/contradictions.json", {"run_id": RUN_ID, "contradictions": contradictions})
    dump(ROOT / "evidence/corrections.json", {"run_id": RUN_ID, "status": "none_before_human_comparison", "corrections": []})

    # Expand judgments and decision ledger without consulting manual research.
    judgments_path = ROOT / "analysis/judgments.json"
    judgments = json.loads(judgments_path.read_text(encoding="utf-8")) if judgments_path.exists() else {"judgments": []}
    existing_ids = {j["judgment_id"] for j in judgments.get("judgments", [])}
    additions = [
        {"judgment_id": "JDG-0003", "topic": "primary_model_year", "decision": "Use 2024 exact configurations for the deep set", "reason": "Best intersection of mature used supply and complete exact-year safety evidence", "impact": "Avoids cross-year transfer", "date": RUN_DATE},
        {"judgment_id": "JDG-0004", "topic": "nhtsa_page_errors", "decision": "Corroborate exact records with a public NHTSA-data mirror and reduce confidence", "reason": "Official dynamic pages intermittently failed to render", "impact": "No unrated assumption from a website error", "date": RUN_DATE},
        {"judgment_id": "JDG-0005", "topic": "qualitative_scoring", "decision": "Use standardized classifications only where scoring-config explicitly permits qualitative classes", "reason": "Preserves deterministic arithmetic while allowing review synthesis", "impact": "Ride, seat, noise, usability and reliability classes remain auditable", "date": RUN_DATE},
        {"judgment_id": "JDG-0006", "topic": "insurance", "decision": "Omit insurance from numeric TCO", "reason": "No comparable household quotes supplied", "impact": "Insurance appears as a reversal condition rather than fabricated dollars", "date": RUN_DATE},
        {"judgment_id": "JDG-0007", "topic": "rta_tax", "decision": "Model registration/RTA as planning allowances, not an exact address calculation", "reason": "ZIP 98038 does not prove exact RTA boundary/address and DOL depreciated-value calculation", "impact": "Registration uncertainty is carried in TCO scenario ranges", "date": RUN_DATE},
        {"judgment_id": "JDG-0008", "topic": "ev9_reliability_gate", "decision": "Do not exclude categorically; impose strict VIN, campaign, charging and battery-health conditions and score reliability at 1/10", "reason": "Strong recurring pattern is material, but documented remedies, warranty and incomplete failure-rate denominators do not prove long-term ownership unreasonable for every corrected VIN", "impact": "EV9 remains conditional and is red-teamed more heavily than alternatives", "date": RUN_DATE},
        {"judgment_id": "JDG-0009", "topic": "build_date_scoping", "decision": "Define Pathfinder and EV9 vehicle IDs as post-restriction exact configurations", "reason": "IIHS awards have build-date restrictions that are binary conditions", "impact": "Scoring is valid only after certification-label verification", "date": RUN_DATE},
        {"judgment_id": "JDG-0010", "topic": "market_price_normalization", "decision": "Use low/base/high exact-trim sets with explicit mileage/CPO adjustments; no opaque regression", "reason": "Small direct-listing samples are more auditable than an unsourced average", "impact": "Price confidence is medium or medium-low", "date": RUN_DATE},
    ]
    judgments["judgments"].extend([j for j in additions if j["judgment_id"] not in existing_ids])
    dump(judgments_path, judgments)

    ledger = {
        "run_id": RUN_ID,
        "decisions": [
            {"decision_id": "DEC-0001", "step": "input_freeze", "decision": "Freeze model years to 2023-2025", "input_claim_ids_or_score_ids": [], "concise_rationale": "Conservative intersection resolves the 2022 conflict without weakening the scoring gate.", "reversible": True, "reversal_conditions": "Supply a revised authoritative scoring configuration that explicitly admits 2022.", "date": RUN_DATE},
            {"decision_id": "DEC-0002", "step": "analysis_mode", "decision": "Use portfolio mode", "input_claim_ids_or_score_ids": [], "concise_rationale": "No authoritative candidate list was supplied; the payload defines a broad discovery target.", "reversible": False, "reversal_conditions": None, "date": RUN_DATE},
            {"decision_id": "DEC-0003", "step": "candidate_discovery", "decision": "Create a 25-vehicle universe spanning gas, hybrid, PHEV, EV, mainstream and near-luxury options", "input_claim_ids_or_score_ids": [], "concise_rationale": "Preserves breadth before hard-filter elimination.", "reversible": True, "reversal_conditions": "Change candidate target or body-style scope.", "date": RUN_DATE},
            {"decision_id": "DEC-0004", "step": "deep_research_selection", "decision": "Deep-research Sienna, Telluride, Pilot, Explorer, Pathfinder and EV9", "input_claim_ids_or_score_ids": [], "concise_rationale": "All are plausible under the gate and collectively test minivan, gas-SUV, value, safety and EV hypotheses.", "reversible": True, "reversal_conditions": "A deep candidate fails or a reserve produces stronger verified eligibility evidence.", "date": RUN_DATE},
            {"decision_id": "DEC-0005", "step": "atlas_elimination", "decision": "Eliminate 2024 Volkswagen Atlas", "input_claim_ids_or_score_ids": [next(e["claim_id"] for e in eliminations if e["vehicle_id"].startswith("VEH-VOLKSWAGEN"))], "concise_rationale": "No complete row-3 LATCH position under the configured definition.", "reversible": True, "reversal_conditions": "Authoritative exact-year anchor map shows lower anchors and tether at one row-3 seating position.", "date": RUN_DATE},
            {"decision_id": "DEC-0006", "step": "pricing_method", "decision": "Use current normalized used acquisition price for official price scoring", "input_claim_ids_or_score_ids": [], "concise_rationale": "Used-only override is more specific than the base new-MSRP language.", "reversible": True, "reversal_conditions": "Scoring configuration is revised to explicitly mandate original MSRP for used vehicles.", "date": RUN_DATE},
            {"decision_id": "DEC-0007", "step": "human_research_embargo", "decision": "Keep MANUAL_RESEARCH.md unopened until recommendation lock", "input_claim_ids_or_score_ids": [], "concise_rationale": "Prevents anchoring and preserves an independent comparison artifact.", "reversible": False, "reversal_conditions": None, "date": RUN_DATE},
        ]
    }
    dump(ROOT / "decisions/decision-ledger.json", ledger)

    # Internal mapping enables deterministic score generation without brittle text searches.
    dump(ROOT / "analysis/claim-map.json", {"mapping": {f"{k[0] or 'GLOBAL'}::{k[1]}": v for k, v in cb.index.items()}})

    # Config validation corrected: monotonic cargo anchors are intentionally increasing.
    scoring = json.loads((ROOT / "config/scoring-config.json").read_text(encoding="utf-8"))
    category_total = sum(cat["max_points"] for cat in scoring["scoring"].values())
    component_checks = {
        "safety": 7 + 6 + 5 + 4 + 3,
        "reliability": 4 + 2 + 2 + 2,
        "passenger_space": 4 + 3 + 2 + 1,
        "cargo_practicality": 8 + 2,
        "comfort": 1.5 + 1.5 + 1 + 1,
        "technology": 1 + 1 + 1 + 0.5 + 0.5 + 0.5 + 0.5,
    }
    anchor_checks = {
        "purchase_price_prices_ascending": [a["price"] for a in scoring["scoring"]["purchase_price"]["anchors"]] == sorted(a["price"] for a in scoring["scoring"]["purchase_price"]["anchors"]),
        "purchase_price_scores_nonincreasing": [a["score"] for a in scoring["scoring"]["purchase_price"]["anchors"]] == sorted((a["score"] for a in scoring["scoring"]["purchase_price"]["anchors"]), reverse=True),
        "cargo_values_ascending": [a["cargo"] for a in scoring["scoring"]["cargo_practicality"]["components"]["cargo_behind_third_row"]["anchors"]] == sorted(a["cargo"] for a in scoring["scoring"]["cargo_practicality"]["components"]["cargo_behind_third_row"]["anchors"]),
        "cargo_points_nondecreasing": [a["points"] for a in scoring["scoring"]["cargo_practicality"]["components"]["cargo_behind_third_row"]["anchors"]] == sorted(a["points"] for a in scoring["scoring"]["cargo_practicality"]["components"]["cargo_behind_third_row"]["anchors"]),
    }
    all_valid = category_total == 100 and all(component_checks[k] == scoring["scoring"][k]["max_points"] for k in component_checks) and all(anchor_checks.values())
    dump(ROOT / "analysis/config-validation.json", {
        "status": "pass" if all_valid else "fail",
        "scoring_config_version": scoring["version"],
        "scoring_config_sha256": sha256_file(ROOT / "config/scoring-config.json"),
        "category_maximum_total": category_total,
        "component_maximum_checks": {k: {"calculated": v, "declared": scoring["scoring"][k]["max_points"], "pass": v == scoring["scoring"][k]["max_points"]} for k, v in component_checks.items()},
        "anchor_checks": anchor_checks,
        "notes": ["Cargo anchors increase in both cargo value and points, as intended.", "TCO and purchase-price anchors increase in cost while score declines."],
    })

    print(f"Built {len(sources)} sources, {len(cb.claims)} claims, {len(eligibility)} eligibility records, and {len(PRICE_RECORDS)} price records.")


if __name__ == "__main__":
    main()
