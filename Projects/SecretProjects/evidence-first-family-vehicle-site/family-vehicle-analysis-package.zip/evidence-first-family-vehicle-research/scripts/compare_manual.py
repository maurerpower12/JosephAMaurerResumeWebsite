from __future__ import annotations
import hashlib, json
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def load(rel): return json.loads((ROOT/rel).read_text())
def write(rel,obj):
 p=ROOT/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(obj,indent=2)+"\n")
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

manifest=load('run-manifest.json')
if not manifest.get('independent_recommendation_locked'):
 raise SystemExit('Independent recommendation must be locked before manual research is read.')
manual_path=ROOT/'MANUAL_RESEARCH.md'
manual_hash=sha(manual_path)
score=load('analysis/scorecard.json')
rec=load('decisions/recommendation.json')

comparison={
 'schema_version':'1.0','run_id':manifest['run_id'],
 'independent_recommendation_sha256':manifest['independent_recommendation_sha256'],
 'manual_research_sha256':manual_hash,
 'comparison_timestamp_utc':datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z'),
 'independent_result_unchanged':True,
 'agreements':[
  {'topic':'Honda Pilot eligibility','manual_position':'Pilot is a plausible candidate with complete row-3 LATCH and adequate cargo.','ai_result':'Pilot passes all hard filters and was deep-researched, but scores sixth because current IIHS test quality, reliability evidence and TCO are weaker than leading options.','claim_ids':['CLM-0129','CLM-0133','CLM-0159']},
  {'topic':'CX-90 cargo','manual_position':'Cargo is 14.9-15.9 cu ft and is a major concern.','ai_result':'Eliminated at low cost because published cargo is below the 16-cu-ft threshold.','claim_ids':['CLM-0432']},
  {'topic':'XC90 cargo and row-3 child-seat limits','manual_position':'Cargo is 15.8 cu ft and row-3 child-seat placement is limited.','ai_result':'Eliminated on cargo before expensive research.','claim_ids':['CLM-0433']},
  {'topic':'EV first-model-year risk','manual_position':'Ioniq 9 could make the family guinea pigs.','ai_result':'The independent EV finalist, EV9, receives only 1/10 reliability because first-year electrical/ICCU risk is material.','claim_ids':['CLM-0342','CLM-0343','CLM-0344','CLM-0345']}
 ],
 'disagreements':[
  {'topic':'Volkswagen Atlas row-3 LATCH','manual_position':'Two row-3 anchor and tether positions.','ai_result':'IIHS maps both third-row positions as tether-only, so the Atlas fails the configured complete-LATCH definition.','impact':'Definitive elimination; the manual shortlist would have admitted an ineligible vehicle.','claim_ids':['CLM-0404'],'source_ids':['SRC-0007']},
  {'topic':'Acura MDX NHTSA applicability','manual_position':'Five-star NHTSA rating.','ai_result':'The exact 2024 SH-AWD configuration is shown as unrated; the configured unrated policy is not a pass.','impact':'Definitive elimination for the exact drivetrain.','claim_ids':['CLM-0426'],'source_ids':['SRC-0012']},
  {'topic':'Ioniq 9 model-year scope','manual_position':'Included despite first model year being 2026.','ai_result':'Outside the frozen 2023-2025 intersection and unavailable as a 2022-2025 used vehicle.','impact':'Not eligible for this run.'},
  {'topic':'Grand Highlander safety','manual_position':'Retained as a functional hybrid despite lower safety rating.','ai_result':'Fails the exact-year IIHS award gate and therefore is not scoreable.','impact':'Definitive elimination.','claim_ids':['CLM-0430']}
 ],
 'human_insights_the_ai_preserved':[
  'The removable Pilot second-row center seat is decision-relevant and should be verified on the exact used vehicle.',
  'Ceiling-mounted rear vents materially affect family comfort but remain a tie-break preference rather than a hard requirement.',
  'Rapid depreciation can be either a concern or a used-buyer opportunity; it must flow through acquisition price and residual uncertainty rather than an undocumented penalty.'
 ],
 'ai_insights_missing_from_manual':[
  'Exact build-date restrictions materially condition the EV9 and Pathfinder safety awards.',
  'The EV9, Telluride, Sienna and Pathfinder form a stronger diversified test-drive slate than the supplied set after exact hard-filter enforcement.',
  'Used price requires direct listing evidence and normalization rather than a single remembered or generic value.',
  'Insurance, VIN campaign closure, battery health and physical child-seat/cargo tests can reverse the recommendation.'
 ],
 'ai_errors_or_limitations_identified_during_comparison':[
  'The independent portfolio standardized deep research on model year 2024 rather than exhaustively testing every 2023 and 2025 variant; this improves consistency but may miss a superior adjacent model year.',
  'Several qualitative comfort, owner-pattern and long-horizon repair inputs remain medium or low confidence and are carried into sensitivity rather than treated as precise facts.',
  'Current listings are snapshots and must be refreshed for Q4 2026; the report is a test-drive slate, not a transaction authorization.'
 ],
 'effect_on_independent_recommendation':'None. The locked recommendation file and hash are unchanged.'
}
write('analysis/human-vs-ai-comparison.json',comparison)

corr=load('evidence/corrections.json')
existing={c['correction_id'] for c in corr.get('corrections',[])}
new=[
 {'correction_id':'COR-0001','original_claim':'Manual research: 2024 Atlas has two complete row-3 LATCH positions.','corrected_claim':'IIHS shows tether anchors but no row-3 lower anchors; zero complete row-3 LATCH positions under the project definition.','phase_or_step_discovered':'post-lock human-versus-AI comparison','reason':'The manual dataset conflated tether availability with a complete LATCH position.','evidence':['CLM-0404','SRC-0007'],'scoring_or_eligibility_impact':'Atlas fails eligibility and receives no score.'},
 {'correction_id':'COR-0002','original_claim':'Manual research: 2024 Acura MDX Advance SH-AWD has a five-star NHTSA overall rating.','corrected_claim':'The exact SH-AWD NHTSA page is unrated under the frozen exact-configuration rule.','phase_or_step_discovered':'post-lock human-versus-AI comparison','reason':'A rating from another drivetrain or configuration cannot be transferred.','evidence':['CLM-0426','SRC-0012'],'scoring_or_eligibility_impact':'MDX fails eligibility and receives no score.'},
 {'correction_id':'COR-0003','original_claim':'Manual research included a 2026 Hyundai Ioniq 9 in a used 2022-2025 project.','corrected_claim':'The Ioniq 9 is outside the frozen 2023-2025 model-year intersection for this run.','phase_or_step_discovered':'post-lock human-versus-AI comparison','reason':'Model-year scope mismatch.','evidence':[],'scoring_or_eligibility_impact':'Not admitted to the candidate universe.'}
]
corr['status']='corrections_recorded'
corr['corrections'].extend(c for c in new if c['correction_id'] not in existing)
write('evidence/corrections.json',corr)

ledger=load('decisions/decision-ledger.json')
if not any(d['decision_id']=='DEC-0011' for d in ledger['decisions']):
 ledger['decisions'].append({'decision_id':'DEC-0011','step':'post_lock_human_comparison','decision':'Open and compare MANUAL_RESEARCH.md only after independent recommendation lock','input_claim_ids_or_score_ids':[manifest['independent_recommendation_sha256']], 'concise_rationale':'The comparison identified useful human observations and three material input errors without contaminating the locked result.','reversible':False,'reversal_conditions':None,'date':'2026-08-24'})
write('decisions/decision-ledger.json',ledger)
manifest['input_hashes']['manual_research_sha256']=manual_hash
manifest['prior_human_research_consulted']=True
manifest['human_comparison_artifact']='analysis/human-vs-ai-comparison.json'
write('run-manifest.json',manifest)
print('Manual research compared after lock; recommendation hash remains',manifest['independent_recommendation_sha256'])
