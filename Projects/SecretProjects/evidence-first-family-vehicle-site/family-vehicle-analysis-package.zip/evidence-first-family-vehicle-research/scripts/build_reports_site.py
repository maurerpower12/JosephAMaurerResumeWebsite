from __future__ import annotations

import base64
import html
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from project_data import DEEP_VEHICLES, RUN_DATE, RUN_ID

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / "site"


def load(rel: str) -> Any:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def dump(rel: str, obj: Any) -> None:
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def money(v: float | int | None) -> str:
    return "—" if v is None else f"${v:,.0f}"


def pct(v: float) -> str:
    return f"{v * 100:.1f}%"


manifest = load("run-manifest.json")
requirements = load("config/normalized-requirements.json")
assumptions = load("config/project-assumptions.json")
scoring = load("analysis/scorecard.json")
tco = load("analysis/tco-model.json")
sensitivity = load("analysis/sensitivity.json")
uncertainty = load("analysis/uncertainty-simulation.json")
eligibility = load("analysis/eligibility.json")
eliminations = load("decisions/eliminations.json")
recommendation = load("decisions/recommendation.json")
ledger = load("decisions/decision-ledger.json")
claims_doc = load("evidence/claims.json")
sources_doc = load("evidence/sources.json")
price_doc = load("evidence/price-records.json")
contradictions = load("evidence/contradictions.json")
corrections = load("evidence/corrections.json")
judgments = load("analysis/judgments.json")
comparison = load("analysis/human-vs-ai-comparison.json")
queries = load("research/query-log.json")
candidates = load("research/candidate-universe.json")
config_validation = load("analysis/config-validation.json")

score_by_id = {v["vehicle_id"]: v for v in scoring["vehicles"]}
tco_by_id = {v["vehicle_id"]: v for v in tco["vehicles"]}
source_by_id = {s["source_id"]: s for s in sources_doc["sources"]}
price_by_vehicle: dict[str, list[dict[str, Any]]] = {}
for p in price_doc["price_records"]:
    price_by_vehicle.setdefault(p["vehicle_id"], []).append(p)

# Price summary with separately labeled planning OTD estimates.
price_summaries = []
for vid, raw in DEEP_VEHICLES.items():
    tax = tco["global_assumptions"]["sales_tax_rate"]
    fees = raw["tco_inputs"]["initial_fees"]
    first_year_registration_allowance = raw["tco_inputs"]["registration_5"] / 5
    otd = {
        k: round(raw["price"][k] * (1 + tax) + fees + first_year_registration_allowance, 2)
        for k in ("low", "base", "high")
    }
    price_summaries.append({
        "vehicle_id": vid,
        "vehicle": raw["short_name"],
        "official_scoring_price": raw["price"]["base"],
        "low": raw["price"]["low"],
        "base": raw["price"]["base"],
        "high": raw["price"]["high"],
        "confidence": raw["price"]["confidence"],
        "estimated_out_the_door": otd,
        "otd_note": "Planning estimate includes 9.1% sales tax, modeled initial fees and one-fifth of the five-year registration/RTA allowance. Exact address, dealer documentation and transaction terms can change it.",
        "price_record_ids": raw["price"]["price_record_ids"],
        "listings": price_by_vehicle.get(vid, []),
    })
dump("analysis/price-summary.json", {"schema_version": "1.0", "run_id": RUN_ID, "vehicles": price_summaries})

# Original local illustrations.
images_dir = SITE / "assets/images"
images_dir.mkdir(parents=True, exist_ok=True)

def vehicle_svg(title: str, subtitle: str, kind: str, accent: str) -> str:
    if kind == "minivan":
        body = "M110 235 C135 180 185 148 276 142 L492 142 C560 146 610 174 650 226 L702 235 L710 286 L90 286 L90 250 Z"
        roof = "M218 148 C266 103 335 92 458 96 C520 99 566 116 607 153"
    elif kind == "electric":
        body = "M105 235 C132 181 184 148 254 143 L502 143 C576 147 626 177 665 226 L710 238 L710 286 L88 286 L88 250 Z"
        roof = "M215 149 C258 105 335 91 470 96 C535 99 581 118 620 155"
    else:
        body = "M102 238 C132 188 183 157 257 149 L487 149 C554 153 609 181 650 228 L707 239 L710 286 L88 286 L88 252 Z"
        roof = "M224 153 C267 114 331 101 454 105 C518 108 563 124 601 158"
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 420" role="img" aria-labelledby="title desc">
<title id="title">{html.escape(title)} original vehicle illustration</title><desc id="desc">Neutral side-profile illustration created for this report; not manufacturer artwork.</desc>
<defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="{accent}"/><stop offset="1" stop-color="#6d5dfc"/></linearGradient><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#eaf2ff"/><stop offset="1" stop-color="#f8fafc"/></linearGradient></defs>
<rect width="800" height="420" rx="28" fill="url(#sky)"/><path d="M0 310 C170 270 290 338 445 299 C585 264 682 286 800 252 L800 420 L0 420 Z" fill="#dce7ea"/>
<circle cx="674" cy="83" r="34" fill="#fff6c7"/><path d="{roof}" fill="none" stroke="#172033" stroke-width="12" stroke-linecap="round"/><path d="{body}" fill="url(#g)" stroke="#172033" stroke-width="10" stroke-linejoin="round"/>
<path d="M244 151 L300 116 L444 116 L518 151 Z" fill="#bfe3f4" stroke="#172033" stroke-width="8"/><path d="M380 118 L380 151" stroke="#172033" stroke-width="7"/>
<circle cx="224" cy="286" r="52" fill="#172033"/><circle cx="224" cy="286" r="26" fill="#d5dbe5"/><circle cx="590" cy="286" r="52" fill="#172033"/><circle cx="590" cy="286" r="26" fill="#d5dbe5"/>
<path d="M116 241 L163 241" stroke="#fff" stroke-width="8" stroke-linecap="round"/><path d="M654 238 L687 242" stroke="#fff5c7" stroke-width="9" stroke-linecap="round"/>
<text x="44" y="365" font-family="system-ui, -apple-system, sans-serif" font-size="28" font-weight="750" fill="#172033">{html.escape(title)}</text><text x="44" y="396" font-family="system-ui, -apple-system, sans-serif" font-size="17" fill="#506074">{html.escape(subtitle)}</text>
</svg>'''

accent_map = {
    "VEH-KIA-EV9-2024-LAND-AWD-POSTJAN24": ("electric", "#1b8f82"),
    "VEH-KIA-TELLURIDE-2024-SX-PRESTIGE-XPRO-AWD": ("suv", "#b96836"),
    "VEH-TOYOTA-SIENNA-2024-PLATINUM-AWD": ("minivan", "#356fa8"),
    "VEH-NISSAN-PATHFINDER-2024-PLATINUM-4WD-POSTNOV23": ("suv", "#63728a"),
    "VEH-FORD-EXPLORER-2024-PLATINUM-4WD": ("suv", "#4d62a8"),
    "VEH-HONDA-PILOT-2024-ELITE-AWD": ("suv", "#8a5c96"),
}
image_map = {}
for vid, raw in DEEP_VEHICLES.items():
    kind, accent = accent_map[vid]
    filename = re.sub(r"[^a-z0-9]+", "-", raw["short_name"].lower()).strip("-") + ".svg"
    (images_dir / filename).write_text(vehicle_svg(raw["short_name"], "Original neutral vector — evidence-first report", kind, accent), encoding="utf-8")
    image_map[vid] = f"assets/images/{filename}"

hero_svg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 430" role="img" aria-labelledby="t d"><title id="t">Family vehicle evidence map</title><desc id="d">Abstract diagram connecting decision, score, rule, claim and source.</desc><defs><linearGradient id="bg" x1="0" x2="1"><stop stop-color="#0f1930"/><stop offset="1" stop-color="#1d2d52"/></linearGradient><linearGradient id="line" x1="0" x2="1"><stop stop-color="#76e4d2"/><stop offset="1" stop-color="#b6a7ff"/></linearGradient></defs><rect width="1200" height="430" rx="28" fill="url(#bg)"/><g fill="none" stroke="url(#line)" stroke-width="5" opacity=".75"><path d="M170 210 H345"/><path d="M450 210 H625"/><path d="M730 210 H905"/><path d="M1010 210 H1090"/></g><g font-family="system-ui,-apple-system,sans-serif" text-anchor="middle"><g><rect x="55" y="145" width="220" height="130" rx="24" fill="#162744" stroke="#76e4d2" stroke-width="3"/><text x="165" y="200" fill="#fff" font-size="26" font-weight="750">Decision</text><text x="165" y="234" fill="#b8c8df" font-size="17">Conditional test-drive slate</text></g><g><rect x="340" y="145" width="220" height="130" rx="24" fill="#162744" stroke="#8ddacb" stroke-width="3"/><text x="450" y="200" fill="#fff" font-size="26" font-weight="750">Score</text><text x="450" y="234" fill="#b8c8df" font-size="17">Deterministic code</text></g><g><rect x="625" y="145" width="220" height="130" rx="24" fill="#162744" stroke="#a8c2ef" stroke-width="3"/><text x="735" y="200" fill="#fff" font-size="26" font-weight="750">Rule + input</text><text x="735" y="234" fill="#b8c8df" font-size="17">Frozen configuration</text></g><g><rect x="910" y="145" width="220" height="130" rx="24" fill="#162744" stroke="#b6a7ff" stroke-width="3"/><text x="1020" y="200" fill="#fff" font-size="26" font-weight="750">Claim + source</text><text x="1020" y="234" fill="#b8c8df" font-size="17">Auditable provenance</text></g></g></svg>'''
(images_dir / "evidence-chain.svg").write_text(hero_svg, encoding="utf-8")

# Vehicle dossiers.
dossier_dir = ROOT / "research/vehicle-dossiers"
dossier_dir.mkdir(parents=True, exist_ok=True)

def source_line(ids: list[str]) -> str:
    parts = []
    for sid in ids:
        s = source_by_id.get(sid)
        if s:
            parts.append(f"[{sid}]({s['url']})")
    return ", ".join(parts)

for vid, raw in DEEP_VEHICLES.items():
    sc = score_by_id[vid]
    tv = tco_by_id[vid]
    listings = price_by_vehicle.get(vid, [])
    price_lines = "\n".join(
        f"- [{p['seller_name']} — {money(p['listed_price'])}, {p['mileage'] if p['mileage'] is not None else 'mileage unavailable'} miles, {p['listing_status_at_retrieval']}]({p['source_url']}) — VIN {p['vin'] or 'not provided'}, retrieved {p['retrieved_at'][:10]}."
        for p in listings
    )
    categories = {c["category"]: c["confirmed_points"] for c in sc["category_scores"]}
    md = f"""# {raw['short_name']} — standardized research dossier

**Vehicle ID:** `{vid}`  
**Eligibility:** `{raw['eligibility']['overall']}`  
**Official frozen score:** **{sc['confirmed_points']:.1f}/100**  
**Configuration condition:** {raw['configuration_condition']}

## 1. Exact configuration and pricing
The scored configuration is a used {raw['year']} {raw['make']} {raw['model']} {raw['trim']} with {raw['drivetrain']} and a {raw['powertrain']} powertrain. The normalized acquisition range is {money(raw['price']['low'])}–{money(raw['price']['high'])}, with {money(raw['price']['base'])} used for the official score. Confidence is **{raw['price']['confidence']}**. The score references price records {', '.join(raw['price']['price_record_ids'])}.

{price_lines}

## 2. Safety and crash avoidance
The configuration records **{raw['eligibility']['nhtsa_overall'][1]} NHTSA stars** and **{raw['safety']['award']}** from IIHS. The safety category score is **{categories['safety']:.1f}/25**. Any build-date restriction remains a binary VIN-level condition. Sources: {source_line(raw['source_ids'][:3])}.

## 3. LATCH, child-seat access, and family usability
Row 2 has {raw['eligibility']['row2_complete_latch'][1]} complete LATCH positions and row 3 has {raw['eligibility']['row3_complete_latch'][1]}. IIHS/owner-manual applicability is encoded in claim IDs attached to the scorecard. Online evidence cannot establish whether the family's exact seats preserve third-row access; that must be physically tested.

## 4. Passenger and cargo practicality
Third-row legroom is {raw['space']['third_row_legroom']} inches and the real-world classification is `{raw['space']['third_row_usability']}`. Cargo behind row 3 is {raw['cargo']['volume']} cu ft. Passenger-space score: **{categories['passenger_space']:.1f}/10**. Cargo score: **{categories['cargo_practicality']:.1f}/10**.

## 5. Reliability, recalls, investigations, campaigns, and technical-service patterns
{raw['reliability']['summary']} Reliability score: **{categories['reliability']:.1f}/10**. Classification: predicted/measured `{raw['reliability']['predicted']}`, platform `{raw['reliability']['maturity']}`, campaigns `{raw['reliability']['recalls']}`, owner pattern `{raw['reliability']['owner_pattern']}`. Complaint counts are not interpreted as failure rates.

## 6. Owner sentiment with duplicated stories removed
Owner evidence is used only for recurring-pattern classification and is cross-checked against recall/campaign evidence. The surviving pattern is `{raw['reliability']['owner_pattern']}`. Confidence remains medium or low where evidence is indirect; no isolated story changes eligibility or score.

## 7. Fuel or energy use
Modeled annual energy cost is **{money(tv['annual_energy_cost_base'])}** at 8,000 miles/year. Energy score: **{categories['fuel_economy']:.1f}/10**. Formula and claim IDs are recorded in `analysis/tco-model.json`.

## 8. EV charging and route practicality, where applicable
{('Home Level 2 charging is already installed. The model uses 90% home and 10% public DC fast charging, 90% wall-to-battery efficiency, and current local rate assumptions. Snoqualmie Pass use requires an actual cold-weather route plan and charging test.' if raw['powertrain']=='electric' else 'Not applicable as a plug-in charging workflow. Winter pass travel still requires tire, traction and fuel-range planning.')}

## 9. Maintenance, tires, consumables, and repair exposure
The planning model includes maintenance, repairs, tires/consumables, registration/RTA allowance, tax, fees and residual value. Insurance is excluded numerically without comparable household quotes. Base TCO is **{money(tv['scenarios']['5_year']['base']['total_tco'])} over five years** and **{money(tv['scenarios']['10_year']['base']['total_tco'])} over ten years**.

## 10. Depreciation and resale uncertainty
Residual-value assumptions are low-confidence planning inputs, not forecasts. Low/base/high TCO scenarios vary purchase price and residual fraction, and uncertainty simulation perturbs both. Rapid first-owner depreciation can benefit a used buyer while still increasing ten-year resale uncertainty.

## 11. Insurance risk, without fabricating exact quotes
No exact premium is modeled. Obtain same-day VIN-specific quotes from the household's insurer for every finalist. A material premium gap is an explicit recommendation-reversal condition.

## 12. Technology and daily experience
Technology score: **{categories['technology']:.1f}/5**. Comfort score: **{categories['comfort']:.1f}/5**. Verified feature inputs are expanded component-by-component in `analysis/scorecard.json`; physical controls, camera usefulness, alerts and interface latency require a test drive.

## 13. Warranty and service access
Verify original in-service date, remaining transferable warranty, CPO coverage, roadside benefits, nearby qualified service access and all completed campaigns on the exact VIN. Do not infer coverage from model year alone.

## 14. Adversarial regret case
**Most plausible five-year regret:** {raw['regret_case']}

Evidence supporting that concern is carried in the reliability, price and TCO claims. Counterevidence is the vehicle's verified strengths and the absence of an exclusion-level defect pattern under the configured standard.

## 15. Decision-changing facts
- Advance reason: {raw['advance_reason']}
- Major concern: {raw['major_concern']}
- Evidence that would eliminate it: {raw['elimination_evidence']}

## 16. Online unknowns that require physical validation
{chr(10).join('- ' + x for x in raw['physical_unknowns'])}

## 17. Confidence and evidence gaps
Overall score evidence confidence is **{sc['overall_evidence_confidence']}**. Pricing is time-sensitive; qualitative reliability and repair inputs carry more uncertainty than safety ratings and official dimensions. The score is provisional for the exact qualifying configuration and is not purchase authorization.

## Traceability pointers
- Scorecard: `analysis/scorecard.json`
- TCO: `analysis/tco-model.json`
- Claim registry: `evidence/claims.json`
- Source registry: `evidence/sources.json`
- Price records: `evidence/price-records.json`
- Price record IDs: {', '.join(raw['price']['price_record_ids'])}
"""
    slug = re.sub(r"[^a-z0-9]+", "-", raw["short_name"].lower()).strip("-")
    (dossier_dir / f"{slug}.md").write_text(md, encoding="utf-8")

# Checklists.
test_checklist = """# Client Test-Drive Checklist

Use the same route, child seats, cargo and scoring scale for every vehicle. Record observations as `OBS-####` before allowing them to affect a decision.

## Before driving
- [ ] Photograph VIN and driver-door certification label; record build month/year.
- [ ] Confirm exact trim, drivetrain, seating configuration and included keys/charging equipment.
- [ ] Run the VIN through NHTSA and the manufacturer service system; photograph campaign status.
- [ ] Verify current listed price, seller fees, certification terms and warranty in writing.

## Child seats and third-row access
- [ ] Install both actual child seats using the intended seating positions.
- [ ] Confirm lower anchors and top tether are at the same seating position.
- [ ] Check buckle access, anchor visibility, seat movement and seatback interference.
- [ ] Attempt third-row access with both seats installed; do not accept a theoretical demonstration.
- [ ] Seat an adult in row 3 for at least 15 minutes and rate knees, feet, headroom and motion comfort.

## Cargo and dog test
- [ ] Load stroller, diaper bag, groceries, dog gear and one representative trip load with row 3 raised.
- [ ] Confirm the hatch closes without compressing equipment.
- [ ] Check lift-over height, underfloor storage, tie-downs and dog entry path.
- [ ] Confirm rear visibility and emergency-access path after loading.

## Comfort and daily controls
- [ ] Test row-2 and row-3 airflow at idle and while moving.
- [ ] Rate front and rear seat comfort, ride over broken pavement, wind noise and tire noise.
- [ ] Pair both phones; test CarPlay/Android Auto, camera latency, physical controls and alerts.
- [ ] Test nighttime headlight operation when feasible.

## Driving and safety systems
- [ ] Use the same city, highway, hill, rough-road and parking route.
- [ ] Test braking feel, low-speed response, lane centering, adaptive cruise and blind-spot alerts.
- [ ] Perform tight parking, garage simulation and 360-camera checks.
- [ ] Listen for suspension, driveline, trim and HVAC noises.

## EV-specific checks
- [ ] Obtain battery state-of-health documentation.
- [ ] Complete a Level 2 charging session and verify scheduled charging.
- [ ] Complete a DC fast-charge session; record starting SOC, ending SOC, time and peak rate.
- [ ] Check 12-volt battery history, ICCU work, charging faults and display/cluster history.
- [ ] Review cold-weather Snoqualmie Pass route planning at the expected winter state of charge.

## Immediately after
- [ ] Obtain VIN-specific insurance quote.
- [ ] Record observed strengths, annoyances and stop conditions before discussing favorites.
- [ ] Score physical observations separately from the frozen internet score.
- [ ] Decide: keep on slate / repeat test / remove from slate.
"""
prepurchase = """# Pre-Purchase Checklist

## Identity, eligibility and title
- [ ] VIN matches windshield, door label, title, listing and diagnostic scan.
- [ ] Model year, trim, drivetrain, seating and build date satisfy every binary requirement.
- [ ] Clean title and acceptable accident/history report; verify no branded, lemon or buyback title.
- [ ] Seller identity and authority to sell are verified.

## Safety, recalls and service history
- [ ] NHTSA and manufacturer recall/campaign records show no open items.
- [ ] IIHS award restrictions match the exact build date, headlights and equipment.
- [ ] Complete maintenance records are reviewed for gaps and repeated repairs.
- [ ] Independent pre-purchase inspection completed by a brand-competent shop.
- [ ] Tires, brakes, alignment, fluids, suspension and 12-volt battery measured, not visually guessed.

## Family fit
- [ ] Both actual car seats installed and independently checked.
- [ ] Third-row access works in the intended daily configuration.
- [ ] Required cargo and dog load physically passes with row 3 raised.
- [ ] All rear vents, seat mechanisms, power-fold functions and cameras work.

## EV/PHEV additions
- [ ] Battery state of health and diagnostic fault history are documented.
- [ ] Level 2 and DC charging tests pass.
- [ ] Charging cable, adapters and portable EVSE are present and functional.
- [ ] ICCU, onboard charger, 12-volt and software campaign history is reviewed.

## Money and documents
- [ ] Final vehicle price is separated from tax, title, registration, document fee, accessories and add-ons.
- [ ] Every discount is unconditional or documented with verified buyer eligibility and expiration.
- [ ] Cash price is not increased because financing is declined.
- [ ] VIN-specific insurance quote accepted before signing.
- [ ] Warranty/CPO coverage, exclusions, deductible and in-service date are in writing.
- [ ] Final out-the-door amount is reconciled against the report's planning range.
- [ ] No blank forms, arbitration surprises or optional products remain unexplained.

## Final stop rule
- [ ] Any unresolved binary requirement, repeated material fault, failed fit test or unexplained fee stops the purchase.
"""
(ROOT / "checklists/client-test-drive-checklist.md").write_text(test_checklist, encoding="utf-8")
(ROOT / "checklists/pre-purchase-checklist.md").write_text(prepurchase, encoding="utf-8")

# Report markdown.
rank_lines = "\n".join(
    f"| {i} | {v['vehicle']} | {v['eligibility_gate']} | {v['confirmed_points']:.1f} | {v['interpretation']} |"
    for i, v in enumerate(scoring["vehicles"], 1)
)
elig_header = ["Vehicle", "Overall", "3rd row", "NHTSA", "IIHS", "R2 LATCH", "R3 LATCH", "Cargo", "AWD/4WD", "Price", "Reliability gate"]
elig_rows = []
for v in eligibility["vehicles"]:
    req = {r["requirement"]: r["status"] for r in v["requirements"]}
    elig_rows.append("| " + " | ".join([
        v["vehicle"], v["overall_status"], req.get("third_row", "—"), req.get("nhtsa_overall", "—"), req.get("iihs_award", "—"),
        req.get("row2_complete_latch", "—"), req.get("row3_complete_latch", "—"), req.get("cargo_behind_row3", "—"),
        req.get("awd_or_4wd", "—"), req.get("price_ceiling", "—"), req.get("reliability_exclusion", "—")
    ]) + " |")

tco_lines = []
for v in tco["vehicles"]:
    s = v["scenarios"]
    tco_lines.append(f"| {v['vehicle']} | {money(s['5_year']['low']['total_tco'])} | {money(s['5_year']['base']['total_tco'])} | {money(s['5_year']['high']['total_tco'])} | {money(s['10_year']['low']['total_tco'])} | {money(s['10_year']['base']['total_tco'])} | {money(s['10_year']['high']['total_tco'])} |")

price_sections = []
for ps in price_summaries:
    listings = "\n".join(
        f"  - [{p['seller_name']} — {money(p['listed_price'])}]({p['source_url']}), {p['seller_location']}, {p['mileage'] if p['mileage'] is not None else 'mileage unavailable'} miles, VIN/stock {p['vin'] or p['stock_number'] or 'not provided'}, status `{p['listing_status_at_retrieval']}`, retrieved {p['retrieved_at'][:10]}. Adjustments: {json.dumps(p.get('normalization_adjustments', []), ensure_ascii=False)}"
        for p in ps["listings"]
    )
    price_sections.append(f"- **{ps['vehicle']}** — score price {money(ps['official_scoring_price'])}; planning range {money(ps['low'])}–{money(ps['high'])}; base planning OTD {money(ps['estimated_out_the_door']['base'])}; confidence {ps['confidence']}.\n{listings}")

eligibility_name_by_id = {v["vehicle_id"]: v["vehicle"] for v in eligibility["vehicles"]}
elim_lines = "\n".join(f"- **{eligibility_name_by_id.get(e['vehicle_id'], e['vehicle_id'])}** — `{e['failed_requirement']}`: {e['reason']} Claim: `{e['claim_id']}`." for e in eliminations["eliminations"])
contr_lines = "\n".join(f"- `{c['contradiction_id']}` — {c['vehicle_and_topic']}: {c['likely_reason']}. Resolution: {c['resolution_rule']}; impact: {c['impact']}." for c in contradictions["contradictions"])
corr_lines = "\n".join(f"- `{c['correction_id']}` — {c['original_claim']} → {c['corrected_claim']} Impact: {c['scoring_or_eligibility_impact']}" for c in corrections["corrections"])

report_md = f"""# Evidence-First Family Vehicle Research Report

**Run:** `{RUN_ID}`  
**Date:** {RUN_DATE}  
**Market:** United States, home ZIP 98038  
**Mode:** Portfolio, used vehicles, frozen model years 2023–2025  
**Independent recommendation consulted manual research before lock:** **No**  
**Manual comparison completed after lock:** **Yes**

## Executive decision
The current evidence-based recommendation is the **{recommendation['current_recommendation']['vehicle']}**, with a **conditional-pass** eligibility status and a frozen deterministic score of **{recommendation['current_recommendation']['confirmed_score']:.1f}/100**. It is not a purchase authorization. It is the first vehicle to test because it combines strong safety, family packaging, low modeled energy cost and used-market value, while carrying the most serious first-model-year electrical/ICCU risk in the finalist group.

The runner-up is the **{recommendation['runner_up']['vehicle']}** at **{recommendation['runner_up']['confirmed_score']:.1f}/100**. The family-utility alternative is the **{recommendation['conditional_alternative']['vehicle']}** at **{recommendation['conditional_alternative']['confirmed_score']:.1f}/100**. The **{recommendation['live_alternate']['vehicle']}** remains live if a finalist fails its VIN/build/fit gates.

## What this analysis is and is not
This is a reproducible internet-research and planning model. It enforces exact-year hard filters, links scored inputs to claim IDs and source IDs, uses code for interpolation/TCO/sorting/simulation, and exposes uncertainty. It does not replace a VIN check, build-date check, recall/campaign verification, inspection, battery/charging test, insurance quote, child-seat installation, cargo load test or test drive.

## Input freeze and assumptions
- Purchase: used, cash, Q4 2026; soft anchor $65,000, hard vehicle-price ceiling $80,000.
- Household: two adults, children about 3 and 1, two child seats, medium dog; 2025 Mach-E retained.
- Driving: 8,000 miles/year base, 6,000–9,000 range, 70% city, 30% highway, occasional Snoqualmie Pass travel.
- EV: existing Level 2 charging; 90% home and 10% public DC fast charging.
- Ownership: ten-year primary horizon, five-year flag.
- Scope conflict: research config admitted 2022, scoring config started at 2023. The run conservatively froze the intersection, 2023–2025, without changing the source files.
- Used-price rule: the project-specific used-market override controls the official purchase-price score; this is recorded in the judgment and decision logs.
- Insurance: excluded numerically because actual comparable quotes were not supplied.

## Configuration validation
The category maximums total **{config_validation.get('category_max_total', 100)}**. Component maximums and interpolation anchors were validated before scoring. Scoring config version `{scoring['scoring_config_version']}`, hash `{scoring['scoring_config_sha256']}`.

## Research funnel
- Candidate universe: **{len(candidates['candidates'])}** vehicles.
- Low-cost hard-filter eliminations: **{len(eliminations['eliminations'])}**.
- Deep-researched configurations: **{len(DEEP_VEHICLES)}**.
- Finalists: **{len(recommendation['finalists'])}**, plus one live alternate.
- Queries logged: **{len(queries['queries'])}**.
- Sources registered: **{len(sources_doc['sources'])}**.
- Claims registered: **{len(claims_doc['claims'])}**.

## Official deterministic ranking
| Rank | Vehicle | Eligibility | Score / 100 | Interpretation |
|---:|---|---|---:|---|
{rank_lines}

The official score gap between EV9 and Telluride is {scoring['vehicles'][0]['confirmed_points'] - scoring['vehicles'][1]['confirmed_points']:.1f} points, above the 2-point practical-tie threshold. Uncertainty still matters because the EV9's risk is concentrated in low-confidence reliability/repair/residual inputs and transaction-level stop conditions.

## Requirements pass/fail matrix
| {' | '.join(elig_header)} |
|{'|'.join(['---'] + ['---'] * (len(elig_header)-1))}|
{chr(10).join(elig_rows)}

`not_researched_after_failure` means the run stopped expensive work after a definitive failure, as required; it does not mean the vehicle failed every unresearched field.

## Finalist rationale
### 1. {recommendation['current_recommendation']['vehicle']}
- **Why first:** {recommendation['current_recommendation']['concise_rationale']}
- **Main compromise:** {recommendation['current_recommendation']['main_compromise']}
- **Adversarial regret case:** {DEEP_VEHICLES[recommendation['current_recommendation']['vehicle_id']]['regret_case']}
- **Stop conditions:** {', '.join(recommendation['current_recommendation']['purchase_stop_conditions'])}

### 2. {recommendation['runner_up']['vehicle']}
- **Why it advances:** {recommendation['runner_up']['why_it_advances']}
- **Main compromise:** {recommendation['runner_up']['main_compromise']}
- **Adversarial regret case:** {DEEP_VEHICLES[recommendation['runner_up']['vehicle_id']]['regret_case']}

### 3. {recommendation['conditional_alternative']['vehicle']}
- **Why it advances:** {recommendation['conditional_alternative']['why_it_advances']}
- **Main compromise:** {recommendation['conditional_alternative']['main_compromise']}
- **Adversarial regret case:** {DEEP_VEHICLES[recommendation['conditional_alternative']['vehicle_id']]['regret_case']}

## Five- and ten-year TCO scenarios
| Vehicle | 5y low | 5y base | 5y high | 10y low | 10y base | 10y high |
|---|---:|---:|---:|---:|---:|---:|
{chr(10).join(tco_lines)}

TCO includes acquisition price, modeled 9.1% sales tax, initial fees, energy, maintenance, repairs, tires/consumables, registration/RTA planning allowance and residual value. Insurance is separate and can reverse the recommendation. All formulas and claim IDs are in `analysis/tco-model.json`.

## Price evidence and direct links
{chr(10).join(price_sections)}

Listings are retrieval-time observations. They must be refreshed within 14 days of a transaction decision; listings older than 30 days are stale for a final market calculation.

## Sensitivity and uncertainty
- Deterministic simulation seed: `{uncertainty['seed']}`; iterations: `{uncertainty['iterations']}`.
- EV9 probability of ranking first within modeled uncertainty: **{pct(next(x for x in uncertainty['vehicle_results'] if x['vehicle_id']==recommendation['current_recommendation']['vehicle_id'])['probability_rank_1'])}**.
- Telluride probability of ranking first: **{pct(next(x for x in uncertainty['vehicle_results'] if x['vehicle_id']==recommendation['runner_up']['vehicle_id'])['probability_rank_1'])}**.
- The risk-averse exploratory preset ranks Telluride first and EV9 fourth. This does not change the official frozen score; it defines a real preference threshold that can reverse the client decision.
- Value-first produces a practical cluster among EV9, Sienna, Telluride and Pathfinder, reinforcing the need to test physical fit and VIN quality.

## What changes the recommendation
{chr(10).join('- ' + x for x in recommendation['recommendation_reversal_conditions'])}

## Eliminations
{elim_lines}

Eliminated vehicles are not necessarily poor vehicles. They failed this family's frozen requirements, exact applicability rules or scope.

## Contradictions
{contr_lines}

## Corrections recorded after human comparison
{corr_lines}

## Human-versus-AI comparison
The manual research was opened only after the independent recommendation file was saved and hashed. The locked result was not changed. The comparison agreed on Pilot plausibility, CX-90/XC90 cargo limitations and the importance of first-model-year EV risk. Material disagreements involved Atlas row-3 LATCH, exact MDX AWD NHTSA applicability, Ioniq 9 model-year scope and Grand Highlander safety eligibility. See `analysis/human-vs-ai-comparison.json`.

## Online unknowns requiring physical validation
- Exact VIN, build date, headlights/equipment and campaign closure.
- Both actual child seats installed while preserving third-row access.
- Stroller, dog equipment and travel load with row 3 raised.
- Comfort, rear HVAC, ride, noise, controls and driver-assistance behavior.
- VIN-specific insurance quote.
- EV battery state of health, Level 2 charging and DC fast charging.
- Independent pre-purchase inspection and complete service history.
- Actual Q4 2026 price and out-the-door terms.

## Traceability architecture
The audit path is maintained as: decision ledger → score ID → scoring rule → claim ID → source ID → query ID or human observation. Stable registries are in `decisions/decision-ledger.json`, `analysis/scorecard.json`, `evidence/claims.json`, `evidence/sources.json`, `research/query-log.json` and `analysis/human-observations.json`.

## Deliverable map
- Client site: `site/index.html`
- Self-contained report: `reports/client-report-self-contained.html`
- Scorecard: `analysis/scorecard.json`
- TCO: `analysis/tco-model.json`
- Sensitivity/simulation: `analysis/sensitivity.json`, `analysis/uncertainty-simulation.json`
- Recommendation: `decisions/recommendation.json`
- Dossiers: `research/vehicle-dossiers/`
- Test-drive and pre-purchase checklists: `checklists/`
- QA report: `reports/qa-report.md` (generated after final audit)
"""
(ROOT / "reports/research-report.md").write_text(report_md, encoding="utf-8")
# Plain text keeps structure while removing most Markdown punctuation.
plain = re.sub(r"\[(.*?)\]\((.*?)\)", r"\1 (\2)", report_md)
plain = re.sub(r"^#{1,6}\s*", "", plain, flags=re.M)
plain = plain.replace("**", "").replace("`", "")
(ROOT / "reports/research-report.txt").write_text(plain, encoding="utf-8")

comparison_md = "# Human-versus-AI Comparison\n\nThe independent recommendation was locked before this comparison.\n\n" + "\n".join(
    ["## Agreements"] + [f"- **{x['topic']}** — {x['ai_result']}" for x in comparison["agreements"]]
    + ["\n## Disagreements"] + [f"- **{x['topic']}** — Manual: {x['manual_position']} AI audit: {x['ai_result']} Impact: {x['impact']}" for x in comparison["disagreements"]]
    + ["\n## Independent result"] + [comparison["effect_on_independent_recommendation"]]
)
(ROOT / "reports/human-vs-ai-comparison.md").write_text(comparison_md, encoding="utf-8")

# README.
readme = f"""# Evidence-First Family Vehicle Research Package

Run `{RUN_ID}` evaluates a used family vehicle purchase for ZIP 98038 with an exact-year safety/LATCH/cargo/AWD/price gate, deterministic 100-point scoring, direct used-listing evidence, five- and ten-year TCO, sensitivity analysis and a local client site.

## Current result
- Recommendation: **{recommendation['current_recommendation']['vehicle']}**
- Eligibility: **{recommendation['current_recommendation']['eligibility_status']}**
- Frozen score: **{recommendation['current_recommendation']['confirmed_score']:.1f}/100**
- Runner-up: **{recommendation['runner_up']['vehicle']}**
- Independent recommendation was locked before `MANUAL_RESEARCH.md` was opened.

## Open the site
Open `site/index.html` locally. It has no CDN, external CSS or external JavaScript dependency. The standalone version is `reports/client-report-self-contained.html`.

## Reproduce
```bash
python scripts/initialize_run.py
python scripts/build_evidence.py
python scripts/compute_analysis.py
python scripts/compare_manual.py
python scripts/build_reports_site.py
python scripts/qa_package.py
```

The scripts use frozen researched inputs in `scripts/project_data.py`. Refresh time-sensitive sources and listing records before a real transaction.

## Structure
- `config/` authoritative and normalized configuration
- `evidence/` source, claim, contradiction, correction and price registries
- `research/` query log, candidate universe and standardized dossiers
- `analysis/` eligibility, scorecard, TCO, sensitivity, uncertainty and judgments
- `decisions/` eliminations, ledger and locked recommendation
- `checklists/` client test-drive and pre-purchase workflows
- `reports/` narrative, comparison, standalone site and QA
- `site/` editable local client website and downloadable data

## Critical limitation
This package is a test-drive and due-diligence slate, not purchase authorization. VIN/build applicability, recalls/campaigns, service history, insurance, child-seat fit, cargo, comfort, charging and inspection can override the internet result.
"""
(ROOT / "README.md").write_text(readme, encoding="utf-8")

# Prepare report data for front end.
report_data = {
    "manifest": manifest,
    "requirements": requirements,
    "assumptions": assumptions,
    "recommendation": recommendation,
    "scorecard": scoring,
    "tco": tco,
    "price_summaries": price_summaries,
    "sensitivity": sensitivity,
    "uncertainty": uncertainty,
    "eligibility": eligibility,
    "eliminations": eliminations,
    "claims": claims_doc,
    "sources": sources_doc,
    "contradictions": contradictions,
    "corrections": corrections,
    "judgments": judgments,
    "decision_ledger": ledger,
    "comparison": comparison,
    "candidate_universe": candidates,
    "query_log": queries,
    "image_map": image_map,
    "vehicle_metadata": {vid: {k: v for k, v in raw.items() if k not in ("source_ids",)} for vid, raw in DEEP_VEHICLES.items()},
    "checklists": {"test_drive": test_checklist, "pre_purchase": prepurchase},
}
(SITE / "data").mkdir(parents=True, exist_ok=True)
(SITE / "data/report-data.json").write_text(json.dumps(report_data, ensure_ascii=False), encoding="utf-8")

# Copy every JSON/MD/TXT artifact into site/data/project preserving paths.
project_data_dir = SITE / "data/project"
if project_data_dir.exists():
    shutil.rmtree(project_data_dir)
project_data_dir.mkdir(parents=True)
text_artifacts = []
for p in sorted(ROOT.rglob("*")):
    if not p.is_file() or SITE in p.parents:
        continue
    if p.suffix.lower() not in {".json", ".md", ".txt"}:
        continue
    if "__pycache__" in p.parts:
        continue
    rel = p.relative_to(ROOT)
    dest = project_data_dir / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)
    text_artifacts.append({"name": str(rel), "href": f"data/project/{rel.as_posix()}", "content": p.read_text(encoding="utf-8")})
report_data["download_artifacts"] = [{"name": x["name"], "href": x["href"]} for x in text_artifacts]
report_data["embedded_text_downloads"] = {x["name"]: x["content"] for x in text_artifacts}
(SITE / "data/report-data.json").write_text(json.dumps(report_data, ensure_ascii=False), encoding="utf-8")

css = r'''
:root{--bg:#f4f7fb;--surface:#fff;--surface2:#eef3f8;--text:#162033;--muted:#5d6b7d;--line:#d7e0ea;--brand:#186f68;--brand2:#6c5ce7;--good:#157447;--warn:#9a5a00;--bad:#ac2f3f;--shadow:0 18px 50px rgba(24,42,72,.10);--radius:22px;--max:1240px;color-scheme:light dark}body.dark{--bg:#0b1220;--surface:#111b2c;--surface2:#172439;--text:#eef4ff;--muted:#aebbd0;--line:#2a3a53;--brand:#67d5c7;--brand2:#b2a7ff;--good:#75d8a6;--warn:#f3c474;--bad:#ff9aa7;--shadow:0 18px 60px rgba(0,0,0,.28)}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.58 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}a{color:var(--brand);text-underline-offset:3px}button,input,select{font:inherit}button,.button{border:1px solid var(--line);background:var(--surface);color:var(--text);padding:.72rem 1rem;border-radius:12px;cursor:pointer;font-weight:700}.button.primary,button.primary{background:var(--brand);color:#fff;border-color:transparent}.button.ghost{background:transparent}button:hover,.button:hover{transform:translateY(-1px)}:focus-visible{outline:4px solid color-mix(in srgb,var(--brand) 35%,transparent);outline-offset:3px}.skip{position:absolute;left:-999px;top:1rem}.skip:focus{left:1rem;z-index:1000;background:var(--surface);padding:.8rem;border-radius:10px}.wrap{width:min(var(--max),calc(100% - 2rem));margin-inline:auto}.topbar{position:sticky;top:0;z-index:30;background:color-mix(in srgb,var(--bg) 88%,transparent);backdrop-filter:blur(16px);border-bottom:1px solid var(--line)}.topbar .inner{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.7rem 0}.brand{font-weight:850;letter-spacing:-.02em}.nav{display:flex;gap:.35rem;overflow:auto}.nav a{white-space:nowrap;text-decoration:none;color:var(--muted);padding:.5rem .65rem;border-radius:9px}.nav a:hover{background:var(--surface2);color:var(--text)}.actions{display:flex;gap:.45rem}.hero{padding:4.5rem 0 2.5rem}.hero-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:2rem;align-items:center}.eyebrow{font-size:.78rem;text-transform:uppercase;letter-spacing:.13em;font-weight:850;color:var(--brand)}h1,h2,h3{line-height:1.12;letter-spacing:-.03em;margin-top:0}h1{font-size:clamp(2.5rem,6vw,5.2rem);margin-bottom:1rem}h2{font-size:clamp(1.8rem,3vw,2.8rem)}h3{font-size:1.25rem}.lead{font-size:clamp(1.08rem,1.8vw,1.35rem);color:var(--muted);max-width:67ch}.hero-img{width:100%;border-radius:28px;box-shadow:var(--shadow)}.badges{display:flex;flex-wrap:wrap;gap:.6rem;margin:1.25rem 0}.badge{display:inline-flex;align-items:center;gap:.4rem;border:1px solid var(--line);background:var(--surface);padding:.45rem .72rem;border-radius:999px;font-size:.88rem;font-weight:750}.badge.good{color:var(--good)}.badge.warn{color:var(--warn)}.badge.bad{color:var(--bad)}.metric-row{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-top:1.5rem}.metric{background:var(--surface);border:1px solid var(--line);border-radius:18px;padding:1.1rem;box-shadow:var(--shadow)}.metric strong{display:block;font-size:1.8rem;line-height:1.1}.metric span{color:var(--muted);font-size:.9rem}section{padding:3.8rem 0;scroll-margin-top:75px}.section-head{display:flex;justify-content:space-between;align-items:end;gap:1.5rem;margin-bottom:1.5rem}.section-head p{max-width:70ch;color:var(--muted);margin:0}.grid{display:grid;gap:1rem}.grid.two{grid-template-columns:repeat(2,minmax(0,1fr))}.grid.three{grid-template-columns:repeat(3,minmax(0,1fr))}.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);padding:1.25rem;box-shadow:var(--shadow)}.card.flush{padding:0;overflow:hidden}.card img{width:100%;display:block}.card-body{padding:1.25rem}.callout{border-left:5px solid var(--brand);background:var(--surface);padding:1.2rem 1.3rem;border-radius:0 16px 16px 0}.callout.warn{border-color:var(--warn)}.callout.bad{border-color:var(--bad)}.muted{color:var(--muted)}.small{font-size:.88rem}.score-big{font-size:2.7rem;font-weight:900;letter-spacing:-.05em}.progress{height:10px;background:var(--surface2);border-radius:999px;overflow:hidden}.progress>span{display:block;height:100%;background:linear-gradient(90deg,var(--brand),var(--brand2));border-radius:inherit}.category{display:grid;grid-template-columns:minmax(130px,1fr) 2fr auto;gap:.75rem;align-items:center;margin:.6rem 0}.vehicle-card .topline{display:flex;justify-content:space-between;gap:1rem;align-items:start}.rank{width:2.2rem;height:2.2rem;border-radius:50%;display:grid;place-items:center;background:var(--surface2);font-weight:900}.chip{padding:.25rem .5rem;background:var(--surface2);border-radius:8px;font-size:.8rem}.table-wrap{overflow:auto;border:1px solid var(--line);border-radius:16px;background:var(--surface)}table{border-collapse:collapse;width:100%;font-size:.9rem}th,td{text-align:left;padding:.75rem;border-bottom:1px solid var(--line);vertical-align:top}th{position:sticky;top:0;background:var(--surface2);z-index:1}tr:last-child td{border-bottom:0}.status-pass{color:var(--good);font-weight:800}.status-conditional_pass,.status-conditional{color:var(--warn);font-weight:800}.status-fail{color:var(--bad);font-weight:800}.status-not_researched_after_failure{color:var(--muted)}details{border:1px solid var(--line);border-radius:14px;background:var(--surface);margin:.6rem 0}summary{cursor:pointer;font-weight:780;padding:1rem;list-style:none}summary::-webkit-details-marker{display:none}summary:after{content:"+";float:right;color:var(--brand);font-size:1.3rem}details[open] summary:after{content:"−"}.details-body{padding:0 1rem 1rem}.kvs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.6rem}.kv{background:var(--surface2);padding:.75rem;border-radius:10px}.kv b{display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}.toolbar{display:flex;flex-wrap:wrap;gap:.6rem;margin:1rem 0}.toolbar input[type="search"]{min-width:min(100%,360px);flex:1}.input{border:1px solid var(--line);background:var(--surface);color:var(--text);padding:.75rem;border-radius:12px}.slider-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:1rem}.slider{background:var(--surface2);padding:.8rem;border-radius:12px}.slider label{display:flex;justify-content:space-between;font-weight:750}.slider input{width:100%}.slate-item{display:flex;gap:.7rem;align-items:start;padding:.8rem 0;border-bottom:1px solid var(--line)}.slate-item:last-child{border:0}.checklist{white-space:pre-wrap;background:var(--surface2);border-radius:14px;padding:1rem;max-height:520px;overflow:auto}.footer{padding:3rem 0 5rem;border-top:1px solid var(--line);color:var(--muted)}.download-list{columns:2;column-gap:2rem}.download-list a{display:block;break-inside:avoid;padding:.35rem 0}.risk-meter{display:flex;height:12px;border-radius:999px;overflow:hidden;background:var(--surface2)}.risk-meter span{height:100%}.pill-row{display:flex;gap:.5rem;flex-wrap:wrap}.hidden{display:none!important}.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:900px){.hero-grid,.grid.three,.grid.two{grid-template-columns:1fr}.metric-row{grid-template-columns:repeat(2,1fr)}.slider-grid{grid-template-columns:repeat(2,1fr)}.nav{display:none}.category{grid-template-columns:1fr auto}.category .progress{grid-column:1/-1}.download-list{columns:1}}@media(max-width:560px){.wrap{width:min(100% - 1rem,var(--max))}.hero{padding-top:2.4rem}.metric-row{grid-template-columns:1fr}.slider-grid{grid-template-columns:1fr}.actions .label{display:none}.section-head{display:block}.kvs{grid-template-columns:1fr}.topbar .inner{gap:.35rem}.brand{font-size:.9rem}}@media print{.topbar,.toolbar,.explorer-controls,.actions,.no-print{display:none!important}body{background:#fff;color:#111;font-size:11pt}.wrap{width:100%;max-width:none}.card,details,.table-wrap{box-shadow:none;break-inside:avoid}section{padding:1.2rem 0}details{display:block}details>*{display:block!important}.hero{padding-top:.5rem}a{color:#111;text-decoration:none}.hero-img{max-height:240px}h1{font-size:30pt}.download-list{display:none}}
'''
(SITE / "assets/css").mkdir(parents=True, exist_ok=True)
(SITE / "assets/css/app.css").write_text(css, encoding="utf-8")

js = r'''
(() => {
  const dataNode = document.getElementById('report-data');
  const DATA = JSON.parse(dataNode.textContent);
  const $ = (s, c=document) => c.querySelector(s);
  const $$ = (s, c=document) => [...c.querySelectorAll(s)];
  const fmtMoney = n => n == null ? '—' : new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(n);
  const esc = s => String(s ?? '').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  const status = s => `<span class="status-${esc(s)}">${esc(String(s).replaceAll('_',' '))}</span>`;
  const scoreById = Object.fromEntries(DATA.scorecard.vehicles.map(v=>[v.vehicle_id,v]));
  const tcoById = Object.fromEntries(DATA.tco.vehicles.map(v=>[v.vehicle_id,v]));
  const vehicleMeta = DATA.vehicle_metadata;

  // Theme.
  const saved = localStorage.getItem('fvr-theme');
  if(saved === 'dark' || (!saved && matchMedia('(prefers-color-scheme:dark)').matches)) document.body.classList.add('dark');
  $('#theme-toggle').addEventListener('click',()=>{document.body.classList.toggle('dark');localStorage.setItem('fvr-theme',document.body.classList.contains('dark')?'dark':'light')});
  $('#print-button').addEventListener('click',()=>window.print());

  // Hero.
  const rec = DATA.recommendation.current_recommendation;
  $('#hero-title').textContent = rec.vehicle;
  $('#hero-score').textContent = rec.confirmed_score.toFixed(1);
  $('#hero-status').innerHTML = status(rec.eligibility_status);
  $('#hero-risk').textContent = rec.main_compromise;
  $('#metric-candidates').textContent = DATA.candidate_universe.candidates.length;
  $('#metric-claims').textContent = DATA.claims.claims.length;
  $('#metric-sources').textContent = DATA.sources.sources.length;
  $('#metric-sim').textContent = DATA.uncertainty.iterations.toLocaleString();

  // Funnel.
  $('#funnel').innerHTML = [
    ['Universe',DATA.candidate_universe.candidates.length,'Broad gas, hybrid, PHEV and EV set'],
    ['Hard-filtered',DATA.eliminations.eliminations.length,'Stopped after first definitive failure'],
    ['Deep research',DATA.scorecard.vehicles.length,'Standardized dossiers and pricing'],
    ['Finalists',DATA.recommendation.finalists.length,'Plus one live alternate']
  ].map(([a,b,c])=>`<article class="card"><div class="eyebrow">${esc(a)}</div><div class="score-big">${b}</div><p class="muted">${esc(c)}</p></article>`).join('');

  // Context cards.
  $('#context-grid').innerHTML = [
    ['Household','Two adults, two young children, two car seats and a medium dog.'],
    ['Purchase','Used, cash, Q4 2026, ZIP 98038; $80,000 hard vehicle-price ceiling.'],
    ['Driving','8,000 miles/year base, 70% city, occasional Snoqualmie Pass winter travel.'],
    ['Energy','Home Level 2 installed; EV model assumes 90% home and 10% public DC fast charging.'],
    ['Ownership','Ten-year primary horizon with a five-year TCO decision flag.'],
    ['Authority','The client—not the model—chooses the test-drive slate and purchase.']
  ].map(([h,p])=>`<article class="card"><h3>${h}</h3><p class="muted">${p}</p></article>`).join('');

  // Eligibility matrix.
  const reqOrder=['third_row','nhtsa_overall','iihs_award','row2_complete_latch','row3_complete_latch','cargo_behind_row3','awd_or_4wd','price_ceiling','model_year','reliability_exclusion'];
  const reqLabel={third_row:'3rd row',nhtsa_overall:'NHTSA',iihs_award:'IIHS',row2_complete_latch:'R2 LATCH',row3_complete_latch:'R3 LATCH',cargo_behind_row3:'Cargo',awd_or_4wd:'AWD/4WD',price_ceiling:'Price',model_year:'Year',reliability_exclusion:'Reliability'};
  $('#eligibility-head').innerHTML='<tr><th>Vehicle</th><th>Overall</th>'+reqOrder.map(r=>`<th>${reqLabel[r]}</th>`).join('')+'</tr>';
  $('#eligibility-body').innerHTML=DATA.eligibility.vehicles.map(v=>{const m=Object.fromEntries(v.requirements.map(r=>[r.requirement,r]));return `<tr><td><strong>${esc(v.vehicle)}</strong></td><td>${status(v.overall_status)}</td>${reqOrder.map(r=>`<td title="${esc(m[r]?.note||'')}">${status(m[r]?.status||'unknown')}</td>`).join('')}</tr>`}).join('');

  // Finalist and all deep cards.
  const simById=Object.fromEntries(DATA.uncertainty.vehicle_results.map(v=>[v.vehicle_id,v]));
  $('#vehicle-cards').innerHTML=DATA.scorecard.vehicles.map((v,i)=>{
    const meta=vehicleMeta[v.vehicle_id], t=tcoById[v.vehicle_id], sim=simById[v.vehicle_id];
    const cats=v.category_scores.map(c=>`<div class="category"><span>${esc(c.category.replaceAll('_',' '))}</span><div class="progress"><span style="width:${Math.min(100,c.confirmed_points/c.maximum_points*100)}%"></span></div><b>${c.confirmed_points.toFixed(1)}/${c.maximum_points}</b></div>`).join('');
    const components=v.component_scores.map(c=>`<details><summary>${esc(c.component.replaceAll('_',' '))} — ${c.points_awarded?.toFixed(2) ?? 'null'}/${c.maximum_points}</summary><div class="details-body"><div class="kvs"><div class="kv"><b>Input</b>${esc(typeof c.input_value==='object'?JSON.stringify(c.input_value):c.input_value)} ${esc(c.unit||'')}</div><div class="kv"><b>Confidence</b>${esc(c.evidence_confidence)}</div><div class="kv"><b>Rule</b>${esc(c.exact_scoring_rule)}</div><div class="kv"><b>Calculation</b>${esc(c.calculation)}</div><div class="kv"><b>Claim IDs</b>${c.claim_ids.map(id=>`<code>${esc(id)}</code>`).join(' ')}</div><div class="kv"><b>Score ID</b><code>${esc(c.score_id)}</code></div></div></div></details>`).join('');
    return `<article class="card flush vehicle-card" id="card-${esc(v.vehicle_id)}"><img src="${esc(DATA.image_map[v.vehicle_id])}" alt="Original neutral illustration of ${esc(v.vehicle)}"><div class="card-body"><div class="topline"><div><div class="eyebrow">Rank ${i+1} · ${esc(v.interpretation)}</div><h3>${esc(v.vehicle)}</h3></div><div class="rank">${i+1}</div></div><div class="badges"><span class="badge">${status(v.eligibility_gate)}</span><span class="badge"><strong>${v.confirmed_points.toFixed(1)}</strong>/100</span><span class="badge">5y ${fmtMoney(t.scenarios['5_year'].base.total_tco)}</span><span class="badge">10y ${fmtMoney(t.scenarios['10_year'].base.total_tco)}</span></div><p><strong>Advance case:</strong> ${esc(meta.advance_reason)}</p><p class="muted"><strong>Primary risk:</strong> ${esc(meta.major_concern)}</p><p class="small"><strong>Modeled rank-1 probability:</strong> ${(sim.probability_rank_1*100).toFixed(1)}% · <strong>90% score range:</strong> ${sim.p05.toFixed(1)}–${sim.p95.toFixed(1)}</p>${cats}<details><summary>Expand every scoring component and provenance</summary><div class="details-body">${components}</div></details><details><summary>Adversarial regret case and physical unknowns</summary><div class="details-body"><p><strong>Five-year regret case:</strong> ${esc(meta.regret_case)}</p><ul>${meta.physical_unknowns.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div></details></div></article>`;
  }).join('');

  // TCO table.
  $('#tco-body').innerHTML=DATA.tco.vehicles.map(v=>{const s=v.scenarios;return `<tr><td><strong>${esc(v.vehicle)}</strong><br><span class="small muted">Energy ${fmtMoney(v.annual_energy_cost_base)}/yr</span></td><td>${fmtMoney(s['5_year'].low.total_tco)}</td><td><strong>${fmtMoney(s['5_year'].base.total_tco)}</strong></td><td>${fmtMoney(s['5_year'].high.total_tco)}</td><td>${fmtMoney(s['10_year'].low.total_tco)}</td><td><strong>${fmtMoney(s['10_year'].base.total_tco)}</strong></td><td>${fmtMoney(s['10_year'].high.total_tco)}</td></tr>`}).join('');

  // Price evidence.
  $('#price-cards').innerHTML=DATA.price_summaries.map(ps=>`<article class="card"><h3>${esc(ps.vehicle)}</h3><div class="kvs"><div class="kv"><b>Official scoring price</b>${fmtMoney(ps.official_scoring_price)}</div><div class="kv"><b>Planning range</b>${fmtMoney(ps.low)}–${fmtMoney(ps.high)}</div><div class="kv"><b>Base OTD planning</b>${fmtMoney(ps.estimated_out_the_door.base)}</div><div class="kv"><b>Confidence</b>${esc(ps.confidence)}</div></div><p class="small muted">${esc(ps.otd_note)}</p>${ps.listings.map(p=>`<details><summary>${esc(p.seller_name)} · ${fmtMoney(p.listed_price)} · ${p.mileage==null?'mileage unavailable':p.mileage.toLocaleString()+' mi'}</summary><div class="details-body"><p><a href="${esc(p.source_url)}" target="_blank" rel="noopener">Open exact listing</a></p><div class="kvs"><div class="kv"><b>Location</b>${esc(p.seller_location)}</div><div class="kv"><b>Status at retrieval</b>${esc(p.listing_status_at_retrieval)}</div><div class="kv"><b>VIN / stock</b>${esc(p.vin||p.stock_number||'not provided')}</div><div class="kv"><b>Retrieved</b>${esc(p.retrieved_at)}</div><div class="kv"><b>Adjustments</b>${esc(JSON.stringify(p.normalization_adjustments||[]))}</div><div class="kv"><b>Price record</b>${esc(p.price_record_id)}</div></div></div></details>`).join('')}</article>`).join('');

  // Explorer sliders.
  const officialWeights=DATA.sensitivity.weight_presets.official;
  const categories=Object.keys(officialWeights);
  const sliderRoot=$('#slider-grid');
  sliderRoot.innerHTML=categories.map(c=>`<div class="slider"><label for="w-${c}"><span>${esc(c.replaceAll('_',' '))}</span><output id="o-${c}">${officialWeights[c]}</output></label><input id="w-${c}" data-cat="${c}" type="range" min="0" max="40" step="0.5" value="${officialWeights[c]}"></div>`).join('');
  function applyWeights(weights){categories.forEach(c=>{$(`#w-${c}`).value=weights[c];$(`#o-${c}`).textContent=weights[c]});updateExplorer()}
  function updateExplorer(){
    const raw=Object.fromEntries(categories.map(c=>[c,Number($(`#w-${c}`).value)]));
    const total=Object.values(raw).reduce((a,b)=>a+b,0)||1;
    $('#weight-total').textContent=total.toFixed(1);
    const rows=DATA.scorecard.vehicles.map(v=>{const cm=Object.fromEntries(v.category_scores.map(c=>[c.category,c]));const s=categories.reduce((sum,c)=>sum+(cm[c].confirmed_points/cm[c].maximum_points)*(raw[c]/total*100),0);return {id:v.vehicle_id,name:v.vehicle,score:s}}).sort((a,b)=>b.score-a.score);
    $('#explorer-body').innerHTML=rows.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.name)}</td><td><strong>${r.score.toFixed(1)}</strong></td></tr>`).join('');
  }
  sliderRoot.addEventListener('input',e=>{if(e.target.matches('input[type=range]')){$(`#o-${e.target.dataset.cat}`).textContent=e.target.value;updateExplorer()}});
  $('#preset-buttons').innerHTML=Object.keys(DATA.sensitivity.weight_presets).map(n=>`<button data-preset="${n}">${esc(n.replaceAll('_',' '))}</button>`).join('');
  $('#preset-buttons').addEventListener('click',e=>{const b=e.target.closest('[data-preset]');if(b)applyWeights(DATA.sensitivity.weight_presets[b.dataset.preset])});
  $('#reset-weights').addEventListener('click',()=>applyWeights(officialWeights));
  updateExplorer();

  // Contradictions, corrections and reversals.
  $('#gaps').innerHTML=[...DATA.contradictions.contradictions.map(c=>({id:c.contradiction_id,title:c.vehicle_and_topic,text:`${c.source_a_and_value} vs ${c.source_b_and_value}. Resolution: ${c.resolution_rule}. Impact: ${c.impact}`})),...DATA.corrections.corrections.map(c=>({id:c.correction_id,title:'Correction',text:`${c.original_claim} → ${c.corrected_claim} ${c.scoring_or_eligibility_impact}`}))].map(x=>`<details><summary>${esc(x.id)} · ${esc(x.title)}</summary><div class="details-body"><p>${esc(x.text)}</p></div></details>`).join('');
  $('#reversal-list').innerHTML=DATA.recommendation.recommendation_reversal_conditions.map(x=>`<li>${esc(x)}</li>`).join('');

  // Eliminations.
  $('#elimination-list').innerHTML=DATA.eliminations.eliminations.map(e=>`<details><summary>${esc((DATA.eligibility.vehicles.find(v=>v.vehicle_id===e.vehicle_id)||{}).vehicle||e.vehicle_id)} — ${esc(e.failed_requirement)}</summary><div class="details-body"><p>${esc(e.reason)}</p><p class="small"><strong>Claim:</strong> <code>${esc(e.claim_id)}</code> · <strong>Sources:</strong> ${(e.source_ids||[]).map(id=>`<code>${esc(id)}</code>`).join(' ')}</p></div></details>`).join('');

  // Slate controls.
  const slateIds=DATA.recommendation.test_drive_slate;
  const savedSlate=JSON.parse(localStorage.getItem('fvr-slate')||'{}');
  $('#slate').innerHTML=slateIds.map((id,i)=>`<label class="slate-item"><input type="checkbox" data-slate="${esc(id)}" ${savedSlate[id]===false?'':'checked'}><span><strong>${i+1}. ${esc(vehicleMeta[id].short_name)}</strong><br><span class="muted">${esc(vehicleMeta[id].configuration_condition)}</span></span></label>`).join('');
  $('#slate').addEventListener('change',()=>{const out={};$$('[data-slate]').forEach(x=>out[x.dataset.slate]=x.checked);localStorage.setItem('fvr-slate',JSON.stringify(out))});

  // Checklist.
  $('#checklist-text').textContent=DATA.checklists.test_drive;
  $('#copy-checklist').addEventListener('click',async()=>{await navigator.clipboard.writeText(DATA.checklists.test_drive);$('#copy-checklist').textContent='Copied';setTimeout(()=>$('#copy-checklist').textContent='Copy checklist',1500)});

  // Claims search.
  function renderClaims(q=''){
    q=q.toLowerCase();const rows=DATA.claims.claims.filter(c=>!q||JSON.stringify(c).toLowerCase().includes(q)).slice(0,200);
    $('#claim-count').textContent=`${rows.length}${rows.length===200?' shown':''} / ${DATA.claims.claims.length}`;
    $('#claims-body').innerHTML=rows.map(c=>`<tr><td><code>${esc(c.claim_id)}</code></td><td>${esc(c.vehicle_id||'global')}</td><td>${esc(c.field_or_topic)}</td><td>${esc(typeof c.display_value==='object'?JSON.stringify(c.display_value):c.display_value)}</td><td>${status(c.status)}</td><td>${esc(c.confidence)}</td><td>${c.source_ids.map(id=>`<code>${esc(id)}</code>`).join(' ')||c.human_observation_ids?.map(id=>`<code>${esc(id)}</code>`).join(' ')||'—'}</td></tr>`).join('');
  }
  $('#claim-search').addEventListener('input',e=>renderClaims(e.target.value));renderClaims();

  // Sources search.
  function renderSources(q=''){
    q=q.toLowerCase();const rows=DATA.sources.sources.filter(s=>!q||JSON.stringify(s).toLowerCase().includes(q)).slice(0,200);
    $('#source-count').textContent=`${rows.length} / ${DATA.sources.sources.length}`;
    $('#sources-body').innerHTML=rows.map(s=>`<tr><td><code>${esc(s.source_id)}</code></td><td><a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.title)}</a><br><span class="small muted">${esc(s.publisher_or_organization)}</span></td><td>${s.authority_tier}</td><td>${esc(s.model_year_and_trim_applicability||'—')}</td><td>${esc(s.access_date)}</td><td>${esc(s.notes_on_limitations)}</td></tr>`).join('');
  }
  $('#source-search').addEventListener('input',e=>renderSources(e.target.value));renderSources();

  // Decision ledger.
  $('#ledger').innerHTML=DATA.decision_ledger.decisions.map(d=>`<details><summary>${esc(d.decision_id)} · ${esc(d.step)} — ${esc(d.decision)}</summary><div class="details-body"><p>${esc(d.concise_rationale)}</p><p><strong>Reversible:</strong> ${d.reversible?'Yes':'No'} ${d.reversal_conditions?`· <strong>Conditions:</strong> ${esc(d.reversal_conditions)}`:''}</p><p class="small"><strong>Inputs:</strong> ${(d.input_claim_ids_or_score_ids||[]).map(x=>`<code>${esc(x)}</code>`).join(' ')||'—'}</p></div></details>`).join('');

  // Downloads. Text files use embedded blobs so standalone HTML remains useful.
  const textMap=DATA.embedded_text_downloads||{};
  $('#downloads').innerHTML=(DATA.download_artifacts||[]).map(x=>`<a href="${esc(x.href)}" data-embedded-name="${esc(x.name)}" download>${esc(x.name)}</a>`).join('') + '<a href="../family-vehicle-site.zip" class="zip-link">Complete site ZIP</a><a href="../family-vehicle-analysis-package.zip" class="zip-link">Complete analysis package ZIP</a>';
  $('#downloads').addEventListener('click',e=>{const a=e.target.closest('[data-embedded-name]');if(!a||!textMap[a.dataset.embeddedName])return;e.preventDefault();const blob=new Blob([textMap[a.dataset.embeddedName]],{type:'text/plain;charset=utf-8'});const u=URL.createObjectURL(blob);const t=document.createElement('a');t.href=u;t.download=a.dataset.embeddedName.split('/').pop();t.click();setTimeout(()=>URL.revokeObjectURL(u),500)});

  // Method metadata.
  $('#method-meta').innerHTML=`<div class="kvs"><div class="kv"><b>Run ID</b>${esc(DATA.manifest.run_id)}</div><div class="kv"><b>Scoring version/hash</b>${esc(DATA.scorecard.scoring_config_version)} · ${esc(DATA.scorecard.scoring_config_sha256.slice(0,16))}…</div><div class="kv"><b>Independent lock</b>${esc(DATA.manifest.independent_recommendation_lock_timestamp_utc)}</div><div class="kv"><b>Manual consulted</b>${DATA.manifest.prior_human_research_consulted?'After lock':'No'}</div><div class="kv"><b>Queries / sources / claims</b>${DATA.query_log.queries.length} / ${DATA.sources.sources.length} / ${DATA.claims.claims.length}</div><div class="kv"><b>Simulation</b>${DATA.uncertainty.iterations.toLocaleString()} iterations · seed ${DATA.uncertainty.seed}</div></div>`;
})();
'''
(SITE / "assets/js").mkdir(parents=True, exist_ok=True)
(SITE / "assets/js/app.js").write_text(js, encoding="utf-8")

html_template = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Evidence-first family vehicle decision report"><title>Family Vehicle Decision Report</title>CSS_LINK</head><body><a class="skip" href="#main">Skip to content</a><header class="topbar"><div class="wrap inner"><div class="brand">Evidence-First Vehicle Decision</div><nav class="nav" aria-label="Report sections"><a href="#decision">Decision</a><a href="#method">Method</a><a href="#eligibility">Eligibility</a><a href="#vehicles">Vehicles</a><a href="#cost">Cost</a><a href="#explore">Explore</a><a href="#evidence">Evidence</a><a href="#downloads-section">Downloads</a></nav><div class="actions"><button id="theme-toggle" aria-label="Toggle dark mode">◐ <span class="label">Theme</span></button><button id="print-button" aria-label="Print report">⌘ <span class="label">Print</span></button></div></div></header><main id="main">
<section class="hero" id="decision"><div class="wrap hero-grid"><div><div class="eyebrow">Current evidence-based recommendation · conditional</div><h1 id="hero-title"></h1><p class="lead">First vehicle to test, not authorization to buy. The internet result remains subordinate to build date, VIN campaigns, battery/charging, child-seat fit, cargo, insurance and inspection.</p><div class="badges"><span class="badge"><span id="hero-status"></span></span><span class="badge good"><strong id="hero-score"></strong>/100 frozen score</span><span class="badge warn">Risk-averse preset reverses leader</span></div><div class="callout warn"><strong>Primary risk:</strong> <span id="hero-risk"></span></div><div class="metric-row"><div class="metric"><strong id="metric-candidates"></strong><span>candidates screened</span></div><div class="metric"><strong id="metric-claims"></strong><span>traceable claims</span></div><div class="metric"><strong id="metric-sources"></strong><span>registered sources</span></div><div class="metric"><strong id="metric-sim"></strong><span>uncertainty runs</span></div></div></div><img class="hero-img" src="HERO_IMAGE" alt="Diagram connecting decision to score, rule, claim and source"></div></section>
<section id="method"><div class="wrap"><div class="section-head"><div><div class="eyebrow">What this is—and is not</div><h2>Auditable research, not a purchase command</h2></div><p>Exact-year binary gates come first. Only qualifying configurations receive a score. Deterministic code handles arithmetic, interpolation, TCO, sorting and simulation.</p></div><div class="grid three" id="context-grid"></div><div class="grid four metric-row" id="funnel"></div><div class="callout" style="margin-top:1rem">Traceability chain: <strong>Decision → score → rule → input → claim → source → query or human observation.</strong> The supplied manual research was opened only after the independent recommendation was hashed and locked.</div></div></section>
<section id="eligibility"><div class="wrap"><div class="section-head"><div><div class="eyebrow">Hard gate</div><h2>Requirements pass/fail matrix</h2></div><p>A single definitive failure stops expensive research. “Not researched after failure” is deliberate, not missing diligence.</p></div><div class="table-wrap"><table><thead id="eligibility-head"></thead><tbody id="eligibility-body"></tbody></table></div></div></section>
<section id="vehicles"><div class="wrap"><div class="section-head"><div><div class="eyebrow">Official frozen model</div><h2>Deep-researched configurations</h2></div><p>Each component expands to its exact input, rule, calculation, claim IDs and confidence.</p></div><div class="grid two" id="vehicle-cards"></div></div></section>
<section id="cost"><div class="wrap"><div class="section-head"><div><div class="eyebrow">Ownership economics</div><h2>Five- and ten-year TCO</h2></div><p>Includes acquisition, tax, modeled fees, energy, maintenance, repair, tires, registration/RTA allowance and residual value. Insurance is intentionally separate.</p></div><div class="table-wrap"><table><thead><tr><th>Vehicle</th><th>5y low</th><th>5y base</th><th>5y high</th><th>10y low</th><th>10y base</th><th>10y high</th></tr></thead><tbody id="tco-body"></tbody></table></div><div class="section-head" style="margin-top:3rem"><div><div class="eyebrow">Price transparency</div><h2>Direct listing evidence</h2></div><p>Every official acquisition score references price records and direct listing URLs. Sold or unavailable examples are clearly labeled.</p></div><div class="grid two" id="price-cards"></div></div></section>
<section id="explore"><div class="wrap"><div class="section-head"><div><div class="eyebrow">Exploratory only</div><h2>Priority sliders and reversal thresholds</h2></div><p>These controls do not alter the official score or locked recommendation. Weights are normalized to 100 for exploration.</p></div><div class="card explorer-controls"><div class="toolbar" id="preset-buttons"></div><button id="reset-weights" class="primary">Reset to official weights</button><p class="small muted">Raw slider total: <strong id="weight-total"></strong>; normalized automatically.</p><div class="slider-grid" id="slider-grid"></div></div><div class="table-wrap" style="margin-top:1rem"><table><thead><tr><th>Exploratory rank</th><th>Vehicle</th><th>Normalized score</th></tr></thead><tbody id="explorer-body"></tbody></table></div><div class="grid two" style="margin-top:1rem"><div class="card"><h3>What changes the recommendation</h3><ul id="reversal-list"></ul></div><div class="card"><h3>Contradictions and evidence gaps</h3><div id="gaps"></div></div></div></div></section>
<section id="eliminations"><div class="wrap"><div class="section-head"><div><div class="eyebrow">Stopped at the gate</div><h2>Why vehicles were eliminated</h2></div><p>Elimination means mismatch with this configuration—not a judgment that the vehicle is universally bad.</p></div><div id="elimination-list"></div></div></section>
<section id="test-drive"><div class="wrap"><div class="section-head"><div><div class="eyebrow">Client authority</div><h2>Choose the test-drive slate</h2></div><p>Selections are saved locally in the browser. Physical observations must be recorded separately before they alter a decision.</p></div><div class="grid two"><div class="card"><h3>Recommended slate</h3><div id="slate"></div></div><div class="card"><div class="toolbar"><button id="copy-checklist" class="primary">Copy checklist</button><button onclick="window.print()">Print</button></div><pre class="checklist" id="checklist-text"></pre></div></div></div></section>
<section id="evidence"><div class="wrap"><div class="section-head"><div><div class="eyebrow">Audit trail</div><h2>Search claims, sources and decisions</h2></div><p>Core conclusions remain visible above; these registries support detailed verification.</p></div><div class="card"><h3>Claim registry <span class="small muted" id="claim-count"></span></h3><div class="toolbar"><label class="sr-only" for="claim-search">Search claims</label><input class="input" id="claim-search" type="search" placeholder="Search claim ID, vehicle, field, value or source…"></div><div class="table-wrap"><table><thead><tr><th>Claim</th><th>Vehicle</th><th>Field</th><th>Value</th><th>Status</th><th>Confidence</th><th>Sources / observations</th></tr></thead><tbody id="claims-body"></tbody></table></div></div><div class="card" style="margin-top:1rem"><h3>Source registry <span class="small muted" id="source-count"></span></h3><div class="toolbar"><label class="sr-only" for="source-search">Search sources</label><input class="input" id="source-search" type="search" placeholder="Search title, publisher, vehicle, tier or limitation…"></div><div class="table-wrap"><table><thead><tr><th>ID</th><th>Source</th><th>Tier</th><th>Applicability</th><th>Accessed</th><th>Limitations</th></tr></thead><tbody id="sources-body"></tbody></table></div></div><div class="card" style="margin-top:1rem"><h3>Decision ledger</h3><div id="ledger"></div></div></div></section>
<section id="downloads-section"><div class="wrap"><div class="section-head"><div><div class="eyebrow">Machine-readable package</div><h2>Download center</h2></div><p>The standalone HTML embeds text artifacts for viewing and export. ZIP links work when companion files are distributed alongside it.</p></div><div class="card"><div class="download-list" id="downloads"></div></div></div></section>
<section id="methodology"><div class="wrap"><div class="section-head"><div><div class="eyebrow">Version and provenance</div><h2>Methodology metadata</h2></div><p>Current listings and other time-sensitive facts must be refreshed before a Q4 2026 transaction.</p></div><div class="card" id="method-meta"></div><div class="card" style="margin-top:1rem"><h3>Image attribution</h3><p>All vehicle and evidence-chain images are original neutral SVG illustrations generated for this report. No manufacturer photography or trademarks are embedded.</p></div></div></section>
</main><footer class="footer"><div class="wrap"><strong>Evidence-first family vehicle research</strong><p>This report is conditional. VIN, build date, recalls, service history, child-seat fit, cargo, comfort, insurance, transaction price and physical inspection can override it.</p></div></footer>DATA_SCRIPTJS_LINK</body></html>'''

data_json = json.dumps(report_data, ensure_ascii=False).replace("</", "<\\/")
index_html = html_template.replace("HERO_IMAGE", "assets/images/evidence-chain.svg").replace("CSS_LINK", '<link rel="stylesheet" href="assets/css/app.css">').replace("DATA_SCRIPT", f'<script id="report-data" type="application/json">{data_json}</script>').replace("JS_LINK", '<script src="assets/js/app.js"></script>')
(SITE / "index.html").write_text(index_html, encoding="utf-8")

# Embed every SVG as a data URI in the standalone report so the single HTML file renders without companion assets.
self_data = json.loads(json.dumps(report_data))
for vehicle_id, rel_path in list(self_data["image_map"].items()):
    svg_bytes = (SITE / rel_path).read_bytes()
    self_data["image_map"][vehicle_id] = "data:image/svg+xml;base64," + base64.b64encode(svg_bytes).decode("ascii")
hero_uri = "data:image/svg+xml;base64," + base64.b64encode((images_dir / "evidence-chain.svg").read_bytes()).decode("ascii")
self_data_json = json.dumps(self_data, ensure_ascii=False).replace("</", "<\\/")
self_contained = html_template.replace("HERO_IMAGE", hero_uri).replace("CSS_LINK", f"<style>{css}</style>").replace("DATA_SCRIPT", f'<script id="report-data" type="application/json">{self_data_json}</script>').replace("JS_LINK", f"<script>{js}</script>")
(ROOT / "reports/client-report-self-contained.html").write_text(self_contained, encoding="utf-8")

print(f"Generated {len(DEEP_VEHICLES)} dossiers, narrative reports, checklists and local site.")
print(f"Editable site: {SITE/'index.html'}")
print(f"Standalone HTML: {ROOT/'reports/client-report-self-contained.html'}")
