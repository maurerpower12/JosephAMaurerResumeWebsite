from __future__ import annotations

import hashlib
import json
import math
import random
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from project_data import DEEP_VEHICLES, GLOBAL_ASSUMPTIONS, RUN_DATE, RUN_ID

ROOT = Path(__file__).resolve().parents[1]
ROUND = 1


def load_json(rel: str) -> Any:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def write_json(rel: str, data: Any) -> None:
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def confidence_min(values: Iterable[str]) -> str:
    order = {"high": 3, "medium": 2, "low": 1, "unknown": 0}
    vals = list(values)
    if not vals:
        return "unknown"
    return min(vals, key=lambda x: order.get(x, 0))


def interpolate(value: float, anchors: list[dict[str, Any]], x_key: str, y_key: str) -> float:
    """Piecewise linear interpolation with endpoint clamping."""
    ordered = sorted(anchors, key=lambda a: float(a[x_key]))
    if value <= float(ordered[0][x_key]):
        return float(ordered[0][y_key])
    if value >= float(ordered[-1][x_key]):
        return float(ordered[-1][y_key])
    for left, right in zip(ordered, ordered[1:]):
        x0, x1 = float(left[x_key]), float(right[x_key])
        if x0 <= value <= x1:
            y0, y1 = float(left[y_key]), float(right[y_key])
            return y0 + (value - x0) * (y1 - y0) / (x1 - x0)
    raise ValueError(f"Value {value} not covered by anchors")


def score_interpretation(total: float) -> str:
    if total >= 90:
        return "Exceptional fit"
    if total >= 80:
        return "Excellent fit"
    if total >= 70:
        return "Strong fit"
    if total >= 60:
        return "Viable with meaningful compromises"
    return "Weak fit for this family"


SCORING = load_json("config/scoring-config.json")
CLAIMS_DOC = load_json("evidence/claims.json")
CLAIMS = {c["claim_id"]: c for c in CLAIMS_DOC["claims"]}
CLAIM_MAP = load_json("analysis/claim-map.json")["mapping"]
ELIGIBILITY = load_json("analysis/eligibility.json")
PRICE_RECORDS_DOC = load_json("evidence/price-records.json")
PRICE_RECORDS = {p["price_record_id"]: p for p in PRICE_RECORDS_DOC["price_records"]}


def claim_id(vehicle_id: str | None, topic: str) -> str:
    key = f"{vehicle_id}::{topic}" if vehicle_id else f"GLOBAL::{topic}"
    if key in CLAIM_MAP:
        return CLAIM_MAP[key]
    # Global assumptions were generated without claim-map aliases.
    for c in CLAIMS.values():
        if c.get("vehicle_id") == vehicle_id and c.get("field_or_topic") == topic:
            return c["claim_id"]
    raise KeyError(f"Missing claim mapping for {key}")


def claim_confidence(ids: list[str]) -> str:
    return confidence_min(CLAIMS[cid].get("confidence", "unknown") for cid in ids)


def make_component(
    *,
    score_id: str,
    category: str,
    component: str,
    maximum_points: float,
    input_value: Any,
    unit: str | None,
    claim_ids: list[str],
    rule: str,
    calculation: str,
    points: float | None,
    missing: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "score_id": score_id,
        "category": category,
        "component": component,
        "maximum_points": maximum_points,
        "input_value": input_value,
        "unit": unit,
        "claim_ids": claim_ids,
        "human_observation_ids": [],
        "exact_scoring_rule": rule,
        "calculation": calculation,
        "points_awarded": None if points is None else round(points, 4),
        "evidence_confidence": claim_confidence(claim_ids) if claim_ids else "unknown",
        "missing_or_conflicting_inputs": missing or [],
    }


score_counter = 0


def next_score_id() -> str:
    global score_counter
    score_counter += 1
    return f"SCR-{score_counter:04d}"


def annual_energy_cost(vehicle: dict[str, Any], *, annual_miles: float | None = None, price_multiplier: float = 1.0) -> tuple[float, dict[str, Any], list[str]]:
    annual_miles = float(annual_miles if annual_miles is not None else GLOBAL_ASSUMPTIONS["annual_miles"])
    city = GLOBAL_ASSUMPTIONS["city_share"]
    highway = GLOBAL_ASSUMPTIONS["highway_share"]
    if vehicle["powertrain"] == "electric":
        kwh100 = float(vehicle["energy"]["kwh_per_100mi"])
        wall_kwh = annual_miles * kwh100 / 100 / GLOBAL_ASSUMPTIONS["ev_wall_to_wheels_efficiency"]
        blended_rate = (
            GLOBAL_ASSUMPTIONS["ev_home_share"] * GLOBAL_ASSUMPTIONS["home_electricity_per_kwh"]
            + GLOBAL_ASSUMPTIONS["ev_public_share"] * GLOBAL_ASSUMPTIONS["public_dcfc_per_kwh"]
        ) * price_multiplier
        cost = wall_kwh * blended_rate
        details = {
            "formula": "annual_miles * kWh_per_100mi / 100 / charging_efficiency * blended_electric_rate",
            "annual_miles": annual_miles,
            "kwh_per_100mi": kwh100,
            "wall_kwh": wall_kwh,
            "home_share": GLOBAL_ASSUMPTIONS["ev_home_share"],
            "public_share": GLOBAL_ASSUMPTIONS["ev_public_share"],
            "blended_rate_per_kwh": blended_rate,
        }
        ids = [
            claim_id(vehicle["vehicle_id"], "scoring.energy.kwh_per_100mi"),
            claim_id(None, "tco.annual_miles"),
            claim_id(None, "tco.ev_home_share"),
            claim_id(None, "tco.ev_public_share"),
            claim_id(None, "tco.home_electricity_per_kwh"),
            claim_id(None, "tco.public_dcfc_per_kwh"),
            claim_id(None, "tco.ev_charging_efficiency"),
        ]
        return cost, details, ids

    city_mpg = float(vehicle["energy"]["city_mpg"])
    highway_mpg = float(vehicle["energy"]["highway_mpg"])
    gallons = annual_miles * city / city_mpg + annual_miles * highway / highway_mpg
    gas_price = GLOBAL_ASSUMPTIONS["gas_price_per_gallon"] * price_multiplier
    cost = gallons * gas_price
    details = {
        "formula": "annual_miles * city_share / city_mpg + annual_miles * highway_share / highway_mpg, multiplied by gas price",
        "annual_miles": annual_miles,
        "city_share": city,
        "highway_share": highway,
        "city_mpg": city_mpg,
        "highway_mpg": highway_mpg,
        "annual_gallons": gallons,
        "gas_price_per_gallon": gas_price,
    }
    ids = [
        claim_id(vehicle["vehicle_id"], "scoring.energy.city_mpg"),
        claim_id(vehicle["vehicle_id"], "scoring.energy.highway_mpg"),
        claim_id(None, "tco.annual_miles"),
        claim_id(None, "tco.city_share"),
        claim_id(None, "tco.highway_share"),
        claim_id(None, "tco.gas_price_per_gallon"),
    ]
    return cost, details, ids


def tco_scenario(vehicle: dict[str, Any], years: int, scenario: str) -> dict[str, Any]:
    t = vehicle["tco_inputs"]
    p = vehicle["price"]
    if scenario == "low":
        price = float(p["low"])
        miles = GLOBAL_ASSUMPTIONS["annual_miles_low"]
        energy_mult = 0.85
        maintenance_mult = 0.80
        repair_mult = 0.80
        tire_mult = 0.80
        residual_mult = 1.20
    elif scenario == "high":
        price = float(p["high"])
        miles = GLOBAL_ASSUMPTIONS["annual_miles_high"]
        energy_mult = 1.25
        maintenance_mult = 1.15
        repair_mult = 1.50
        tire_mult = 1.15
        residual_mult = 0.80
    else:
        price = float(p["base"])
        miles = GLOBAL_ASSUMPTIONS["annual_miles"]
        energy_mult = maintenance_mult = repair_mult = tire_mult = residual_mult = 1.0

    annual_energy, energy_details, energy_claim_ids = annual_energy_cost(vehicle, annual_miles=miles, price_multiplier=energy_mult)
    maintenance = float(t[f"maintenance_{years}"]) * maintenance_mult
    repairs = float(t[f"repairs_{years}"]) * repair_mult
    tires = float(t[f"tires_{years}"]) * tire_mult
    registration = float(t[f"registration_{years}"])
    initial_fees = float(t["initial_fees"])
    sales_tax = price * GLOBAL_ASSUMPTIONS["sales_tax_rate"]
    residual_fraction = min(0.95, max(0.0, float(t[f"residual_{years}"]) * residual_mult))
    residual_value = price * residual_fraction
    total = price + sales_tax + initial_fees + annual_energy * years + maintenance + repairs + tires + registration - residual_value

    input_claim_ids = [
        claim_id(vehicle["vehicle_id"], f"market_price.{scenario if scenario in ('low', 'high') else 'base'}"),
        claim_id(None, "tco.sales_tax_rate"),
        claim_id(vehicle["vehicle_id"], f"tco.maintenance_{years}"),
        claim_id(vehicle["vehicle_id"], f"tco.repairs_{years}"),
        claim_id(vehicle["vehicle_id"], f"tco.tires_{years}"),
        claim_id(vehicle["vehicle_id"], f"tco.registration_{years}"),
        claim_id(vehicle["vehicle_id"], "tco.initial_fees"),
        claim_id(vehicle["vehicle_id"], f"tco.residual_{years}"),
        *energy_claim_ids,
    ]
    return {
        "scenario": scenario,
        "years": years,
        "total_tco": round(total, 2),
        "formula": "purchase_price + sales_tax + initial_fees + energy + maintenance + repairs + tires + registration - residual_value",
        "components": {
            "purchase_price": round(price, 2),
            "sales_tax": round(sales_tax, 2),
            "initial_fees": round(initial_fees, 2),
            "energy": round(annual_energy * years, 2),
            "maintenance": round(maintenance, 2),
            "repairs": round(repairs, 2),
            "tires_and_consumables": round(tires, 2),
            "registration_and_RTA_planning_allowance": round(registration, 2),
            "residual_value_credit": round(residual_value, 2),
            "insurance": None,
        },
        "energy_details": energy_details,
        "scenario_multipliers": {
            "annual_miles": miles,
            "energy_price": energy_mult,
            "maintenance": maintenance_mult,
            "repairs": repair_mult,
            "tires": tire_mult,
            "residual_fraction": residual_mult,
        },
        "input_claim_ids": sorted(set(input_claim_ids)),
        "price_record_ids": vehicle["price"]["price_record_ids"],
        "confidence": confidence_min([claim_confidence(input_claim_ids), vehicle["price"]["confidence"]]),
        "insurance_note": "Excluded from numeric TCO because comparable household quotes were not supplied.",
    }


def build_tco_model() -> dict[str, Any]:
    vehicles = []
    for vehicle_id, raw in DEEP_VEHICLES.items():
        vehicle = {"vehicle_id": vehicle_id, **raw}
        scenarios: dict[str, dict[str, Any]] = {"5_year": {}, "10_year": {}}
        for years in (5, 10):
            for scenario in ("low", "base", "high"):
                scenarios[f"{years}_year"][scenario] = tco_scenario(vehicle, years, scenario)
        annual_base, annual_details, annual_claim_ids = annual_energy_cost(vehicle)
        vehicles.append({
            "vehicle_id": vehicle_id,
            "vehicle": raw["short_name"],
            "price_record_ids": raw["price"]["price_record_ids"],
            "annual_energy_cost_base": round(annual_base, 2),
            "annual_energy_details": annual_details,
            "annual_energy_claim_ids": annual_claim_ids,
            "scenarios": scenarios,
            "qualitative_insurance_risk": "Obtain VIN-specific quotes before purchase; insurance is excluded from numeric comparisons.",
            "remaining_warranty_note": "Verify original in-service date, transferable coverage, CPO terms and campaign completion on the exact VIN.",
        })
    return {
        "schema_version": "1.0",
        "run_id": RUN_ID,
        "model_version": "1.0-used-vehicle-planning",
        "formula": "TCO = acquisition price + sales tax + initial fees + energy + maintenance + repairs + tires/consumables + registration/RTA allowance - residual value. Insurance excluded without actual comparable quotes.",
        "global_assumptions": {
            **GLOBAL_ASSUMPTIONS,
            "claim_ids": [cid for cid, c in CLAIMS.items() if c.get("vehicle_id") is None and c.get("field_or_topic", "").startswith("tco.")],
            "insurance_included": False,
            "exact_address_RTA_status": "unresolved",
        },
        "scenario_definition": {
            "low": "Low observed purchase price; 6,000 miles/year; energy prices -15%; maintenance, repairs and tires -20%; residual fraction +20%.",
            "base": "Normalized acquisition price; 8,000 miles/year; base energy, maintenance, repair and depreciation assumptions.",
            "high": "High observed purchase price; 9,000 miles/year; energy prices +25%; maintenance +15%; repairs +50%; tires +15%; residual fraction -20%.",
        },
        "vehicles": vehicles,
    }


TCO_MODEL = build_tco_model()
TCO_BY_ID = {v["vehicle_id"]: v for v in TCO_MODEL["vehicles"]}


def score_vehicle(vehicle_id: str, raw: dict[str, Any]) -> dict[str, Any]:
    cfg = SCORING["scoring"]
    components: list[dict[str, Any]] = []
    category_raw: dict[str, float] = defaultdict(float)

    def add(category: str, component: str, max_points: float, value: Any, unit: str | None, topic_ids: list[str], rule: str, calc: str, points: float | None) -> None:
        rec = make_component(
            score_id=next_score_id(), category=category, component=component, maximum_points=max_points,
            input_value=value, unit=unit, claim_ids=topic_ids, rule=rule, calculation=calc, points=points,
            missing=[] if points is not None else ["unknown_or_conflicting_input"],
        )
        components.append(rec)
        if points is not None:
            category_raw[category] += points

    # Safety.
    s = raw["safety"]
    sc = cfg["safety"]["components"]
    award_points = float(sc["iihs_award"]["rules"][s["award"]])
    add("safety", "iihs_award", 7, s["award"], None, [claim_id(vehicle_id, "scoring.safety.iihs_award")],
        "Top Safety Pick+=7; Top Safety Pick=5", f"lookup({s['award']}) = {award_points}", award_points)
    test_points = float(sc["iihs_test_quality"]["rules"][s["test_quality"]])
    add("safety", "iihs_test_quality", 6, s["test_quality"], None, [claim_id(vehicle_id, "scoring.safety.iihs_test_quality")],
        "Current-generation IIHS test-quality lookup", f"lookup({s['test_quality']}) = {test_points}", test_points)
    crash_fields = [
        ("pedestrian_aeb_strong_result", "pedestrian_strong", 2, "scoring.safety.pedestrian_aeb_strong_result"),
        ("vehicle_to_vehicle_aeb", "v2v_aeb", 1, "scoring.safety.vehicle_to_vehicle_aeb"),
        ("blind_spot_monitoring_standard", "bsm", 1, "scoring.safety.blind_spot_monitoring_standard"),
        ("rear_cross_traffic_alert_standard", "rcta", 1, "scoring.safety.rear_cross_traffic_alert_standard"),
    ]
    for comp, key, maxp, topic in crash_fields:
        pts = float(maxp if s[key] else 0)
        add("safety", comp, maxp, s[key], "boolean", [claim_id(vehicle_id, topic)],
            f"{maxp} points when verified true; 0 when verified false", f"{maxp} * {int(bool(s[key]))} = {pts}", pts)
    fam_fields = [
        ("rear_occupant_alert", "rear_occupant", "scoring.safety.rear_occupant_alert"),
        ("safe_exit_warning_or_equivalent", "safe_exit", "scoring.safety.safe_exit_warning"),
        ("driver_attention_monitoring", "driver_attention", "scoring.safety.driver_attention_monitoring"),
        ("surround_view_camera_available_on_scored_trim", "surround_view", "scoring.safety.surround_view_camera"),
    ]
    for comp, key, topic in fam_fields:
        pts = 1.0 if s[key] else 0.0
        add("safety", comp, 1, s[key], "boolean", [claim_id(vehicle_id, topic)],
            "1 point when verified true; 0 when verified false", f"1 * {int(bool(s[key]))} = {pts}", pts)
    latch_points = float(sc["latch_quality"]["rules"][s["latch_quality"]])
    add("safety", "latch_quality", 3, s["latch_quality"], None, [claim_id(vehicle_id, "scoring.safety.latch_quality")],
        "LATCH access-and-position lookup", f"lookup({s['latch_quality']}) = {latch_points}", latch_points)

    # TCO.
    tco_cfg = cfg["total_cost_of_ownership"]
    tco_v = TCO_BY_ID[vehicle_id]
    five = float(tco_v["scenarios"]["5_year"]["base"]["total_tco"])
    ten = float(tco_v["scenarios"]["10_year"]["base"]["total_tco"])
    five_raw = interpolate(five, tco_cfg["five_year_tco_score"]["anchors"], "tco", "score")
    ten_raw = interpolate(ten, tco_cfg["ten_year_tco_score"]["anchors"], "tco", "score")
    tco_points = float(tco_cfg["max_points"]) * ((0.40 * five_raw + 0.60 * ten_raw) / 10)
    tco_claims = sorted(set(tco_v["scenarios"]["5_year"]["base"]["input_claim_ids"] + tco_v["scenarios"]["10_year"]["base"]["input_claim_ids"]))
    add("total_cost_of_ownership", "weighted_5_and_10_year_tco", 15,
        {"five_year_tco": five, "ten_year_tco": ten, "five_year_raw_score": round(five_raw, 4), "ten_year_raw_score": round(ten_raw, 4)}, "USD",
        tco_claims,
        "15 * ((0.40 * interpolated 5-year score + 0.60 * interpolated 10-year score) / 10)",
        f"15 * ((0.40*{five_raw:.4f} + 0.60*{ten_raw:.4f})/10) = {tco_points:.4f}", tco_points)

    # Reliability.
    r = raw["reliability"]
    rc = cfg["reliability"]["components"]
    rel_defs = [
        ("predicted_or_measured_reliability", "predicted", 4, "predicted_or_measured_reliability", "scoring.reliability.predicted_or_measured"),
        ("powertrain_and_platform_maturity", "maturity", 2, "powertrain_and_platform_maturity", "scoring.reliability.platform_maturity"),
        ("recall_and_campaign_history", "recalls", 2, "recall_and_campaign_history", "scoring.reliability.recall_history"),
        ("owner_problem_pattern", "owner_pattern", 2, "owner_problem_pattern", "scoring.reliability.owner_problem_pattern"),
    ]
    for comp, key, maxp, cfg_key, topic in rel_defs:
        value = r[key]
        pts = float(rc[cfg_key]["rules"][value])
        add("reliability", comp, maxp, value, None, [claim_id(vehicle_id, topic)],
            "Configuration-defined reliability classification lookup", f"lookup({value}) = {pts}", pts)

    # Purchase price, using explicit used-vehicle override recorded in judgments.
    pp_cfg = cfg["purchase_price"]
    price = float(raw["price"]["base"])
    price_raw = interpolate(price, pp_cfg["anchors"], "price", "score")
    price_points = float(pp_cfg["max_points"]) * price_raw / 10
    add("purchase_price", "normalized_used_acquisition_price", 10, price, "USD",
        [claim_id(vehicle_id, "market_price.base")],
        "Used-vehicle override: interpolate normalized current-market acquisition price on configured purchase-price anchors",
        f"10 * interpolated_score({price:.2f})/10 = {price_points:.4f}", price_points)

    # Passenger space.
    ps_cfg = cfg["passenger_space"]["components"]
    sp = raw["space"]
    leg = float(sp["third_row_legroom"])
    leg_pts = 0.0
    leg_rule = "below 28 inches = 0"
    for rule in ps_cfg["third_row_legroom"]["rules"]:
        if "min" in rule and leg >= float(rule["min"]):
            leg_pts = float(rule["points"])
            leg_rule = f">= {rule['min']} inches = {rule['points']} points"
            break
    add("passenger_space", "third_row_legroom", 4, leg, "inches", [claim_id(vehicle_id, "scoring.passenger_space.third_row_legroom")],
        "Threshold lookup: >=34=4; >=32=3; >=30=2; >=28=1; below28=0", f"{leg} -> {leg_rule}", leg_pts)
    use_pts = float(ps_cfg["third_row_real_world_usability"]["rules"][sp["third_row_usability"]])
    add("passenger_space", "third_row_real_world_usability", 3, sp["third_row_usability"], None,
        [claim_id(vehicle_id, "scoring.passenger_space.third_row_real_world_usability")], "Qualitative usability lookup permitted by configuration",
        f"lookup({sp['third_row_usability']}) = {use_pts}", use_pts)
    for comp, key, topic in [
        ("sliding_second_row", "sliding_second_row", "scoring.passenger_space.sliding_second_row"),
        ("multiple_family_usable_seating_configurations", "multiple_configurations", "scoring.passenger_space.multiple_family_usable_configurations"),
    ]:
        pts = 1.0 if sp[key] else 0.0
        add("passenger_space", comp, 1, sp[key], "boolean", [claim_id(vehicle_id, topic)], "1 point if verified true", f"1*{int(bool(sp[key]))}={pts}", pts)
    entry_pts = float(ps_cfg["entry_and_exit"]["rules"][sp["entry_exit"]])
    add("passenger_space", "entry_and_exit", 1, sp["entry_exit"], None, [claim_id(vehicle_id, "scoring.passenger_space.entry_and_exit")],
        "Entry/exit qualitative lookup", f"lookup({sp['entry_exit']})={entry_pts}", entry_pts)

    # Cargo.
    cg_cfg = cfg["cargo_practicality"]["components"]
    cg = raw["cargo"]
    vol = float(cg["volume"])
    cargo_pts = interpolate(vol, cg_cfg["cargo_behind_third_row"]["anchors"], "cargo", "points")
    add("cargo_practicality", "cargo_behind_third_row", 8, vol, "cu_ft", [claim_id(vehicle_id, "scoring.cargo.volume_behind_third_row")],
        "Linear interpolation across 16/2, 18/4, 20/6, 22/8 with endpoint clamping",
        f"interpolate({vol}) = {cargo_pts:.4f}", cargo_pts)
    cargo_fields = [
        ("flat_or_low_load_floor", "low_floor", "scoring.cargo.flat_or_low_load_floor"),
        ("useful_underfloor_storage", "underfloor", "scoring.cargo.useful_underfloor_storage"),
        ("power_third_row_available", "power_third_row", "scoring.cargo.power_third_row_available"),
        ("independent_testing_confirms_good_real_world_shape", "good_shape", "scoring.cargo.independent_testing_good_shape"),
    ]
    for comp, key, topic in cargo_fields:
        pts = 0.5 if cg[key] else 0.0
        add("cargo_practicality", comp, 0.5, cg[key], "boolean", [claim_id(vehicle_id, topic)], "0.5 points if verified true", f"0.5*{int(bool(cg[key]))}={pts}", pts)

    # Fuel / energy.
    annual_cost, energy_details, energy_claims = annual_energy_cost({"vehicle_id": vehicle_id, **raw})
    fe_cfg = cfg["fuel_economy"]
    fe_raw = interpolate(annual_cost, fe_cfg["anchors"], "annual_energy_cost", "score")
    fe_points = float(fe_cfg["max_points"]) * fe_raw / 10
    add("fuel_economy", "estimated_annual_energy_cost", 10, round(annual_cost, 2), "USD/year", energy_claims,
        "Linear interpolation on configured annual-energy-cost anchors",
        f"10 * interpolated_score({annual_cost:.2f})/10 = {fe_points:.4f}; {energy_details['formula']}", fe_points)

    # Comfort.
    ccfg = cfg["comfort"]["components"]
    co = raw["comfort"]
    comfort_fields = [
        ("row_2_dedicated_vents", "row2_vents", 0.5, "scoring.comfort.row2_dedicated_vents"),
        ("row_3_dedicated_vents", "row3_vents", 0.5, "scoring.comfort.row3_dedicated_vents"),
        ("ceiling_mounted_or_equivalently_effective_rear_vents", "ceiling_vents", 0.5, "scoring.comfort.ceiling_or_equivalent_rear_vents"),
    ]
    for comp, key, maxp, topic in comfort_fields:
        pts = maxp if co[key] else 0.0
        add("comfort", comp, maxp, co[key], "boolean", [claim_id(vehicle_id, topic)], f"{maxp} points if verified true", f"{maxp}*{int(bool(co[key]))}={pts}", pts)
    for comp, key, maxp, cfg_key, topic in [
        ("ride_quality", "ride", 1.5, "ride_quality", "scoring.comfort.ride_quality"),
        ("cabin_noise", "noise", 1.0, "cabin_noise", "scoring.comfort.cabin_noise"),
        ("seat_comfort", "seats", 1.0, "seat_comfort", "scoring.comfort.seat_comfort"),
    ]:
        pts = float(ccfg[cfg_key]["rules"][co[key]])
        add("comfort", comp, maxp, co[key], None, [claim_id(vehicle_id, topic)], "Qualitative comfort lookup permitted by configuration", f"lookup({co[key]})={pts}", pts)

    # Technology.
    tech = raw["technology"]
    tech_cfg = cfg["technology"]["components"]
    tech_fields = [
        ("surround_view_camera", "surround_view", "surround_view_camera", "scoring.technology.surround_view"),
        ("wireless_carplay_android_auto", "wireless_carplay", "wireless_carplay_android_auto", "scoring.technology.wireless_carplay"),
        ("adaptive_cruise_with_lane_centering", "adaptive_lane_centering", "adaptive_cruise_with_lane_centering", "scoring.technology.adaptive_lane_centering"),
        ("rear_or_family_camera_feature", "family_camera", "rear_or_family_camera_feature", "scoring.technology.family_camera"),
        ("ota_updates", "ota", "ota_updates", "scoring.technology.ota"),
        ("digital_key_or_phone_key", "digital_key", "digital_key_or_phone_key", "scoring.technology.digital_key"),
        ("usable_physical_controls_for_core_functions", "physical_controls", "usable_physical_controls_for_core_functions", "scoring.technology.physical_controls"),
    ]
    for comp, key, cfg_key, topic in tech_fields:
        maxp = float(tech_cfg[cfg_key]["points"])
        pts = maxp if tech[key] else 0.0
        add("technology", comp, maxp, tech[key], "boolean", [claim_id(vehicle_id, topic)], f"{maxp} points if verified true", f"{maxp}*{int(bool(tech[key]))}={pts}", pts)

    expected_max = {name: float(v["max_points"]) for name, v in cfg.items()}
    category_scores = []
    for category, maxp in expected_max.items():
        raw_points = category_raw.get(category, 0.0)
        if raw_points > maxp + 1e-9:
            raise AssertionError(f"{vehicle_id} {category} exceeds max: {raw_points}>{maxp}")
        category_scores.append({
            "category": category,
            "maximum_points": maxp,
            "confirmed_points_raw": round(raw_points, 6),
            "confirmed_points": round(raw_points, ROUND),
            "maximum_possible_points": round(raw_points, ROUND),
            "missing_components": [],
            "evidence_confidence": confidence_min(c["evidence_confidence"] for c in components if c["category"] == category),
        })
    total_raw = sum(c["confirmed_points_raw"] for c in category_scores)
    total = round(total_raw, ROUND)
    return {
        "vehicle_id": vehicle_id,
        "vehicle": raw["short_name"],
        "eligibility_gate": raw["eligibility"]["overall"],
        "score_scope": "Provisional score for the exact qualifying configuration described in the vehicle ID; build-date and VIN conditions remain purchase gates where stated.",
        "category_scores": category_scores,
        "component_scores": components,
        "confirmed_points_raw": round(total_raw, 6),
        "confirmed_points": total,
        "maximum_possible_points": total,
        "missing_scoring_inputs": [],
        "interpretation": score_interpretation(total),
        "overall_evidence_confidence": confidence_min(c["evidence_confidence"] for c in components),
        "price_record_ids": raw["price"]["price_record_ids"],
    }


SCORECARDS = [score_vehicle(vid, raw) for vid, raw in DEEP_VEHICLES.items()]
SCORECARDS.sort(key=lambda x: (-x["confirmed_points_raw"], x["vehicle"]))
SCORE_BY_ID = {s["vehicle_id"]: s for s in SCORECARDS}

# Validate exact total structure.
category_total = sum(float(v["max_points"]) for v in SCORING["scoring"].values())
if not math.isclose(category_total, 100.0):
    raise AssertionError(f"Category maximums total {category_total}, not 100")
for sc in SCORECARDS:
    if sc["confirmed_points_raw"] > 100 + 1e-9:
        raise AssertionError(f"Score exceeds 100: {sc['vehicle_id']}")

SCORECARD_DOC = {
    "schema_version": "1.0",
    "run_id": RUN_ID,
    "scoring_config_version": SCORING["version"],
    "scoring_config_sha256": sha256(ROOT / "config/scoring-config.json"),
    "score_rounding_decimals": SCORING["scoring_principles"]["score_rounding_decimals"],
    "practical_tie_threshold_points": SCORING["scoring_principles"]["practical_tie_threshold_points"],
    "used_price_override": "Normalized current-market acquisition price for exact year, trim, drivetrain, mileage and condition.",
    "ranking_note": "Official scores are deterministic. Conditional build/VIN requirements and overlapping uncertainty ranges prevent the score alone from authorizing a purchase.",
    "vehicles": SCORECARDS,
}


def score_with_overrides(vehicle_id: str, *, price: float | None = None, miles: float | None = None, energy_mult: float = 1.0,
                         tco5: float | None = None, tco10: float | None = None, reliability_delta: float = 0.0) -> float:
    sc = SCORE_BY_ID[vehicle_id]
    cat = {c["category"]: float(c["confirmed_points_raw"]) for c in sc["category_scores"]}
    raw = DEEP_VEHICLES[vehicle_id]
    if price is not None:
        p_cfg = SCORING["scoring"]["purchase_price"]
        cat["purchase_price"] = float(p_cfg["max_points"]) * interpolate(price, p_cfg["anchors"], "price", "score") / 10
    if miles is not None or energy_mult != 1.0:
        annual, _, _ = annual_energy_cost({"vehicle_id": vehicle_id, **raw}, annual_miles=miles, price_multiplier=energy_mult)
        f_cfg = SCORING["scoring"]["fuel_economy"]
        cat["fuel_economy"] = float(f_cfg["max_points"]) * interpolate(annual, f_cfg["anchors"], "annual_energy_cost", "score") / 10
    if tco5 is not None or tco10 is not None:
        tcfg = SCORING["scoring"]["total_cost_of_ownership"]
        base5 = TCO_BY_ID[vehicle_id]["scenarios"]["5_year"]["base"]["total_tco"]
        base10 = TCO_BY_ID[vehicle_id]["scenarios"]["10_year"]["base"]["total_tco"]
        v5 = float(tco5 if tco5 is not None else base5)
        v10 = float(tco10 if tco10 is not None else base10)
        s5 = interpolate(v5, tcfg["five_year_tco_score"]["anchors"], "tco", "score")
        s10 = interpolate(v10, tcfg["ten_year_tco_score"]["anchors"], "tco", "score")
        cat["total_cost_of_ownership"] = 15 * ((0.4 * s5 + 0.6 * s10) / 10)
    cat["reliability"] = min(10.0, max(0.0, cat["reliability"] + reliability_delta))
    return sum(cat.values())


# Sensitivity analysis.
presets = {
    "official": {"safety": 25, "total_cost_of_ownership": 15, "reliability": 10, "purchase_price": 10, "passenger_space": 10, "cargo_practicality": 10, "fuel_economy": 10, "comfort": 5, "technology": 5},
    "value_first": {"safety": 20, "total_cost_of_ownership": 22, "reliability": 15, "purchase_price": 15, "passenger_space": 8, "cargo_practicality": 7, "fuel_economy": 8, "comfort": 2.5, "technology": 2.5},
    "space_first": {"safety": 20, "total_cost_of_ownership": 10, "reliability": 10, "purchase_price": 7.5, "passenger_space": 17.5, "cargo_practicality": 17.5, "fuel_economy": 5, "comfort": 7.5, "technology": 5},
    "risk_averse": {"safety": 30, "total_cost_of_ownership": 12.5, "reliability": 22.5, "purchase_price": 7.5, "passenger_space": 7.5, "cargo_practicality": 7.5, "fuel_economy": 5, "comfort": 5, "technology": 2.5},
    "efficiency_first": {"safety": 20, "total_cost_of_ownership": 20, "reliability": 10, "purchase_price": 10, "passenger_space": 7.5, "cargo_practicality": 7.5, "fuel_economy": 20, "comfort": 2.5, "technology": 2.5},
}
for name, weights in presets.items():
    if not math.isclose(sum(weights.values()), 100.0):
        raise AssertionError(f"Preset {name} weights do not total 100")


def weighted_score(vehicle_id: str, weights: dict[str, float]) -> float:
    cats = {c["category"]: c for c in SCORE_BY_ID[vehicle_id]["category_scores"]}
    return sum((cats[k]["confirmed_points_raw"] / cats[k]["maximum_points"]) * w for k, w in weights.items())

sensitivity_vehicles = []
for vid, raw in DEEP_VEHICLES.items():
    tco = TCO_BY_ID[vid]["scenarios"]
    rows = {
        "official_score": SCORE_BY_ID[vid]["confirmed_points"],
        "purchase_price_low": round(score_with_overrides(vid, price=raw["price"]["low"]), 1),
        "purchase_price_high": round(score_with_overrides(vid, price=raw["price"]["high"]), 1),
        "annual_miles_6000": round(score_with_overrides(vid, miles=6000), 1),
        "annual_miles_9000": round(score_with_overrides(vid, miles=9000), 1),
        "energy_prices_minus_25_percent": round(score_with_overrides(vid, energy_mult=0.75), 1),
        "energy_prices_plus_25_percent": round(score_with_overrides(vid, energy_mult=1.25), 1),
        "low_tco": round(score_with_overrides(vid, tco5=tco["5_year"]["low"]["total_tco"], tco10=tco["10_year"]["low"]["total_tco"]), 1),
        "high_tco": round(score_with_overrides(vid, tco5=tco["5_year"]["high"]["total_tco"], tco10=tco["10_year"]["high"]["total_tco"]), 1),
        "reliability_minus_1": round(score_with_overrides(vid, reliability_delta=-1), 1),
        "reliability_plus_1": round(score_with_overrides(vid, reliability_delta=1), 1),
    }
    sensitivity_vehicles.append({
        "vehicle_id": vid,
        "vehicle": raw["short_name"],
        "one_variable_scenarios": rows,
        "exploratory_weight_presets": {name: round(weighted_score(vid, weights), 1) for name, weights in presets.items()},
    })

preset_rankings = {}
for name, weights in presets.items():
    ranking = sorted(((vid, weighted_score(vid, weights)) for vid in DEEP_VEHICLES), key=lambda x: (-x[1], x[0]))
    preset_rankings[name] = [{"rank": i + 1, "vehicle_id": vid, "score": round(score, 1)} for i, (vid, score) in enumerate(ranking)]

SENSITIVITY_DOC = {
    "schema_version": "1.0",
    "run_id": RUN_ID,
    "official_model_unchanged": True,
    "exploratory_warning": "Alternative weights are client exploration only. They do not change the frozen official score or recommendation record.",
    "weight_presets": presets,
    "preset_rankings": preset_rankings,
    "vehicles": sensitivity_vehicles,
}

# Deterministic uncertainty simulation.
rng = random.Random(GLOBAL_ASSUMPTIONS["simulation_seed"])
iterations = int(GLOBAL_ASSUMPTIONS["simulation_iterations"])
sim_scores: dict[str, list[float]] = {vid: [] for vid in DEEP_VEHICLES}
rank_counts: dict[str, Counter[int]] = {vid: Counter() for vid in DEEP_VEHICLES}
pairwise: dict[tuple[str, str], int] = Counter()

for _ in range(iterations):
    iteration_scores: dict[str, float] = {}
    common_gas_mult = rng.triangular(0.75, 1.25, 1.0)
    common_electric_mult = rng.triangular(0.75, 1.25, 1.0)
    miles = rng.triangular(6000, 9000, 8000)
    for vid, raw in DEEP_VEHICLES.items():
        purchase = rng.triangular(float(raw["price"]["low"]), float(raw["price"]["high"]), float(raw["price"]["base"]))
        energy_mult = common_electric_mult if raw["powertrain"] == "electric" else common_gas_mult
        t = raw["tco_inputs"]
        # Model TCO using sampled acquisition, mileage, energy and uncertain upkeep/depreciation.
        annual, _, _ = annual_energy_cost({"vehicle_id": vid, **raw}, annual_miles=miles, price_multiplier=energy_mult)
        maint_mult = rng.triangular(0.8, 1.2, 1.0)
        repair_mult = rng.triangular(0.6, 1.6, 1.0)
        tire_mult = rng.triangular(0.85, 1.2, 1.0)
        residual_mult = rng.triangular(0.75, 1.25, 1.0)
        sampled_tco = {}
        for years in (5, 10):
            residual_fraction = max(0.0, min(0.95, float(t[f"residual_{years}"]) * residual_mult))
            sampled_tco[years] = (
                purchase + purchase * GLOBAL_ASSUMPTIONS["sales_tax_rate"] + float(t["initial_fees"]) + annual * years
                + float(t[f"maintenance_{years}"]) * maint_mult + float(t[f"repairs_{years}"]) * repair_mult
                + float(t[f"tires_{years}"]) * tire_mult + float(t[f"registration_{years}"])
                - purchase * residual_fraction
            )
        confidence = raw["price"]["confidence"]
        rel_sd = 0.9 if confidence == "low" else 0.65
        if raw["reliability"]["predicted"] in ("below_average", "poor_or_systemic_problems"):
            rel_sd = 1.1
        reliability_delta = max(-2.0, min(2.0, rng.gauss(0.0, rel_sd)))
        iteration_scores[vid] = score_with_overrides(
            vid, price=purchase, miles=miles, energy_mult=energy_mult,
            tco5=sampled_tco[5], tco10=sampled_tco[10], reliability_delta=reliability_delta,
        )
        sim_scores[vid].append(iteration_scores[vid])
    ranked = sorted(iteration_scores.items(), key=lambda x: (-x[1], x[0]))
    for rank, (vid, _) in enumerate(ranked, 1):
        rank_counts[vid][rank] += 1
    vids = list(DEEP_VEHICLES)
    for i, a in enumerate(vids):
        for b in vids[i + 1:]:
            if iteration_scores[a] > iteration_scores[b]:
                pairwise[(a, b)] += 1
            elif iteration_scores[b] > iteration_scores[a]:
                pairwise[(b, a)] += 1


def pct(values: list[float], p: float) -> float:
    ordered = sorted(values)
    idx = (len(ordered) - 1) * p
    lo = math.floor(idx)
    hi = math.ceil(idx)
    if lo == hi:
        return ordered[lo]
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (idx - lo)

sim_summary = []
for vid, values in sim_scores.items():
    sim_summary.append({
        "vehicle_id": vid,
        "vehicle": DEEP_VEHICLES[vid]["short_name"],
        "mean_score": round(sum(values) / len(values), 2),
        "p05": round(pct(values, 0.05), 2),
        "p50": round(pct(values, 0.50), 2),
        "p95": round(pct(values, 0.95), 2),
        "probability_rank_1": round(rank_counts[vid][1] / iterations, 4),
        "probability_top_3": round(sum(rank_counts[vid][r] for r in (1, 2, 3)) / iterations, 4),
        "rank_distribution": {str(r): round(rank_counts[vid][r] / iterations, 4) for r in range(1, len(DEEP_VEHICLES) + 1)},
    })
sim_summary.sort(key=lambda x: (-x["probability_rank_1"], -x["mean_score"]))

pairwise_rows = []
vids = list(DEEP_VEHICLES)
for i, a in enumerate(vids):
    for b in vids[i + 1:]:
        a_wins = pairwise[(a, b)]
        b_wins = pairwise[(b, a)]
        ties = iterations - a_wins - b_wins
        pairwise_rows.append({
            "vehicle_a": a, "vehicle_b": b,
            "probability_a_scores_higher": round(a_wins / iterations, 4),
            "probability_b_scores_higher": round(b_wins / iterations, 4),
            "probability_exact_tie": round(ties / iterations, 4),
        })

UNCERTAINTY_DOC = {
    "schema_version": "1.0",
    "run_id": RUN_ID,
    "seed": GLOBAL_ASSUMPTIONS["simulation_seed"],
    "iterations": iterations,
    "method": "Triangular uncertainty for transaction price, miles, energy prices, maintenance, repairs, tires and residual fraction; bounded Gaussian perturbation for reliability category. Official weights and verified non-cost component scores remain fixed.",
    "limitations": [
        "Simulation expresses planning uncertainty, not statistical failure probabilities.",
        "Input ranges are scenario assumptions rather than actuarial distributions.",
        "Insurance is omitted because household-specific comparable quotes were not supplied.",
    ],
    "vehicle_results": sim_summary,
    "pairwise_comparisons": pairwise_rows,
}

# Determine finalists from deterministic scores and retain conditionality.
ranked_ids = [s["vehicle_id"] for s in SCORECARDS]
finalists = ranked_ids[:3]
leader = ranked_ids[0]
runner_up = ranked_ids[1]
conditional_alt = ranked_ids[2]
live_alt = ranked_ids[3] if len(ranked_ids) > 3 else None

# Recommendation is a test-drive slate, not purchase authorization.
RECOMMENDATION = {
    "schema_version": "1.0",
    "run_id": RUN_ID,
    "status": "independent_recommendation_locked",
    "lock_timestamp_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    "recommendation_type": "provisional_test_drive_slate_not_purchase_authorization",
    "current_recommendation": {
        "vehicle_id": leader,
        "vehicle": DEEP_VEHICLES[leader]["short_name"],
        "eligibility_status": DEEP_VEHICLES[leader]["eligibility"]["overall"],
        "confirmed_score": SCORE_BY_ID[leader]["confirmed_points"],
        "maximum_possible_score": SCORE_BY_ID[leader]["maximum_possible_points"],
        "concise_rationale": "Highest frozen deterministic score, driven by safety, space, energy cost and used-market value; the conclusion remains conditional because first-year electrical/ICCU risk is materially worse than the alternatives.",
        "main_compromise": DEEP_VEHICLES[leader]["major_concern"],
        "purchase_stop_conditions": [
            "Certification label does not satisfy the IIHS build-date condition.",
            "Any recall, ICCU, cluster or seat-bolt campaign remains open.",
            "Service history shows repeated 12-volt, ICCU, charging or display failures without durable resolution.",
            "Battery state-of-health, Level 2 charging or DC fast-charging test is unsatisfactory.",
            "Household insurance quote erases the modeled cost advantage.",
            "Physical car-seat, dog and cargo test fails.",
        ],
    },
    "runner_up": {
        "vehicle_id": runner_up,
        "vehicle": DEEP_VEHICLES[runner_up]["short_name"],
        "confirmed_score": SCORE_BY_ID[runner_up]["confirmed_points"],
        "eligibility_status": DEEP_VEHICLES[runner_up]["eligibility"]["overall"],
        "why_it_advances": DEEP_VEHICLES[runner_up]["advance_reason"],
        "main_compromise": DEEP_VEHICLES[runner_up]["major_concern"],
    },
    "conditional_alternative": {
        "vehicle_id": conditional_alt,
        "vehicle": DEEP_VEHICLES[conditional_alt]["short_name"],
        "confirmed_score": SCORE_BY_ID[conditional_alt]["confirmed_points"],
        "eligibility_status": DEEP_VEHICLES[conditional_alt]["eligibility"]["overall"],
        "why_it_advances": DEEP_VEHICLES[conditional_alt]["advance_reason"],
        "main_compromise": DEEP_VEHICLES[conditional_alt]["major_concern"],
    },
    "live_alternate": None if live_alt is None else {
        "vehicle_id": live_alt,
        "vehicle": DEEP_VEHICLES[live_alt]["short_name"],
        "confirmed_score": SCORE_BY_ID[live_alt]["confirmed_points"],
        "reason": "Retained because its value case can become compelling if finalist VINs fail their stop conditions.",
    },
    "finalists": finalists,
    "test_drive_slate": finalists + ([live_alt] if live_alt else []),
    "recommendation_reversal_conditions": [
        "The recommended EV9 fails any build-date, campaign, service-history, battery-health, charging, insurance or physical-fit gate.",
        "A Telluride with all recalls closed and clean electrical history is available within the verified market range while the EV9 cannot clear its risk gates.",
        "The family prioritizes mature-platform dependability over efficiency strongly enough to adopt the risk-averse exploratory preset.",
        "The Sienna's physical packaging advantage proves decisive and its updated moderate-overlap result is acceptable to the family.",
        "A Q4 2026 transaction-price change materially alters purchase-price and TCO scores beyond the modeled ranges.",
    ],
    "decision_authority": "The client chooses the actual test-drive slate and purchase. Internet research is subordinate to VIN, build date, child-seat, cargo, comfort, insurance, charging and inspection results.",
    "prior_human_research_consulted_before_lock": False,
}

# Add ranking and recommendation decisions without overwriting prior history.
ledger = load_json("decisions/decision-ledger.json")
existing_ids = {d["decision_id"] for d in ledger["decisions"]}
new_decisions = [
    {
        "decision_id": "DEC-0008", "step": "deterministic_scoring",
        "decision": "Rank eligible planning configurations by the frozen 100-point model",
        "input_claim_ids_or_score_ids": [s["component_scores"][0]["score_id"] for s in SCORECARDS],
        "concise_rationale": "Code-calculated component scores were validated against category maximums and the 100-point total.",
        "reversible": True, "reversal_conditions": "Verified input claim, price record or scoring configuration changes.", "date": RUN_DATE,
    },
    {
        "decision_id": "DEC-0009", "step": "finalist_selection",
        "decision": "Advance the top three deterministic configurations while retaining the fourth-ranked live alternate",
        "input_claim_ids_or_score_ids": finalists + ([live_alt] if live_alt else []),
        "concise_rationale": "Top official scores define the slate; the alternate is retained because conditional VIN/build gates can disqualify a finalist.",
        "reversible": True, "reversal_conditions": "A finalist fails a purchase gate or updated evidence changes the score ordering.", "date": RUN_DATE,
    },
    {
        "decision_id": "DEC-0010", "step": "independent_recommendation_lock",
        "decision": f"Lock {DEEP_VEHICLES[leader]['short_name']} as the provisional evidence-based recommendation",
        "input_claim_ids_or_score_ids": [c["score_id"] for c in SCORE_BY_ID[leader]["component_scores"]],
        "concise_rationale": "It has the highest deterministic score, subject to explicit high-risk reliability and VIN/build conditions.",
        "reversible": True, "reversal_conditions": "; ".join(RECOMMENDATION["recommendation_reversal_conditions"]), "date": RUN_DATE,
    },
]
ledger["decisions"].extend(d for d in new_decisions if d["decision_id"] not in existing_ids)

# Human-supplied operating assumptions are provenance-bearing observations, not web claims.
obs = {
    "schema_version": "1.0",
    "observations": [
        {"observation_id": "OBS-0001", "type": "project_input", "topic": "annual_miles", "value": 8000, "unit": "miles/year", "source": "user_input_payload", "date": RUN_DATE},
        {"observation_id": "OBS-0002", "type": "project_input", "topic": "city_share", "value": 0.70, "unit": "fraction", "source": "user_input_payload", "date": RUN_DATE},
        {"observation_id": "OBS-0003", "type": "project_input", "topic": "highway_share", "value": 0.30, "unit": "fraction", "source": "user_input_payload", "date": RUN_DATE},
        {"observation_id": "OBS-0004", "type": "project_input", "topic": "ev_home_share", "value": 0.90, "unit": "fraction", "source": "user_input_payload", "date": RUN_DATE},
        {"observation_id": "OBS-0005", "type": "project_input", "topic": "ev_public_share", "value": 0.10, "unit": "fraction", "source": "user_input_payload", "date": RUN_DATE},
        {"observation_id": "OBS-0006", "type": "physical_validation_placeholder", "topic": "test_drive_and_fit", "value": None, "unit": None, "source": "pending_client_observation", "date": None},
    ],
}
obs_map = {
    "tco.annual_miles": "OBS-0001", "tco.city_share": "OBS-0002", "tco.highway_share": "OBS-0003",
    "tco.ev_home_share": "OBS-0004", "tco.ev_public_share": "OBS-0005",
}
for c in CLAIMS_DOC["claims"]:
    if not c.get("source_ids") and c.get("field_or_topic") in obs_map:
        c["human_observation_ids"] = [obs_map[c["field_or_topic"]]]
    else:
        c.setdefault("human_observation_ids", [])

write_json("analysis/tco-model.json", TCO_MODEL)
write_json("analysis/scorecard.json", SCORECARD_DOC)
write_json("analysis/sensitivity.json", SENSITIVITY_DOC)
write_json("analysis/uncertainty-simulation.json", UNCERTAINTY_DOC)
write_json("analysis/human-observations.json", obs)
write_json("evidence/claims.json", CLAIMS_DOC)
write_json("decisions/recommendation.json", RECOMMENDATION)
write_json("decisions/decision-ledger.json", ledger)

rec_hash = sha256(ROOT / "decisions/recommendation.json")
manifest = load_json("run-manifest.json")
manifest["independent_recommendation_locked"] = True
manifest["independent_recommendation_sha256"] = rec_hash
manifest["independent_recommendation_lock_timestamp_utc"] = RECOMMENDATION["lock_timestamp_utc"]
manifest["prior_human_research_consulted"] = False
manifest["deep_research_count"] = len(DEEP_VEHICLES)
manifest["finalist_count"] = len(finalists)
manifest["current_recommendation_vehicle_id"] = leader
write_json("run-manifest.json", manifest)

print("Official deterministic ranking:")
for i, sc in enumerate(SCORECARDS, 1):
    print(f"{i}. {sc['vehicle']}: {sc['confirmed_points']:.1f}/100 ({sc['eligibility_gate']})")
print(f"Recommendation locked: {DEEP_VEHICLES[leader]['short_name']} ({rec_hash[:12]}...)")
