from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent
PROJECT_NAME = ROOT.name
ZIP_NAMES = {"family-vehicle-site.zip", "family-vehicle-analysis-package.zip", "project-package.zip"}
TOP_LEVEL_EXPORTS = {
    "reports/client-report-self-contained.html": "family-vehicle-decision-report.html",
    "reports/research-report.md": "family-vehicle-research-report.md",
    "analysis/scorecard.json": "family-vehicle-scoring-output.json",
    "evidence/sources.json": "family-vehicle-sources.json",
    "evidence/claims.json": "family-vehicle-claims.json",
    "decisions/decision-ledger.json": "family-vehicle-decision-ledger.json",
    "checklists/client-test-drive-checklist.md": "family-vehicle-test-drive-checklist.md",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def is_canonical_file(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if path.name in ZIP_NAMES or path.suffix == ".zip":
        return False
    if any(part == "__pycache__" for part in rel.parts):
        return False
    return path.is_file()


def write_artifact_manifest() -> None:
    rows = []
    for p in sorted(ROOT.rglob("*")):
        if not is_canonical_file(p):
            continue
        rel = p.relative_to(ROOT).as_posix()
        rows.append({"path": rel, "bytes": p.stat().st_size, "sha256": sha256(p)})
    doc = {
        "schema_version": "1.0",
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "root": PROJECT_NAME,
        "file_count": len(rows),
        "files": rows,
    }
    path = ROOT / "analysis/artifact-manifest.json"
    path.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")


def write_analysis_zip(dest: Path) -> None:
    tmp = OUT / (dest.name + ".tmp")
    tmp.unlink(missing_ok=True)
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(ROOT.rglob("*")):
            if not is_canonical_file(p):
                continue
            arc = Path(PROJECT_NAME) / p.relative_to(ROOT)
            z.write(p, arc.as_posix())
    tmp.replace(dest)


def write_site_zip(dest: Path, analysis_zip: Path) -> None:
    tmp = OUT / (dest.name + ".tmp")
    tmp.unlink(missing_ok=True)
    prefix = Path("evidence-first-family-vehicle-site")
    readme = """Evidence-First Family Vehicle Decision Site

Open site/index.html in a modern browser. The site uses only local CSS, JavaScript, images and data. The self-contained report is client-report-self-contained.html.

The included family-vehicle-analysis-package.zip contains the complete editable research corpus. The site's link back to the site ZIP itself is meaningful in the original distribution location; after extraction, this folder is already the complete site package.
"""
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted((ROOT / "site").rglob("*")):
            if p.is_file():
                z.write(p, (prefix / "site" / p.relative_to(ROOT / "site")).as_posix())
        for rel, name in [
            ("reports/client-report-self-contained.html", "client-report-self-contained.html"),
            ("reports/research-report.md", "research-report.md"),
            ("checklists/client-test-drive-checklist.md", "client-test-drive-checklist.md"),
            ("reports/qa-report.md", "qa-report.md"),
        ]:
            z.write(ROOT / rel, (prefix / name).as_posix())
        z.write(analysis_zip, (prefix / "family-vehicle-analysis-package.zip").as_posix())
        z.writestr((prefix / "README.txt").as_posix(), readme)
    tmp.replace(dest)


def copy_exports() -> None:
    for rel, name in TOP_LEVEL_EXPORTS.items():
        shutil.copy2(ROOT / rel, OUT / name)


write_artifact_manifest()
analysis_out = OUT / "family-vehicle-analysis-package.zip"
write_analysis_zip(analysis_out)
project_out = OUT / "project-package.zip"
shutil.copy2(analysis_out, project_out)
site_out = OUT / "family-vehicle-site.zip"
write_site_zip(site_out, analysis_out)

# Companion files in the project root make the website's relative ZIP links work.
for src in (analysis_out, project_out, site_out):
    shutil.copy2(src, ROOT / src.name)

copy_exports()

# Friendly top-level alias for the complete package.
shutil.copy2(analysis_out, OUT / "family-vehicle-project-package.zip")

for p in [site_out, analysis_out, project_out]:
    with zipfile.ZipFile(p) as z:
        bad = z.testzip()
        if bad:
            raise RuntimeError(f"CRC failure in {p.name}: {bad}")

print(json.dumps({
    "site_zip": {"path": str(site_out), "bytes": site_out.stat().st_size, "sha256": sha256(site_out)},
    "analysis_zip": {"path": str(analysis_out), "bytes": analysis_out.stat().st_size, "sha256": sha256(analysis_out)},
    "project_package": {"path": str(project_out), "bytes": project_out.stat().st_size, "sha256": sha256(project_out)},
    "top_level_exports": [str(OUT / name) for name in TOP_LEVEL_EXPORTS.values()],
}, indent=2))
