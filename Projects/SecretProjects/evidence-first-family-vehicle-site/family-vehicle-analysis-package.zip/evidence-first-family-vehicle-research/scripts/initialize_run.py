import json, hashlib, os, datetime, pathlib
root = pathlib.Path('/mnt/data/evidence-first-family-vehicle-research')

def load(p):
    return json.loads((root/p).read_text())

def sha256(p):
    return hashlib.sha256((root/p).read_bytes()).hexdigest()

sc = load('config/scoring-config.json')
rc = load('config/research-config.json')
checks=[]
cat_sum=sum(v['max_points'] for v in sc['scoring'].values())
checks.append({'check':'category_maximums_total','expected':sc['total_points'],'actual':cat_sum,'pass':cat_sum==sc['total_points']})
component_checks={
 'safety':sum(v['max_points'] for v in sc['scoring']['safety']['components'].values()),
 'reliability':sum(v['max_points'] for v in sc['scoring']['reliability']['components'].values()),
 'passenger_space':sum(v['max_points'] for v in sc['scoring']['passenger_space']['components'].values()),
 'cargo_practicality':sum(v['max_points'] for v in sc['scoring']['cargo_practicality']['components'].values()),
 'comfort':sum(v['max_points'] for v in sc['scoring']['comfort']['components'].values()),
 'technology':sum(v['points'] for v in sc['scoring']['technology']['components'].values()),
}
for k,v in component_checks.items():
    checks.append({'check':f'{k}_component_sum','expected':sc['scoring'][k]['max_points'],'actual':v,'pass':abs(v-sc['scoring'][k]['max_points'])<1e-9})

def validate_anchors(name, anchors, xkey, ykey):
    xs=[a[xkey] for a in anchors]; ys=[a[ykey] for a in anchors]
    return {
      'check':name,
      'x_strictly_ascending':all(b>a for a,b in zip(xs,xs[1:])),
      'y_nonincreasing':all(b<=a for a,b in zip(ys,ys[1:])),
      'unambiguous_x':len(xs)==len(set(xs)),
      'pass':all(b>a for a,b in zip(xs,xs[1:])) and all(b<=a for a,b in zip(ys,ys[1:])) and len(xs)==len(set(xs))
    }
checks += [
 validate_anchors('five_year_tco_anchors', sc['scoring']['total_cost_of_ownership']['five_year_tco_score']['anchors'],'tco','score'),
 validate_anchors('ten_year_tco_anchors', sc['scoring']['total_cost_of_ownership']['ten_year_tco_score']['anchors'],'tco','score'),
 validate_anchors('purchase_price_anchors', sc['scoring']['purchase_price']['anchors'],'price','score'),
 validate_anchors('cargo_anchors', sc['scoring']['cargo_practicality']['components']['cargo_behind_third_row']['anchors'],'cargo','points'),
 validate_anchors('fuel_cost_anchors', sc['scoring']['fuel_economy']['anchors'],'annual_energy_cost','score')
]
(root/'analysis/config-validation.json').write_text(json.dumps({'status':'pass' if all(c['pass'] for c in checks) else 'fail','checks':checks},indent=2))

requirements={
 'version':'1.0-frozen-2026-08-24',
 'analysis_mode':'portfolio',
 'market':'United States',
 'home_zip':'98038',
 'purchase_window':'Q4 2026',
 'condition':'used',
 'model_years':[2023,2024,2025],
 'model_year_resolution':{
   'status':'resolved_by_conservative_intersection',
   'project_context':[2022,2023,2024,2025],
   'research_config':[2022,2023,2024,2025],
   'scoring_eligibility':[2023,2024,2025,2026,2027],
   'frozen_intersection':[2023,2024,2025],
   'reason':'Avoid granting eligibility to 2022 vehicles that the authoritative scoring gate excludes.'
 },
 'budget':{'soft_anchor':65000,'realistic_range':[70000,75000],'hard_vehicle_price_ceiling':80000,'excludes':['sales_tax','title','registration','dealer_fees']},
 'household':{'adults':2,'children_ages_at_freeze':[3,1],'car_seats':2,'dog':'medium Sheltie-sized','retained_vehicle':'2025 Ford Mustang Mach-E','trade_vehicle':'2015 Nissan Sentra'},
 'driving':{'annual_miles_point':8000,'annual_miles_range':[6000,9000],'city_percent':70,'highway_percent':30,'climate':'Pacific Northwest marine','winter_travel':'occasional Snoqualmie Pass','home_level_2_charging':True,'ev_home_charging_percent':90,'ev_public_dcfc_percent':10},
 'ownership_horizon_years':10,
 'secondary_tco_horizon_years':5,
 'candidate_target':25,'deep_research_target':6,'finalist_target':3,
 'binary_requirements':sc['eligibility']['requirements'],
 'brand_preferences':['Volkswagen','Acura','Honda','Volvo','Mazda','Toyota','Hyundai','Ford','Nissan','General Motors'],
 'brand_preferences_usage':'tie-break context only; no points',
 'used_price_basis':'normalized current-market acquisition price for exact year/trim/drivetrain/mileage/condition, overriding the new-MSRP language in purchase_price.price_definition for this used-only run',
 'manual_research_embargo':'Do not consult MANUAL_RESEARCH.md until independent recommendation is written and hashed.'
}
(root/'config/requirements.json').write_text(json.dumps(requirements,indent=2))
(root/'config/normalized-requirements.json').write_text(json.dumps(requirements,indent=2))
assumptions={
 'version':'1.0',
 'assumptions':[
  {'id':'ASM-0001','topic':'model_years','value':[2023,2024,2025],'basis':'conservative intersection of conflicting authoritative inputs','impact':'2022 candidates excluded'},
  {'id':'ASM-0002','topic':'used_purchase_timing','value':'Current August 2026 market snapshot used as planning evidence for Q4 2026; all live listings require recheck within 14 days of purchase decision.','impact':'price and availability may change'},
  {'id':'ASM-0003','topic':'listing_mileage_band','value':'Prefer approximately 10,000-45,000 miles; widen only when exact trim evidence is sparse.','impact':'normalization adjustments required outside band'},
  {'id':'ASM-0004','topic':'cash_purchase','value':True,'impact':'financing cost excluded'},
  {'id':'ASM-0005','topic':'insurance','value':'No exact insurance quotes supplied; insurance omitted from numeric TCO and reported qualitatively.','impact':'TCO is incomplete by design but comparable'},
  {'id':'ASM-0006','topic':'fuel_and_electricity_prices','value':'Use current regional planning rates researched for ZIP 98038 and scenario bounds; do not reuse MANUAL_RESEARCH assumptions.','impact':'energy-cost sensitivity'},
  {'id':'ASM-0007','topic':'trade_in','value':'2015 Nissan Sentra trade value excluded from official vehicle score and comparative TCO because it is common to all candidates.','impact':'out-of-pocket cash differs by actual trade quote only'},
  {'id':'ASM-0008','topic':'tax_and_registration','value':'Washington/King County location-based estimates included in TCO but excluded from eligibility and purchase-price score.','impact':'requires local rate assumptions'},
  {'id':'ASM-0009','topic':'qualitative_scoring','value':'Qualitative points awarded only where the rubric explicitly permits them and evidence is recorded.','impact':'some components remain null when evidence is insufficient'}
 ],
 'missing_inputs':[
  {'field':'actual insurance quotes','critical':False},
  {'field':'specific VINs and pre-purchase inspection results','critical':False},
  {'field':'actual Q4 2026 negotiated prices','critical':False},
  {'field':'client human test-drive observations','critical':False}
 ]
}
(root/'config/project-assumptions.json').write_text(json.dumps(assumptions,indent=2))

now=datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
manifest={
 'run_id':'RUN-FVR-20260824-001',
 'project_name':'Evidence-First Family Vehicle Research and Client Decision Site',
 'project_slug':'evidence-first-family-vehicle-research',
 'start_timestamp_utc':now,
 'completion_timestamp_utc':None,
 'current_date':'2026-08-24',
 'model_environment':'GPT-5.6 Pro with web.run and container tools',
 'market':'US','location':{'zip':'98038','state':'WA'},'analysis_mode':'portfolio',
 'candidate_count_target':25,
 'input_files':['config/scoring-config.json','config/research-config.json','MANUAL_RESEARCH.md'],
 'input_versions':{'scoring_config':'1.0','research_config':'unspecified','manual_research_schema':'1.0'},
 'input_hashes':{'scoring_config_sha256':sha256('config/scoring-config.json'),'research_config_sha256':sha256('config/research-config.json'),'manual_research_sha256':None},
 'assumptions':[a['id'] for a in assumptions['assumptions']],
 'missing_inputs':[m['field'] for m in assumptions['missing_inputs']],
 'output_status':'in_progress',
 'independent_recommendation_locked':False,
 'prior_human_research_consulted':False
}
(root/'run-manifest.json').write_text(json.dumps(manifest,indent=2))
for rel,empty in [
 ('evidence/sources.json',{'sources':[]}),('evidence/claims.json',{'claims':[]}),('evidence/contradictions.json',{'contradictions':[]}),('evidence/corrections.json',{'corrections':[]}),
 ('research/query-log.json',{'queries':[]}),('analysis/judgments.json',{'judgments':[{'judgment_id':'JDG-0001','topic':'model_year_conflict','decision':'Use 2023-2025 conservative intersection','reason':'Scoring eligibility excludes 2022 while project and research config include it','impact':'2022 vehicles cannot enter candidate universe','date':'2026-08-24'},{'judgment_id':'JDG-0002','topic':'used_price_scoring_basis','decision':'Use normalized current used acquisition price','reason':'Project-specific used-vehicle rules explicitly override new-MSRP basis for used runs','impact':'purchase-price scores reference price_record_ids','date':'2026-08-24'}]}),
 ('analysis/human-observations.json',{'status':'not_applicable_before_test_drives','observations':[]}),('decisions/decision-ledger.json',{'decisions':[]}),('decisions/eliminations.json',{'eliminations':[]})
]:
    (root/rel).write_text(json.dumps(empty,indent=2))
print(json.dumps({'config_validation':'pass' if all(c['pass'] for c in checks) else 'fail','category_sum':cat_sum,'hashes':manifest['input_hashes']},indent=2))
