from __future__ import annotations
import base64, json, re
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path('/mnt/data/evidence-first-family-vehicle-research')
OUT=ROOT/'analysis/browser-qa.json'

def patch_storage(html:str)->str:
    html=html.replace("const saved = localStorage.getItem('fvr-theme');", "const saved = null;")
    html=html.replace("localStorage.setItem('fvr-theme',document.body.classList.contains('dark')?'dark':'light')", "void 0")
    html=html.replace("const savedSlate=JSON.parse(localStorage.getItem('fvr-slate')||'{}');", "const savedSlate={};")
    html=html.replace("localStorage.setItem('fvr-slate',JSON.stringify(out))", "void 0")
    return html

def inline_editable()->str:
    html=(ROOT/'site/index.html').read_text(encoding='utf-8')
    css=(ROOT/'site/assets/css/app.css').read_text(encoding='utf-8')
    js=(ROOT/'site/assets/js/app.js').read_text(encoding='utf-8')
    html=html.replace('<link rel="stylesheet" href="assets/css/app.css">',f'<style>{css}</style>')
    html=html.replace('<script src="assets/js/app.js"></script>',f'<script>{js}</script>')
    for path in (ROOT/'site/assets/images').iterdir():
        if not path.is_file():
            continue
        mime='image/svg+xml' if path.suffix.lower()=='.svg' else 'image/png'
        b64=base64.b64encode(path.read_bytes()).decode('ascii')
        html=html.replace(f'assets/images/{path.name}',f'data:{mime};base64,{b64}')
    return patch_storage(html)

def standalone()->str:
    return patch_storage((ROOT/'reports/client-report-self-contained.html').read_text(encoding='utf-8'))

def inspect(page,label,html,viewport,screenshot):
    errors=[]; warnings=[]
    page.on('console',lambda msg: errors.append(f'console:{msg.type}:{msg.text}') if msg.type=='error' else (warnings.append(f'console:{msg.type}:{msg.text}') if msg.type=='warning' else None))
    page.on('pageerror',lambda exc: errors.append(f'pageerror:{exc}'))
    page.set_content(html,wait_until='load',timeout=120000)
    page.wait_for_timeout(1600)
    res={
      'label':label,
      'title':page.title(),
      'hero_title':page.locator('#hero-title').inner_text(),
      'hero_score':page.locator('#hero-score').inner_text(),
      'vehicle_cards':page.locator('.vehicle-card').count(),
      'claim_rows_initial':page.locator('#claims-body tr').count(),
      'source_rows_initial':page.locator('#sources-body tr').count(),
      'images':page.locator('img').count(),
      'broken_images':page.locator('img').evaluate_all("els=>els.filter(e=>!e.complete||e.naturalWidth===0).length"),
      'horizontal_overflow':page.evaluate('document.documentElement.scrollWidth > document.documentElement.clientWidth'),
      'scroll_width':page.evaluate('document.documentElement.scrollWidth'),
      'client_width':page.evaluate('document.documentElement.clientWidth'),
      'errors':errors,
      'warnings':warnings,
    }
    if viewport['width']>=1000:
      page.click('[data-preset="risk_averse"]')
      page.wait_for_timeout(100)
      res['risk_averse_first']=page.locator('#explorer-body tr').first.inner_text().replace('\n',' | ')
      page.fill('#claim-search','ICCU')
      page.wait_for_timeout(100)
      res['filtered_claim_rows']=page.locator('#claims-body tr').count()
      page.fill('#source-search','EV9')
      page.wait_for_timeout(100)
      res['filtered_source_rows']=page.locator('#sources-body tr').count()
      page.click('#theme-toggle')
      res['dark_mode_class']=page.locator('body').get_attribute('class')
      # Accordion exercise
      if page.locator('.vehicle-card details').count():
        page.locator('.vehicle-card details').first.locator(':scope > summary').click()
        res['score_detail_open']=page.locator('.vehicle-card details').first.evaluate('e=>e.open')
    page.screenshot(path=str(screenshot),full_page=False)
    return res

results=[]
with sync_playwright() as p:
    exe='/usr/bin/chromium'
    browser=p.chromium.launch(headless=True,executable_path=exe,args=['--no-sandbox','--disable-web-security','--allow-file-access-from-files'])
    for label,html in [('editable-inlined',inline_editable()),('standalone',standalone())]:
        pg=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
        results.append(inspect(pg,label,html,{'width':1440,'height':1000},ROOT/f'reports/{label}-desktop.png'))
        pg.close()
    pg=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
    results.append(inspect(pg,'mobile-editable-inlined',inline_editable(),{'width':390,'height':844},ROOT/'reports/mobile.png'))
    pg.close(); browser.close()
OUT.write_text(json.dumps({'status':'pass' if all(not r['errors'] and not r['broken_images'] and not r['horizontal_overflow'] for r in results) else 'fail','results':results},indent=2),encoding='utf-8')
print(OUT.read_text())
