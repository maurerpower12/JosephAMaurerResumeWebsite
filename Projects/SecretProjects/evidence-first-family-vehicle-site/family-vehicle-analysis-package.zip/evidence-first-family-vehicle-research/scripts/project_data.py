from __future__ import annotations

RUN_DATE = "2026-08-24"
ACCESS_DATE = "2026-08-24"
RUN_ID = "RUN-FVR-20260824-001"

GLOBAL_ASSUMPTIONS = {
    "sales_tax_rate": 0.091,
    "gas_price_per_gallon": 5.121,
    "home_electricity_per_kwh": 0.141598,
    "public_dcfc_per_kwh": 0.572,
    "ev_wall_to_wheels_efficiency": 0.90,
    "annual_miles": 8000,
    "annual_miles_low": 6000,
    "annual_miles_high": 9000,
    "city_share": 0.70,
    "highway_share": 0.30,
    "ev_home_share": 0.90,
    "ev_public_share": 0.10,
    "simulation_seed": 20260824,
    "simulation_iterations": 5000,
}

SOURCE_DEFS = [
    # Core primary safety sources.
    ("SRC-0001", "2024 Toyota Sienna ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/toyota/sienna-minivan/2024", "safety_rating", 1, "2024", ["Toyota Sienna"]),
    ("SRC-0002", "2024 Kia Telluride ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/kia/telluride-4-door-suv/2024", "safety_rating", 1, "2024", ["Kia Telluride"]),
    ("SRC-0003", "2024 Honda Pilot ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/honda/pilot-4-door-suv/2024", "safety_rating", 1, "2024", ["Honda Pilot"]),
    ("SRC-0004", "2024 Ford Explorer ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/ford/explorer-4-door-suv/2024", "safety_rating", 1, "2024", ["Ford Explorer"]),
    ("SRC-0005", "2024 Nissan Pathfinder ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/nissan/pathfinder-4-door-suv/2024", "safety_rating", 1, "2024", ["Nissan Pathfinder"]),
    ("SRC-0006", "2024 Kia EV9 ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/kia/ev9/2024", "safety_rating", 1, "2024", ["Kia EV9"]),
    ("SRC-0007", "2024 Volkswagen Atlas ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/volkswagen/atlas-4-door-suv/2024", "safety_rating", 1, "2024", ["Volkswagen Atlas"]),
    ("SRC-0008", "2024 Hyundai Palisade ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/hyundai/palisade-4-door-suv/2024", "safety_rating", 1, "2024", ["Hyundai Palisade"]),
    ("SRC-0009", "2024 Subaru Ascent ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/subaru/ascent-4-door-suv/2024", "safety_rating", 1, "2024", ["Subaru Ascent"]),
    ("SRC-0010", "2024 Chrysler Pacifica ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/chrysler/pacifica-minivan/2024", "safety_rating", 1, "2024", ["Chrysler Pacifica"]),
    ("SRC-0011", "2024 Buick Enclave ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/buick/enclave-4-door-suv/2024", "safety_rating", 1, "2024", ["Buick Enclave"]),
    ("SRC-0012", "2024 Acura MDX SH-AWD NHTSA record", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/ACURA/MDX/SUV/AWD", "government_safety", 1, "2024 SH-AWD", ["Acura MDX"]),
    ("SRC-0013", "2024 Toyota Sienna AWD NHTSA record", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/Toyota/Sienna%20Le%20Awd", "government_safety", 1, "2024 AWD", ["Toyota Sienna"]),
    ("SRC-0014", "2024 Kia Telluride AWD NHTSA record", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/KIA/TELLURIDE/SUV/AWD", "government_safety", 1, "2024 AWD", ["Kia Telluride"]),
    ("SRC-0015", "2024 Honda Pilot AWD NHTSA record", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/HONDA/PILOT/SUV/AWD", "government_safety", 1, "2024 AWD", ["Honda Pilot"]),
    ("SRC-0016", "2024 Ford Explorer 4WD NHTSA record", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/FORD/EXPLORER/SUV/4WD", "government_safety", 1, "2024 4WD", ["Ford Explorer"]),
    ("SRC-0017", "2024 Nissan Pathfinder AWD NHTSA record", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/NISSAN/PATHFINDER/SUV/AWD", "government_safety", 1, "2024 AWD", ["Nissan Pathfinder"]),
    ("SRC-0018", "2024 Kia EV9 AWD NHTSA record", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/KIA/EV9/SUV/AWD", "government_safety", 1, "2024 AWD", ["Kia EV9"]),
    ("SRC-0019", "NHTSA ratings-data API documentation", "National Highway Traffic Safety Administration", "https://api.nhtsa.gov/SafetyRatings", "government_api", 1, None, ["All"]),
    ("SRC-0020", "2024 Sienna AWD NHTSA data mirror", "DriveData", "https://www.drivedata.org/car-safety-ratings/l/1491/toyota-sienna-hybrid-2024", "secondary_data_mirror", 2, "2024 AWD", ["Toyota Sienna"]),
    ("SRC-0021", "2024 Telluride AWD NHTSA data mirror", "DriveData", "https://www.drivedata.org/car-safety-ratings/l/1157/kia-telluride-2024", "secondary_data_mirror", 2, "2024 AWD", ["Kia Telluride"]),
    ("SRC-0022", "2024 Pathfinder AWD NHTSA data mirror", "DriveData", "https://www.drivedata.org/car-safety-ratings/l/1331/nissan-pathfinder-2024", "secondary_data_mirror", 2, "2024 AWD", ["Nissan Pathfinder"]),
    ("SRC-0023", "2024 EV9 AWD NHTSA data mirror", "DriveData", "https://www.drivedata.org/car-safety-ratings/l/1135/kia-ev9-2024", "secondary_data_mirror", 2, "2024 AWD", ["Kia EV9"]),

    # Manufacturer/specification and energy sources.
    ("SRC-0024", "2024 Toyota Sienna product overview", "Toyota Motor North America", "https://pressroom.toyota.com/seize-the-day-in-style-with-the-2024-toyota-sienna/", "manufacturer_specification", 1, "2024", ["Toyota Sienna"]),
    ("SRC-0025", "2024 Honda Pilot build and price", "American Honda Motor Co.", "https://automobiles.honda.com/tools/build-and-price-trimwalk?modelseries=pilot&modelyear=2024", "manufacturer_configurator", 1, "2024", ["Honda Pilot"]),
    ("SRC-0026", "2024 Kia Telluride specifications", "Kia America", "https://www.kia.com/us/en/telluride/2024/specs", "manufacturer_specification", 1, "2024", ["Kia Telluride"]),
    ("SRC-0027", "2024 Ford Explorer specifications", "Ford Motor Company", "https://media.ford.com/content/dam/fordmedia/North%20America/US/product/2024/explorer/2024-Ford-Explorer-Tech-Specs.pdf", "manufacturer_specification", 1, "2024", ["Ford Explorer"]),
    ("SRC-0028", "2024 Nissan Pathfinder brochure", "Nissan North America", "https://www.nissanusa.com/content/dam/Nissan/us/vehicle-brochures/2024/2024-nissan-pathfinder-brochure-en.pdf", "manufacturer_specification", 1, "2024", ["Nissan Pathfinder"]),
    ("SRC-0029", "2024 Kia EV9 consumer handout", "Kia America", "https://www.rosevillekia.com/static/dealer-18027/ev9/2024_EV9_Consumer_Handout_Draft_Sep_20_2023.pdf", "manufacturer_specification", 1, "2024", ["Kia EV9"]),
    ("SRC-0030", "Fuel economy of 2024 Kia EV9", "U.S. Department of Energy / EPA", "https://www.fueleconomy.gov/feg/PowerSearch.do?action=noform&baseModel=EV9&make=Kia&year1=2024&year2=2024", "government_energy", 1, "2024", ["Kia EV9"]),
    ("SRC-0031", "Fuel economy of 2024 Toyota Sienna", "U.S. Department of Energy / EPA", "https://www.fueleconomy.gov/feg/Find.do?action=sbs&id=46926", "government_energy", 1, "2024 AWD", ["Toyota Sienna"]),
    ("SRC-0032", "Fuel economy of 2024 Kia Telluride", "U.S. Department of Energy / EPA", "https://www.fueleconomy.gov/feg/Find.do?action=sbs&id=46941", "government_energy", 1, "2024 AWD", ["Kia Telluride"]),
    ("SRC-0033", "Fuel economy of 2024 Honda Pilot", "U.S. Department of Energy / EPA", "https://www.fueleconomy.gov/feg/Find.do?action=sbs&id=46898", "government_energy", 1, "2024 AWD", ["Honda Pilot"]),
    ("SRC-0034", "Fuel economy of 2024 Ford Explorer", "U.S. Department of Energy / EPA", "https://www.fueleconomy.gov/feg/Find.do?action=sbs&id=47133", "government_energy", 1, "2024 4WD", ["Ford Explorer"]),
    ("SRC-0035", "Fuel economy of 2024 Nissan Pathfinder", "U.S. Department of Energy / EPA", "https://www.fueleconomy.gov/feg/Find.do?action=sbs&id=47103", "government_energy", 1, "2024 4WD", ["Nissan Pathfinder"]),
    ("SRC-0036", "2024 Honda Pilot interior dimensions", "Honda of Turnersville", "https://www.hondaofturnersville.com/2024-honda-pilot-interior/", "authorized_dealer_specification", 4, "2024", ["Honda Pilot"]),
    ("SRC-0037", "2024 Ford Explorer interior dimensions", "Anderson Ford Kingman", "https://www.andersonfordkingman.com/2024-ford-explorer-interior/", "authorized_dealer_specification", 4, "2024", ["Ford Explorer"]),
    ("SRC-0038", "Kia EV9 interior dimensions", "Kia of Riverdale", "https://www.kiaofriverdale.com/kia-research/kia-ev9-interior/", "authorized_dealer_specification", 4, "2024", ["Kia EV9"]),

    # Reliability, recalls, campaigns and owner-pattern synthesis.
    ("SRC-0039", "2024 Toyota Sienna reliability synthesis", "Auto Reliability Index", "https://autoreliabilityindex.com/toyota/sienna/2024", "derived_nhtsa_owner_dataset", 3, "2024", ["Toyota Sienna"]),
    ("SRC-0040", "2024 Kia Telluride reliability synthesis", "Auto Reliability Index", "https://autoreliabilityindex.com/kia/telluride/2024", "derived_nhtsa_owner_dataset", 3, "2024", ["Kia Telluride"]),
    ("SRC-0041", "2024 Honda Pilot reliability synthesis", "Auto Reliability Index", "https://autoreliabilityindex.com/honda/pilot/2024", "derived_nhtsa_owner_dataset", 3, "2024", ["Honda Pilot"]),
    ("SRC-0042", "2024 Ford Explorer reliability synthesis", "Auto Reliability Index", "https://autoreliabilityindex.com/ford/explorer/2024", "derived_nhtsa_owner_dataset", 3, "2024", ["Ford Explorer"]),
    ("SRC-0043", "2024 Nissan Pathfinder reliability synthesis", "Auto Reliability Index", "https://autoreliabilityindex.com/nissan/pathfinder/2024", "derived_nhtsa_owner_dataset", 3, "2024", ["Nissan Pathfinder"]),
    ("SRC-0044", "2024 Kia EV9 reliability synthesis", "Auto Reliability Index", "https://autoreliabilityindex.com/kia/ev9/2024", "derived_nhtsa_owner_dataset", 3, "2024", ["Kia EV9"]),
    ("SRC-0045", "2024 Telluride recalls and owner complaints", "Vehicle Safety Hub", "https://www.vehiclesafetyhub.com/kia/telluride/2024", "derived_nhtsa_dataset", 3, "2024", ["Kia Telluride"]),
    ("SRC-0046", "2024 Pathfinder recalls and owner complaints", "Vehicle Safety Hub", "https://www.vehiclesafetyhub.com/nissan/pathfinder/2024", "derived_nhtsa_dataset", 3, "2024", ["Nissan Pathfinder"]),
    ("SRC-0047", "2024 Kia EV9 NHTSA-derived issue review", "ProblemsByVin", "https://problemsbyvin.com/2024-kia-ev9/", "derived_nhtsa_dataset", 3, "2024", ["Kia EV9"]),
    ("SRC-0048", "EV9 ICCU logic improvement service action SA568", "Kia America via NHTSA TSB repository", "https://static.nhtsa.gov/odi/tsbs/2024/MC-10253541-0001.pdf", "manufacturer_service_bulletin", 1, "2024 EV9 built 2023-09-25 through 2024-03-21", ["Kia EV9"]),
    ("SRC-0049", "2024 Honda Pilot recalls and complaints", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/HONDA/PILOT/SUV/AWD#recalls", "government_recall_database", 1, "2024 AWD", ["Honda Pilot"]),
    ("SRC-0050", "2024 Ford Explorer recalls and complaints", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/FORD/EXPLORER/SUV/4WD#recalls", "government_recall_database", 1, "2024 4WD", ["Ford Explorer"]),

    # Used-market listing sources, exact URLs retained even when sold/expired.
    ("SRC-0051", "2024 Toyota Sienna Platinum AWD listing", "CarMax", "https://www.carmax.com/car/70145488", "live_listing", 4, "2024 Platinum AWD", ["Toyota Sienna"]),
    ("SRC-0052", "2024 Toyota Sienna Platinum listing", "Carvana", "https://www.carvana.com/vehicle/4618929", "live_listing", 4, "2024 Platinum AWD", ["Toyota Sienna"]),
    ("SRC-0053", "2024 Toyota Sienna Platinum CPO listing", "Toyota of Erie", "https://www.toyotaoferie.com/viewdetails/cpo/5tdeskfc3rs130913/2024-toyota-sienna-mini-van,-passenger", "certified_pre_owned_listing", 4, "2024 Platinum AWD", ["Toyota Sienna"]),
    ("SRC-0054", "2024 Kia Telluride SX Prestige X-Pro listing", "CarMax", "https://www.carmax.com/car/70135597", "live_listing", 4, "2024 SX Prestige X-Pro AWD", ["Kia Telluride"]),
    ("SRC-0055", "2024 Kia Telluride SX Prestige X-Pro listing", "Carvana", "https://www.carvana.com/vehicle/4553664", "live_listing", 4, "2024 SX Prestige X-Pro AWD", ["Kia Telluride"]),
    ("SRC-0056", "2024 Kia Telluride SX Prestige X-Pro listing", "Transitowne Kia", "https://www.transitownewilliamsville.com/inventory/used-2024-kia-telluride-sx-prestige-x-pro-awd-sport-utility-5xyp5dgc0rg414720/", "authorized_dealer_listing", 4, "2024 SX Prestige X-Pro AWD", ["Kia Telluride"]),
    ("SRC-0057", "2024 Honda Pilot Elite AWD listing", "CarMax", "https://www.carmax.com/car/28666081", "live_listing", 4, "2024 Elite AWD", ["Honda Pilot"]),
    ("SRC-0058", "2024 Honda Pilot Elite AWD listing", "Carvana", "https://www.carvana.com/vehicle/4558078", "live_listing", 4, "2024 Elite AWD", ["Honda Pilot"]),
    ("SRC-0059", "2024 Honda Pilot Elite AWD inventory result", "Community Honda", "https://www.communityhondacars.com/search/used-honda-pilot-cedar-falls-ia/?cy=50614&md=133&tp=used", "authorized_dealer_search_result", 4, "2024 Elite AWD", ["Honda Pilot"]),
    ("SRC-0060", "2024 Ford Explorer Platinum 4WD listing", "CarMax", "https://www.carmax.com/car/29064605", "live_listing", 4, "2024 Platinum 4WD", ["Ford Explorer"]),
    ("SRC-0061", "2024 Ford Explorer Platinum 4WD listing", "Carvana", "https://www.carvana.com/vehicle/4493520", "live_listing", 4, "2024 Platinum 4WD", ["Ford Explorer"]),
    ("SRC-0062", "2024 Ford Explorer Platinum CPO listing", "Spitzer Ford Hartville", "https://www.spitzerfordhartville.com/inventory/certified-used-2024-ford-explorer-platinum-4wd-4d-sport-utility-1fm5k8hc3rga84909/", "certified_pre_owned_listing", 4, "2024 Platinum 4WD", ["Ford Explorer"]),
    ("SRC-0063", "2024 Nissan Pathfinder Platinum 4WD listing", "CarMax", "https://www.carmax.com/car/70112041", "live_listing", 4, "2024 Platinum 4WD", ["Nissan Pathfinder"]),
    ("SRC-0064", "2024 Nissan Pathfinder Platinum 4WD listing", "CarMax", "https://www.carmax.com/car/28886620", "live_listing", 4, "2024 Platinum 4WD", ["Nissan Pathfinder"]),
    ("SRC-0065", "2024 Nissan Pathfinder Platinum CPO listing", "Nissan Certified Pre-Owned", "https://www.nissanusa.com/shopping-tools/search-inventory/certified-pre-owned/vehicle-details/5N1DR3DK4RC234041", "certified_pre_owned_listing", 4, "2024 Platinum 4WD", ["Nissan Pathfinder"]),
    ("SRC-0066", "2024 Kia EV9 Land AWD CPO listing", "Kia of Cerritos", "https://www.kiacerritos.com/inventory/certified-used-2024-kia-ev9-land-awd-4d-sport-utility-kndadfs54r6029435/", "certified_pre_owned_listing", 4, "2024 Land AWD", ["Kia EV9"]),
    ("SRC-0067", "2024 Kia EV9 Land AWD listing", "Kia Santa Monica", "https://www.kiasantamonica.com/auto/preowned-2024-kia-ev9-land-near-los-angeles-ca/121571693/", "authorized_dealer_listing", 4, "2024 Land AWD", ["Kia EV9"]),
    ("SRC-0068", "2024 Kia EV9 Land AWD CPO listing", "Towbin Kia", "https://www.towbinkia.com/inventory/certified-used-2024-kia-ev9-land-awd-4d-sport-utility-kndadfs53r6028891/", "certified_pre_owned_listing", 4, "2024 Land AWD", ["Kia EV9"]),

    # Location and cost-model sources.
    ("SRC-0069", "Maple Valley Q3 2026 local sales and use tax rate", "Washington State Department of Revenue", "https://dor.wa.gov/sites/default/files/2026-06/Q326_LSU.pdf", "government_tax", 1, "Q3 2026", ["TCO"]),
    ("SRC-0070", "Weekly Washington gasoline price", "U.S. Energy Information Administration", "https://www.eia.gov/petroleum/gasdiesel/", "government_energy_price", 1, "2026-08-17", ["TCO"]),
    ("SRC-0071", "Regional Transit Authority motor vehicle excise tax", "Washington State Department of Licensing", "https://dol.wa.gov/vehicles-and-boats/taxes-fuel-tax-and-other-fees/regional-transit-authority-rta-tax", "government_registration", 1, "2026", ["TCO"]),
    ("SRC-0072", "PSE Schedule 7 residential electricity tariff", "Puget Sound Energy", "https://www.pse.com/-/media/Project/PSE/Portal/Rate-documents/Electric/elec_sch_007.pdf?sc_lang=en", "regulated_utility_tariff", 1, "effective 2026-01-29", ["TCO"]),
    ("SRC-0073", "Washington public DC fast-charging planning price", "Washington State Department of Transportation", "https://wsdot.wa.gov/construction-planning/statewide-plans/national-electric-vehicle-infrastructure-plan", "government_charging", 1, "2026 planning", ["TCO"]),

    # Elimination and reserve evidence.
    ("SRC-0074", "2024 Lincoln Aviator ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/lincoln/aviator-4-door-suv/2024", "safety_rating", 1, "2024", ["Lincoln Aviator"]),
    ("SRC-0075", "2024 GMC Acadia ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/gmc/acadia-4-door-suv/2024", "safety_rating", 1, "2024", ["GMC Acadia"]),
    ("SRC-0076", "2024 Chevrolet Traverse ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/chevrolet/traverse-4-door-suv/2024", "safety_rating", 1, "2024", ["Chevrolet Traverse"]),
    ("SRC-0077", "2024 Toyota Grand Highlander ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/toyota/grand-highlander-4-door-suv/2024", "safety_rating", 1, "2024", ["Toyota Grand Highlander"]),
    ("SRC-0078", "2024 Toyota Highlander ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/toyota/highlander-4-door-suv/2024", "safety_rating", 1, "2024", ["Toyota Highlander"]),
    ("SRC-0079", "2024 Mazda CX-90 ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/mazda/cx-90-4-door-suv/2024", "safety_rating", 1, "2024", ["Mazda CX-90"]),
    ("SRC-0080", "2024 Volvo XC90 ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/volvo/xc90-4-door-suv/2024", "safety_rating", 1, "2024", ["Volvo XC90"]),
    ("SRC-0081", "2024 Audi Q7 ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/audi/q7-4-door-suv/2024", "safety_rating", 1, "2024", ["Audi Q7"]),
    ("SRC-0082", "2024 Infiniti QX60 ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/infiniti/qx60-4-door-suv/2024", "safety_rating", 1, "2024", ["Infiniti QX60"]),
    ("SRC-0083", "2024 Hyundai Santa Fe ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/hyundai/santa-fe-4-door-suv/2024", "safety_rating", 1, "2024", ["Hyundai Santa Fe"]),
    ("SRC-0084", "2024 Mitsubishi Outlander ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/mitsubishi/outlander-4-door-suv/2024", "safety_rating", 1, "2024", ["Mitsubishi Outlander"]),
    ("SRC-0085", "2024 Jeep Grand Cherokee L ratings", "Insurance Institute for Highway Safety", "https://www.iihs.org/ratings/vehicle/jeep/grand-cherokee-l-4-door-suv/2024", "safety_rating", 1, "2024", ["Jeep Grand Cherokee L"]),
    ("SRC-0086", "2024 Rivian R1S NHTSA record", "National Highway Traffic Safety Administration", "https://www.nhtsa.gov/vehicle/2024/RIVIAN/R1S/SUV/AWD", "government_safety", 1, "2024 AWD", ["Rivian R1S"]),
    ("SRC-0087", "2024 model specifications summary", "Edmunds", "https://www.edmunds.com/car-comparisons/", "independent_specification", 2, "2024", ["Candidate screening"]),
]

CANDIDATES = [
    {
        "vehicle_id": "VEH-HONDA-PILOT-2024-ELITE-AWD",
        "make": "Honda", "model": "Pilot", "model_year": 2024, "trim": "Elite", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "High family usability, removable second-row center seat, preferred brand, qualifying safety.",
        "screen_outcome": "deep_research", "screen_note": "Passed low-cost screen; selected for exact-family-usability test."
    },
    {
        "vehicle_id": "VEH-KIA-TELLURIDE-2024-SX-PRESTIGE-XPRO-AWD",
        "make": "Kia", "model": "Telluride", "model_year": 2024, "trim": "SX Prestige X-Pro", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "Strong safety results, family equipment, broad used supply.",
        "screen_outcome": "deep_research", "screen_note": "Passed low-cost screen; chosen as safety/feature benchmark."
    },
    {
        "vehicle_id": "VEH-HYUNDAI-PALISADE-2024-CALLIGRAPHY-AWD",
        "make": "Hyundai", "model": "Palisade", "model_year": 2024, "trim": "Calligraphy", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "Preferred brand, strong feature set, close Telluride sibling.",
        "screen_outcome": "reserve", "screen_note": "Qualifying award but Poor updated moderate-overlap result made it a weaker safety benchmark than Telluride."
    },
    {
        "vehicle_id": "VEH-VOLKSWAGEN-ATLAS-2024-SEL-PREMIUM-RLINE-4MOTION",
        "make": "Volkswagen", "model": "Atlas", "model_year": 2024, "trim": "SEL Premium R-Line", "drivetrain": "4MOTION AWD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "Preferred brand, class-leading packaging and cargo.",
        "screen_outcome": "eliminated", "screen_note": "Third-row seats are tether-only in IIHS map; no complete row-3 LATCH position."
    },
    {
        "vehicle_id": "VEH-NISSAN-PATHFINDER-2024-PLATINUM-4WD-POSTNOV23",
        "make": "Nissan", "model": "Pathfinder", "model_year": 2024, "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "Preferred brand, LATCH AND GLIDE access, low used acquisition cost.",
        "screen_outcome": "deep_research", "screen_note": "Conditional on build after November 2023 for IIHS award applicability."
    },
    {
        "vehicle_id": "VEH-SUBARU-ASCENT-2024-TOURING-AWD",
        "make": "Subaru", "model": "Ascent", "model_year": 2024, "trim": "Touring", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "Standard AWD, strong IIHS record and PNW fit.",
        "screen_outcome": "reserve", "screen_note": "Passed preliminary screen but did not displace more differentiated deep candidates."
    },
    {
        "vehicle_id": "VEH-FORD-EXPLORER-2024-PLATINUM-4WD",
        "make": "Ford", "model": "Explorer", "model_year": 2024, "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "Preferred brand, strong exact-year IIHS results and broad service network.",
        "screen_outcome": "deep_research", "screen_note": "Passed low-cost screen; selected as domestic SUV benchmark."
    },
    {
        "vehicle_id": "VEH-BUICK-ENCLAVE-2024-AVENIR-AWD",
        "make": "Buick", "model": "Enclave", "model_year": 2024, "trim": "Avenir", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "GM preference, spacious cabin and used value.",
        "screen_outcome": "eliminated", "screen_note": "No 2024 IIHS Top Safety Pick or Top Safety Pick+ award."
    },
    {
        "vehicle_id": "VEH-TOYOTA-SIENNA-2024-PLATINUM-AWD",
        "make": "Toyota", "model": "Sienna", "model_year": 2024, "trim": "Platinum", "drivetrain": "AWD", "powertrain": "hybrid",
        "body_style": "minivan", "universe_reason": "Preferred brand, exceptional family access, cargo and fuel efficiency.",
        "screen_outcome": "deep_research", "screen_note": "Passed low-cost screen; selected as minivan/hybrid benchmark."
    },
    {
        "vehicle_id": "VEH-CHRYSLER-PACIFICA-2024-LIMITED-AWD",
        "make": "Chrysler", "model": "Pacifica", "model_year": 2024, "trim": "Limited", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "minivan", "universe_reason": "Only other AWD minivan in scope; strong cargo and access.",
        "screen_outcome": "reserve", "screen_note": "Preliminary eligibility pass; Sienna offered stronger efficiency and maturity for the same body-style hypothesis."
    },
    {
        "vehicle_id": "VEH-KIA-EV9-2024-LAND-AWD-POSTJAN24",
        "make": "Kia", "model": "EV9", "model_year": 2024, "trim": "Land", "drivetrain": "AWD", "powertrain": "electric",
        "body_style": "three-row electric crossover", "universe_reason": "Home charging already installed; only broadly available used three-row EV near budget with complete safety evidence.",
        "screen_outcome": "deep_research", "screen_note": "Conditional on build after January 2024 and completion of all campaigns/recalls."
    },
    {
        "vehicle_id": "VEH-ACURA-MDX-2024-ADVANCE-SHAWD",
        "make": "Acura", "model": "MDX", "model_year": 2024, "trim": "Advance", "drivetrain": "SH-AWD", "powertrain": "gas",
        "body_style": "near-luxury three-row crossover", "universe_reason": "Preferred brand and removable second-row center seat.",
        "screen_outcome": "eliminated", "screen_note": "Exact AWD NHTSA overall rating is not available; unrated policy is conditional-not-pass."
    },
    {
        "vehicle_id": "VEH-LINCOLN-AVIATOR-2024-RESERVE-AWD",
        "make": "Lincoln", "model": "Aviator", "model_year": 2024, "trim": "Reserve", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "luxury three-row crossover", "universe_reason": "Near-luxury alternative with strong space and used depreciation.",
        "screen_outcome": "eliminated", "screen_note": "No qualifying 2024 IIHS award."
    },
    {
        "vehicle_id": "VEH-GMC-ACADIA-2024-DENALI-AWD",
        "make": "GMC", "model": "Acadia", "model_year": 2024, "trim": "Denali", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "GM preference and redesigned packaging.",
        "screen_outcome": "eliminated", "screen_note": "No qualifying 2024 IIHS award for the exact redesigned model."
    },
    {
        "vehicle_id": "VEH-CHEVROLET-TRAVERSE-2024-Z71-AWD",
        "make": "Chevrolet", "model": "Traverse", "model_year": 2024, "trim": "Z71", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "GM preference, large cargo volume, family packaging.",
        "screen_outcome": "eliminated", "screen_note": "No qualifying 2024 IIHS award for the exact model year."
    },
    {
        "vehicle_id": "VEH-TOYOTA-GRAND-HIGHLANDER-2024-HYBRID-LIMITED-AWD",
        "make": "Toyota", "model": "Grand Highlander Hybrid", "model_year": 2024, "trim": "Limited", "drivetrain": "AWD", "powertrain": "hybrid",
        "body_style": "three-row crossover", "universe_reason": "Preferred brand, hybrid efficiency and strong cargo packaging.",
        "screen_outcome": "eliminated", "screen_note": "No qualifying exact-year IIHS award under the frozen gate."
    },
    {
        "vehicle_id": "VEH-TOYOTA-HIGHLANDER-2024-HYBRID-PLATINUM-AWD",
        "make": "Toyota", "model": "Highlander Hybrid", "model_year": 2024, "trim": "Platinum", "drivetrain": "AWD", "powertrain": "hybrid",
        "body_style": "three-row crossover", "universe_reason": "Preferred brand, proven hybrid and used availability.",
        "screen_outcome": "eliminated", "screen_note": "Third row does not provide a complete LATCH position in the researched configuration."
    },
    {
        "vehicle_id": "VEH-MAZDA-CX90-2024-PHEV-PREMIUMPLUS-AWD",
        "make": "Mazda", "model": "CX-90 PHEV", "model_year": 2024, "trim": "Premium Plus", "drivetrain": "AWD", "powertrain": "plug-in hybrid",
        "body_style": "three-row crossover", "universe_reason": "Preferred brand and PHEV alternative leveraging home charging.",
        "screen_outcome": "eliminated", "screen_note": "Official cargo behind row 3 is below 16 cubic feet."
    },
    {
        "vehicle_id": "VEH-VOLVO-XC90-2024-RECHARGE-PLUS-AWD",
        "make": "Volvo", "model": "XC90 Recharge", "model_year": 2024, "trim": "Plus", "drivetrain": "AWD", "powertrain": "plug-in hybrid",
        "body_style": "luxury three-row crossover", "universe_reason": "Preferred brand, PHEV and strong safety reputation.",
        "screen_outcome": "eliminated", "screen_note": "Cargo behind row 3 is below 16 cubic feet and row-3 complete LATCH applicability is configuration-limited."
    },
    {
        "vehicle_id": "VEH-AUDI-Q7-2024-PRESTIGE-QUATTRO",
        "make": "Audi", "model": "Q7", "model_year": 2024, "trim": "Prestige", "drivetrain": "quattro AWD", "powertrain": "gas",
        "body_style": "luxury three-row crossover", "universe_reason": "Near-luxury used-market alternative with AWD.",
        "screen_outcome": "eliminated", "screen_note": "Cargo behind row 3 is below 16 cubic feet."
    },
    {
        "vehicle_id": "VEH-INFINITI-QX60-2024-AUTOGRAPH-AWD",
        "make": "Infiniti", "model": "QX60", "model_year": 2024, "trim": "Autograph", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "near-luxury three-row crossover", "universe_reason": "Near-luxury Pathfinder-relative with used depreciation.",
        "screen_outcome": "eliminated", "screen_note": "Cargo behind row 3 is below 16 cubic feet."
    },
    {
        "vehicle_id": "VEH-HYUNDAI-SANTAFE-2024-CALLIGRAPHY-AWD",
        "make": "Hyundai", "model": "Santa Fe", "model_year": 2024, "trim": "Calligraphy", "drivetrain": "AWD", "powertrain": "gas",
        "body_style": "compact three-row crossover", "universe_reason": "Preferred brand, efficient packaging and strong feature value.",
        "screen_outcome": "eliminated", "screen_note": "Cargo behind row 3 is below 16 cubic feet."
    },
    {
        "vehicle_id": "VEH-MITSUBISHI-OUTLANDER-2024-PHEV-SEL-PREMIUM-AWD",
        "make": "Mitsubishi", "model": "Outlander PHEV", "model_year": 2024, "trim": "SEL Premium", "drivetrain": "S-AWC", "powertrain": "plug-in hybrid",
        "body_style": "compact three-row crossover", "universe_reason": "PHEV and AWD with home charging compatibility.",
        "screen_outcome": "eliminated", "screen_note": "Third row/cargo package does not meet the usable-space and 16-cubic-foot threshold."
    },
    {
        "vehicle_id": "VEH-JEEP-GRANDCHEROKEEL-2024-SUMMIT-4X4",
        "make": "Jeep", "model": "Grand Cherokee L", "model_year": 2024, "trim": "Summit", "drivetrain": "4x4", "powertrain": "gas",
        "body_style": "three-row crossover", "universe_reason": "Premium-adjacent 4WD alternative with broad used supply.",
        "screen_outcome": "eliminated", "screen_note": "No qualifying exact-year IIHS award."
    },
    {
        "vehicle_id": "VEH-RIVIAN-R1S-2024-DUAL-AWD",
        "make": "Rivian", "model": "R1S", "model_year": 2024, "trim": "Dual-Motor", "drivetrain": "AWD", "powertrain": "electric",
        "body_style": "luxury three-row electric crossover", "universe_reason": "EV alternative with strong packaging and home charging fit.",
        "screen_outcome": "eliminated", "screen_note": "Exact NHTSA overall rating is not available; unrated policy is conditional-not-pass."
    },
]

DEEP_VEHICLES = {
    "VEH-TOYOTA-SIENNA-2024-PLATINUM-AWD": {
        "short_name": "2024 Toyota Sienna Platinum AWD",
        "make": "Toyota", "model": "Sienna", "year": 2024, "trim": "Platinum", "drivetrain": "AWD", "powertrain": "hybrid", "seats": 7,
        "configuration_condition": "Verify exact AWD Platinum configuration and open recalls by VIN.",
        "eligibility": {
            "third_row": ("pass", True, "Normal three-row minivan configuration."),
            "nhtsa_overall": ("pass", 5, "Exact 2024 AWD record corroborated by NHTSA record and public data mirror."),
            "iihs_award": ("pass", "Top Safety Pick", "Exact 2024 award."),
            "row2_complete_latch": ("pass", 3, "At least three complete positions in row 2."),
            "row3_complete_latch": ("pass", 2, "Two complete positions in row 3."),
            "cargo_behind_row3": ("pass", 33.5, "Manufacturer cargo volume with row 3 raised."),
            "awd_or_4wd": ("pass", "AWD", "Electronic on-demand AWD."),
            "price_ceiling": ("pass", 52995, "Normalized used-market acquisition price."),
            "model_year": ("pass", 2024, "Inside frozen 2023-2025 scope."),
            "reliability_exclusion": ("pass", "no_exclusion", "No sufficiently supported systemic pattern making ownership unreasonable."),
            "overall": "pass",
        },
        "safety": {"award": "Top Safety Pick", "test_quality": "any_marginal_or_poor", "pedestrian_strong": False, "v2v_aeb": True, "bsm": True, "rcta": True,
                   "rear_occupant": True, "safe_exit": False, "driver_attention": False, "surround_view": True, "latch_quality": "excellent_access_and_4_or_more_complete_positions"},
        "reliability": {"predicted": "above_average", "maturity": "established_platform_and_powertrain_3plus_years", "recalls": "minor_or_resolved_pattern", "owner_pattern": "no_meaningful_recurring_pattern",
                        "summary": "Mature Toyota hybrid platform; complaints exist but no material recurring pattern sufficient for exclusion."},
        "space": {"third_row_legroom": 38.7, "third_row_usability": "adult_usable_for_extended_trip", "sliding_second_row": True, "multiple_configurations": False, "entry_exit": "easy"},
        "cargo": {"volume": 33.5, "low_floor": True, "underfloor": False, "power_third_row": False, "good_shape": True},
        "energy": {"city_mpg": 35, "highway_mpg": 36, "kwh_per_100mi": None},
        "comfort": {"row2_vents": True, "row3_vents": True, "ceiling_vents": True, "ride": "generally_good", "noise": "average", "seats": "consistently_praised"},
        "technology": {"surround_view": True, "wireless_carplay": False, "adaptive_lane_centering": True, "family_camera": False, "ota": False, "digital_key": False, "physical_controls": True},
        "price": {"low": 48990, "base": 52995, "high": 58990, "confidence": "medium", "price_record_ids": ["PRC-0001", "PRC-0002", "PRC-0003"]},
        "tco_inputs": {"maintenance_5": 3000, "maintenance_10": 8500, "repairs_5": 1500, "repairs_10": 8000, "tires_5": 2400, "tires_10": 5000, "registration_5": 3500, "registration_10": 5000, "initial_fees": 700, "residual_5": 0.50, "residual_10": 0.25},
        "source_ids": ["SRC-0001", "SRC-0013", "SRC-0020", "SRC-0024", "SRC-0031", "SRC-0039"],
        "advance_reason": "Best physical family utility and hybrid efficiency in the funnel.",
        "major_concern": "High used price and a Marginal updated moderate-overlap result reduce its safety score.",
        "hypothesis": "The minivan packaging advantage may outweigh its lower crash-test score and SUV preference.",
        "elimination_evidence": "Physical test reveals unacceptable seating comfort or safety priorities make the Marginal test result non-negotiable.",
        "regret_case": "The family pays a scarcity premium and later wishes it had chosen an SUV with stronger current crash-test results.",
        "physical_unknowns": ["Fit both installed child seats while preserving third-row access", "Load stroller, dog equipment and travel luggage with row 3 raised", "Confirm second-row ottoman/rail geometry works with chosen car seats"],
    },
    "VEH-KIA-TELLURIDE-2024-SX-PRESTIGE-XPRO-AWD": {
        "short_name": "2024 Kia Telluride SX Prestige X-Pro AWD",
        "make": "Kia", "model": "Telluride", "year": 2024, "trim": "SX Prestige X-Pro", "drivetrain": "AWD", "powertrain": "gas", "seats": 7,
        "configuration_condition": "Verify recall closure and exact feature content by VIN.",
        "eligibility": {
            "third_row": ("pass", True, "Normal three-row configuration."),
            "nhtsa_overall": ("pass", 5, "Exact AWD record corroborated."),
            "iihs_award": ("pass", "Top Safety Pick+", "Exact 2024 award."),
            "row2_complete_latch": ("pass", 2, "Complete LATCH in both second-row captain chairs."),
            "row3_complete_latch": ("pass", 1, "At least one complete position in row 3."),
            "cargo_behind_row3": ("pass", 21.0, "Manufacturer/independent specification."),
            "awd_or_4wd": ("pass", "AWD", "Exact X-Pro configuration is AWD."),
            "price_ceiling": ("pass", 41990, "Normalized used-market price."),
            "model_year": ("pass", 2024, "Inside scope."),
            "reliability_exclusion": ("pass", "no_exclusion_with_conditions", "Multiple recalls and recurring electrical/trim reports require VIN verification but do not establish an unreasonable-ownership pattern."),
            "overall": "pass",
        },
        "safety": {"award": "Top Safety Pick+", "test_quality": "all_applicable_good", "pedestrian_strong": True, "v2v_aeb": True, "bsm": True, "rcta": True,
                   "rear_occupant": True, "safe_exit": True, "driver_attention": True, "surround_view": True, "latch_quality": "good_access_and_3_complete_positions"},
        "reliability": {"predicted": "average_or_mixed", "maturity": "established_platform_and_powertrain_3plus_years", "recalls": "multiple_material_or_unresolved_issues", "owner_pattern": "moderate_recurring_issue",
                        "summary": "Mature platform, but valve-spring, driveshaft, seat-motor and electrical/trim patterns warrant strict VIN and service-history checks."},
        "space": {"third_row_legroom": 31.4, "third_row_usability": "adult_usable_for_short_trip", "sliding_second_row": True, "multiple_configurations": False, "entry_exit": "easy"},
        "cargo": {"volume": 21.0, "low_floor": True, "underfloor": True, "power_third_row": True, "good_shape": True},
        "energy": {"city_mpg": 18, "highway_mpg": 24, "kwh_per_100mi": None},
        "comfort": {"row2_vents": True, "row3_vents": True, "ceiling_vents": True, "ride": "consistently_praised", "noise": "quiet_for_class", "seats": "consistently_praised"},
        "technology": {"surround_view": True, "wireless_carplay": False, "adaptive_lane_centering": True, "family_camera": False, "ota": True, "digital_key": True, "physical_controls": True},
        "price": {"low": 38998, "base": 41990, "high": 42561, "confidence": "medium", "price_record_ids": ["PRC-0004", "PRC-0005", "PRC-0006"]},
        "tco_inputs": {"maintenance_5": 3500, "maintenance_10": 9000, "repairs_5": 2500, "repairs_10": 10000, "tires_5": 3000, "tires_10": 6000, "registration_5": 2700, "registration_10": 4000, "initial_fees": 700, "residual_5": 0.42, "residual_10": 0.20},
        "source_ids": ["SRC-0002", "SRC-0014", "SRC-0021", "SRC-0026", "SRC-0032", "SRC-0040", "SRC-0045"],
        "advance_reason": "Strongest verified safety package and excellent family equipment at a moderate used price.",
        "major_concern": "Recall load and recurring electrical/trim complaints create used-VIN risk.",
        "hypothesis": "It can deliver the best gas-SUV blend if a clean VIN has all campaigns completed.",
        "elimination_evidence": "Unclosed engine/seat/driveshaft recall, repeated cluster failures, or poor third-row access with installed seats.",
        "regret_case": "A recurring electrical fault or recall-related downtime makes the attractive feature set feel fragile.",
        "physical_unknowns": ["Test third-row path with both child seats installed", "Verify X-Pro ride on broken pavement", "Confirm power third-row and underfloor storage on exact VIN"],
    },
    "VEH-HONDA-PILOT-2024-ELITE-AWD": {
        "short_name": "2024 Honda Pilot Elite AWD",
        "make": "Honda", "model": "Pilot", "year": 2024, "trim": "Elite", "drivetrain": "AWD", "powertrain": "gas", "seats": 8,
        "configuration_condition": "Verify recall closure and removable center-seat hardware is present.",
        "eligibility": {
            "third_row": ("pass", True, "Normal three-row configuration."),
            "nhtsa_overall": ("pass", 5, "Exact AWD rating."),
            "iihs_award": ("pass", "Top Safety Pick", "Exact 2024 award."),
            "row2_complete_latch": ("pass", 2, "Two complete second-row positions."),
            "row3_complete_latch": ("pass", 1, "One complete third-row position."),
            "cargo_behind_row3": ("pass", 18.6, "Specification with row 3 raised."),
            "awd_or_4wd": ("pass", "AWD", "Elite is AWD."),
            "price_ceiling": ("pass", 43800, "Normalized used-market price."),
            "model_year": ("pass", 2024, "Inside scope."),
            "reliability_exclusion": ("pass", "no_exclusion_with_conditions", "First-generation-year issues and recalls lower confidence but do not establish unreasonable ownership."),
            "overall": "pass",
        },
        "safety": {"award": "Top Safety Pick", "test_quality": "any_marginal_or_poor", "pedestrian_strong": True, "v2v_aeb": True, "bsm": True, "rcta": True,
                   "rear_occupant": True, "safe_exit": False, "driver_attention": True, "surround_view": True, "latch_quality": "excellent_access_and_4_or_more_complete_positions"},
        "reliability": {"predicted": "average_or_mixed", "maturity": "partially_new_or_significantly_revised", "recalls": "multiple_material_or_unresolved_issues", "owner_pattern": "moderate_recurring_issue",
                        "summary": "2024 is early in the redesigned generation; steering/transmission complaints and recall activity justify a conservative score."},
        "space": {"third_row_legroom": 32.5, "third_row_usability": "adult_usable_for_short_trip", "sliding_second_row": True, "multiple_configurations": True, "entry_exit": "easy"},
        "cargo": {"volume": 18.6, "low_floor": True, "underfloor": True, "power_third_row": False, "good_shape": True},
        "energy": {"city_mpg": 19, "highway_mpg": 25, "kwh_per_100mi": None},
        "comfort": {"row2_vents": True, "row3_vents": True, "ceiling_vents": False, "ride": "generally_good", "noise": "average", "seats": "average_or_mixed"},
        "technology": {"surround_view": True, "wireless_carplay": True, "adaptive_lane_centering": True, "family_camera": False, "ota": False, "digital_key": False, "physical_controls": True},
        "price": {"low": 41998, "base": 43800, "high": 47590, "confidence": "medium_low", "price_record_ids": ["PRC-0007", "PRC-0008", "PRC-0009"]},
        "tco_inputs": {"maintenance_5": 3500, "maintenance_10": 9000, "repairs_5": 2500, "repairs_10": 9500, "tires_5": 2500, "tires_10": 5500, "registration_5": 2800, "registration_10": 4200, "initial_fees": 700, "residual_5": 0.45, "residual_10": 0.22},
        "source_ids": ["SRC-0003", "SRC-0015", "SRC-0025", "SRC-0033", "SRC-0036", "SRC-0041", "SRC-0049"],
        "advance_reason": "Very flexible second row and strong exact-family packaging from a preferred brand.",
        "major_concern": "Updated moderate-overlap result and early-generation reliability evidence cap the score.",
        "hypothesis": "Removable center seat and good access could outperform its numerical score in real family use.",
        "elimination_evidence": "Steering/transmission symptoms, open recalls, or installed child seats block third-row access.",
        "regret_case": "The family chooses the familiar brand but encounters first-generation steering or transmission issues.",
        "physical_unknowns": ["Confirm removable center seat and storage bag are present", "Attempt one-touch entry with actual car seats", "Check third-row comfort for intended passengers"],
    },
    "VEH-FORD-EXPLORER-2024-PLATINUM-4WD": {
        "short_name": "2024 Ford Explorer Platinum 4WD",
        "make": "Ford", "model": "Explorer", "year": 2024, "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas", "seats": 6,
        "configuration_condition": "Verify exact engine, feature content and recall closure by VIN.",
        "eligibility": {
            "third_row": ("pass", True, "Normal three-row configuration."),
            "nhtsa_overall": ("pass", 5, "Exact 4WD rating."),
            "iihs_award": ("pass", "Top Safety Pick+", "Exact 2024 award."),
            "row2_complete_latch": ("pass", 2, "Complete positions in row 2."),
            "row3_complete_latch": ("pass", 2, "Complete positions in row 3."),
            "cargo_behind_row3": ("pass", 18.2, "Specification with row 3 raised."),
            "awd_or_4wd": ("pass", "4WD", "Exact configuration."),
            "price_ceiling": ("pass", 42500, "Normalized used-market price."),
            "model_year": ("pass", 2024, "Inside scope."),
            "reliability_exclusion": ("pass", "no_exclusion_with_conditions", "Recall history and higher repair exposure lower score without proving unreasonable ownership."),
            "overall": "pass",
        },
        "safety": {"award": "Top Safety Pick+", "test_quality": "all_applicable_good", "pedestrian_strong": False, "v2v_aeb": True, "bsm": True, "rcta": True,
                   "rear_occupant": True, "safe_exit": False, "driver_attention": True, "surround_view": True, "latch_quality": "passes_requirement_but_access_is_difficult"},
        "reliability": {"predicted": "average_or_mixed", "maturity": "established_platform_and_powertrain_3plus_years", "recalls": "multiple_material_or_unresolved_issues", "owner_pattern": "moderate_recurring_issue",
                        "summary": "Mature generation but meaningful recall and repair-cost exposure; no single pattern met the exclusion threshold."},
        "space": {"third_row_legroom": 32.2, "third_row_usability": "adult_usable_for_short_trip", "sliding_second_row": True, "multiple_configurations": False, "entry_exit": "average"},
        "cargo": {"volume": 18.2, "low_floor": True, "underfloor": True, "power_third_row": True, "good_shape": True},
        "energy": {"city_mpg": 18, "highway_mpg": 24, "kwh_per_100mi": None},
        "comfort": {"row2_vents": True, "row3_vents": True, "ceiling_vents": True, "ride": "mixed", "noise": "average", "seats": "average_or_mixed"},
        "technology": {"surround_view": True, "wireless_carplay": True, "adaptive_lane_centering": True, "family_camera": False, "ota": True, "digital_key": False, "physical_controls": True},
        "price": {"low": 40590, "base": 42500, "high": 44998, "confidence": "medium", "price_record_ids": ["PRC-0010", "PRC-0011", "PRC-0012"]},
        "tco_inputs": {"maintenance_5": 4000, "maintenance_10": 10500, "repairs_5": 3500, "repairs_10": 14000, "tires_5": 3500, "tires_10": 7000, "registration_5": 2600, "registration_10": 3900, "initial_fees": 700, "residual_5": 0.35, "residual_10": 0.15},
        "source_ids": ["SRC-0004", "SRC-0016", "SRC-0027", "SRC-0034", "SRC-0037", "SRC-0042", "SRC-0050"],
        "advance_reason": "Excellent IIHS crashworthiness and useful cargo at an accessible used price.",
        "major_concern": "Higher long-horizon repair/depreciation exposure and only Acceptable LATCH ease of use.",
        "hypothesis": "Strong safety may compensate for ownership-cost and access compromises.",
        "elimination_evidence": "Difficult car-seat installation, poor ride, open recalls or service history indicating repeat electrical/powertrain work.",
        "regret_case": "Depreciation and repair costs erase the attractive purchase price while the child-seat anchors remain frustrating.",
        "physical_unknowns": ["Install both child seats and inspect buckle/anchor access", "Evaluate ride on rough pavement", "Verify third-row power fold and cargo-floor operation"],
    },
    "VEH-NISSAN-PATHFINDER-2024-PLATINUM-4WD-POSTNOV23": {
        "short_name": "2024 Nissan Pathfinder Platinum 4WD (post-Nov. 2023 build)",
        "make": "Nissan", "model": "Pathfinder", "year": 2024, "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas", "seats": 7,
        "configuration_condition": "Certification-label build date must be after November 2023; verify recalls and rear-brake condition.",
        "eligibility": {
            "third_row": ("pass", True, "Normal three-row configuration."),
            "nhtsa_overall": ("pass", 5, "Exact AWD record corroborated."),
            "iihs_award": ("conditional_pass", "Top Safety Pick+", "Award applies only to vehicles built after November 2023."),
            "row2_complete_latch": ("pass", 2, "Complete positions in row 2."),
            "row3_complete_latch": ("pass", 1, "At least one complete row-3 position."),
            "cargo_behind_row3": ("pass", 16.6, "Just above configured threshold."),
            "awd_or_4wd": ("pass", "4WD", "Exact configuration."),
            "price_ceiling": ("pass", 36998, "Normalized used-market price."),
            "model_year": ("pass", 2024, "Inside scope."),
            "reliability_exclusion": ("pass", "no_exclusion_with_conditions", "Premature rear-brake pattern requires inspection but is not an exclusion-level systemic defect."),
            "overall": "conditional_pass",
        },
        "safety": {"award": "Top Safety Pick+", "test_quality": "all_applicable_good", "pedestrian_strong": True, "v2v_aeb": True, "bsm": True, "rcta": True,
                   "rear_occupant": True, "safe_exit": False, "driver_attention": True, "surround_view": True, "latch_quality": "good_access_and_3_complete_positions"},
        "reliability": {"predicted": "above_average", "maturity": "established_platform_and_powertrain_3plus_years", "recalls": "minor_or_resolved_pattern", "owner_pattern": "moderate_recurring_issue",
                        "summary": "Low recall count and mature platform, offset by a recurring premature rear-brake-wear pattern in complaint data."},
        "space": {"third_row_legroom": 28.0, "third_row_usability": "primarily_child_sized", "sliding_second_row": True, "multiple_configurations": False, "entry_exit": "easy"},
        "cargo": {"volume": 16.6, "low_floor": True, "underfloor": True, "power_third_row": True, "good_shape": False},
        "energy": {"city_mpg": 20, "highway_mpg": 25, "kwh_per_100mi": None},
        "comfort": {"row2_vents": True, "row3_vents": True, "ceiling_vents": False, "ride": "generally_good", "noise": "average", "seats": "average_or_mixed"},
        "technology": {"surround_view": True, "wireless_carplay": True, "adaptive_lane_centering": True, "family_camera": False, "ota": False, "digital_key": False, "physical_controls": True},
        "price": {"low": 35998, "base": 36998, "high": 37500, "confidence": "medium", "price_record_ids": ["PRC-0013", "PRC-0014", "PRC-0015"]},
        "tco_inputs": {"maintenance_5": 3500, "maintenance_10": 9000, "repairs_5": 2500, "repairs_10": 9000, "tires_5": 2500, "tires_10": 5500, "registration_5": 2400, "registration_10": 3500, "initial_fees": 700, "residual_5": 0.38, "residual_10": 0.18},
        "source_ids": ["SRC-0005", "SRC-0017", "SRC-0022", "SRC-0028", "SRC-0035", "SRC-0043", "SRC-0046"],
        "advance_reason": "Lowest acquisition cost, strong exact-build safety and useful child-seat access system.",
        "major_concern": "Cargo barely clears the threshold, third row is child-sized and build date is a hard condition.",
        "hypothesis": "Value and safety can offset its tight rear packaging for this four-person family.",
        "elimination_evidence": "Pre-December-2023 build, worn rear brakes/rotors, or stroller-plus-dog load fails behind row 3.",
        "regret_case": "The family outgrows the tight third row and threshold-level cargo long before the ten-year horizon.",
        "physical_unknowns": ["Read certification-label build month", "Load full travel kit behind row 3", "Measure rear brake pad and rotor condition", "Test LATCH AND GLIDE with actual child seat"],
    },
    "VEH-KIA-EV9-2024-LAND-AWD-POSTJAN24": {
        "short_name": "2024 Kia EV9 Land AWD (post-Jan. 2024 build)",
        "make": "Kia", "model": "EV9", "year": 2024, "trim": "Land", "drivetrain": "AWD", "powertrain": "electric", "seats": 6,
        "configuration_condition": "Build after January 2024; all recall/ICCU/cluster/seat-bolt campaigns closed; battery health and charging verified.",
        "eligibility": {
            "third_row": ("pass", True, "Normal three-row configuration."),
            "nhtsa_overall": ("pass", 5, "Exact AWD record corroborated."),
            "iihs_award": ("conditional_pass", "Top Safety Pick", "Award applies to vehicles built after January 2024."),
            "row2_complete_latch": ("pass", 2, "Complete positions in second-row captain chairs."),
            "row3_complete_latch": ("pass", 2, "Two complete positions in row 3."),
            "cargo_behind_row3": ("pass", 20.2, "Manufacturer handout."),
            "awd_or_4wd": ("pass", "AWD", "Land is dual-motor AWD."),
            "price_ceiling": ("pass", 46112, "Normalized used-market acquisition price."),
            "model_year": ("pass", 2024, "Inside scope."),
            "reliability_exclusion": ("pass", "no_exclusion_but_high_risk", "Strong electrical/ICCU pattern and seven recalls materially reduce score, but campaigns, warranty and available remedies prevent a categorical exclusion at this evidence threshold."),
            "overall": "conditional_pass",
        },
        "safety": {"award": "Top Safety Pick", "test_quality": "all_applicable_good", "pedestrian_strong": True, "v2v_aeb": True, "bsm": True, "rcta": True,
                   "rear_occupant": True, "safe_exit": True, "driver_attention": True, "surround_view": True, "latch_quality": "excellent_access_and_4_or_more_complete_positions"},
        "reliability": {"predicted": "below_average", "maturity": "first_year_platform_or_powertrain", "recalls": "multiple_material_or_unresolved_issues", "owner_pattern": "strong_recurring_material_issue",
                        "summary": "First model year with a strong recurring electrical/ICCU/12V and display complaint pattern; this is the decisive ownership risk."},
        "space": {"third_row_legroom": 30.8, "third_row_usability": "adult_usable_for_extended_trip", "sliding_second_row": True, "multiple_configurations": True, "entry_exit": "easy"},
        "cargo": {"volume": 20.2, "low_floor": True, "underfloor": True, "power_third_row": True, "good_shape": True},
        "energy": {"city_mpg": None, "highway_mpg": None, "kwh_per_100mi": 41.0},
        "comfort": {"row2_vents": True, "row3_vents": True, "ceiling_vents": True, "ride": "consistently_praised", "noise": "quiet_for_class", "seats": "consistently_praised"},
        "technology": {"surround_view": True, "wireless_carplay": True, "adaptive_lane_centering": True, "family_camera": False, "ota": True, "digital_key": True, "physical_controls": True},
        "price": {"low": 44240, "base": 46112, "high": 48291, "confidence": "medium", "price_record_ids": ["PRC-0016", "PRC-0017", "PRC-0018"]},
        "tco_inputs": {"maintenance_5": 2000, "maintenance_10": 5000, "repairs_5": 2500, "repairs_10": 10000, "tires_5": 4000, "tires_10": 8500, "registration_5": 3000, "registration_10": 4500, "initial_fees": 900, "residual_5": 0.30, "residual_10": 0.10},
        "source_ids": ["SRC-0006", "SRC-0018", "SRC-0023", "SRC-0029", "SRC-0030", "SRC-0038", "SRC-0044", "SRC-0047", "SRC-0048"],
        "advance_reason": "Best combination of verified safety, space, energy cost, family LATCH coverage and used-value depreciation.",
        "major_concern": "First-year reliability and electrical/ICCU campaign burden are materially worse than the alternatives.",
        "hypothesis": "A fully updated, post-January-build CPO example can convert first-owner depreciation into a compelling family value.",
        "elimination_evidence": "Pre-February build, incomplete campaigns, repeat 12V/ICCU symptoms, poor battery health, unreliable home charging or unacceptable insurance quote.",
        "regret_case": "Electrical downtime, charging faults or rapid residual-value erosion overwhelm the efficiency and packaging advantages.",
        "physical_unknowns": ["Verify build date and campaign closure in Kia service system", "Run Level 2 and DC fast-charge tests", "Obtain battery state-of-health report", "Load stroller/dog/travel kit", "Obtain exact insurance quote"],
    },
}

PRICE_RECORDS = [
    {
        "price_record_id": "PRC-0001", "vehicle_id": "VEH-TOYOTA-SIENNA-2024-PLATINUM-AWD", "price_type": "live_listing", "source_id": "SRC-0051", "source_domain": "carmax.com",
        "source_url": "https://www.carmax.com/car/70145488", "listing_title": "2024 Toyota Sienna Platinum AWD", "seller_name": "CarMax", "seller_location": "United States / delivery market",
        "stock_number": "70145488", "vin": "5TDCSKFC5RS140155", "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "unknown", "model_year": 2024, "make": "Toyota", "model": "Sienna", "trim": "Platinum", "drivetrain": "AWD", "powertrain": "hybrid", "mileage": 37695, "listed_price": 52998,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "rounding", "amount": -3, "reason": "Median planning estimate rounded across comparable set."}], "notes": "Direct listing URL retained; active status must be rechecked before Q4 purchase."
    },
    {
        "price_record_id": "PRC-0002", "vehicle_id": "VEH-TOYOTA-SIENNA-2024-PLATINUM-AWD", "price_type": "live_listing", "source_id": "SRC-0052", "source_domain": "carvana.com",
        "source_url": "https://www.carvana.com/vehicle/4618929", "listing_title": "2024 Toyota Sienna Platinum AWD", "seller_name": "Carvana", "seller_location": "Online delivery", "stock_number": None, "vin": None,
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "sold", "model_year": 2024, "make": "Toyota", "model": "Sienna", "trim": "Platinum", "drivetrain": "AWD", "powertrain": "hybrid", "mileage": 44725, "listed_price": 53990,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "mileage", "amount": -1500, "reason": "Higher-mile example normalized toward 20k-40k planning band."}], "notes": "Sold comparable; excluded from active availability but retained for market range."
    },
    {
        "price_record_id": "PRC-0003", "vehicle_id": "VEH-TOYOTA-SIENNA-2024-PLATINUM-AWD", "price_type": "certified_pre_owned", "source_id": "SRC-0053", "source_domain": "toyotaoferie.com",
        "source_url": "https://www.toyotaoferie.com/viewdetails/cpo/5tdeskfc3rs130913/2024-toyota-sienna-mini-van,-passenger", "listing_title": "Certified 2024 Toyota Sienna Platinum AWD", "seller_name": "Toyota of Erie", "seller_location": "Erie, Pennsylvania", "stock_number": "T06282A", "vin": "5TDESKFC3RS130913",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "unknown", "model_year": 2024, "make": "Toyota", "model": "Sienna", "trim": "Platinum", "drivetrain": "AWD", "powertrain": "hybrid", "mileage": 30866, "listed_price": 52990,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "certification", "amount": -1000, "reason": "CPO premium separated when estimating a non-CPO base."}], "notes": "Direct CPO listing; status requires refresh."
    },
    {
        "price_record_id": "PRC-0004", "vehicle_id": "VEH-KIA-TELLURIDE-2024-SX-PRESTIGE-XPRO-AWD", "price_type": "live_listing", "source_id": "SRC-0054", "source_domain": "carmax.com",
        "source_url": "https://www.carmax.com/car/70135597", "listing_title": "2024 Kia Telluride SX Prestige X-Pro AWD", "seller_name": "CarMax", "seller_location": "United States / delivery market", "stock_number": "70135597", "vin": "5XYP5DGC1RG429114",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "unknown", "model_year": 2024, "make": "Kia", "model": "Telluride", "trim": "SX Prestige X-Pro", "drivetrain": "AWD", "powertrain": "gas", "mileage": 44445, "listed_price": 38998,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "mileage", "amount": 1500, "reason": "High end of mileage band; upward normalization toward 25k-35k miles."}], "notes": "Direct listing URL retained."
    },
    {
        "price_record_id": "PRC-0005", "vehicle_id": "VEH-KIA-TELLURIDE-2024-SX-PRESTIGE-XPRO-AWD", "price_type": "live_listing", "source_id": "SRC-0055", "source_domain": "carvana.com",
        "source_url": "https://www.carvana.com/vehicle/4553664", "listing_title": "2024 Kia Telluride SX Prestige X-Pro AWD", "seller_name": "Carvana", "seller_location": "Online delivery", "stock_number": None, "vin": None,
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "sold", "model_year": 2024, "make": "Kia", "model": "Telluride", "trim": "SX Prestige X-Pro", "drivetrain": "AWD", "powertrain": "gas", "mileage": 29788, "listed_price": 41990,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [], "notes": "Sold comparable retained in market range."
    },
    {
        "price_record_id": "PRC-0006", "vehicle_id": "VEH-KIA-TELLURIDE-2024-SX-PRESTIGE-XPRO-AWD", "price_type": "live_listing", "source_id": "SRC-0056", "source_domain": "transitownewilliamsville.com",
        "source_url": "https://www.transitownewilliamsville.com/inventory/used-2024-kia-telluride-sx-prestige-x-pro-awd-sport-utility-5xyp5dgc0rg414720/", "listing_title": "2024 Kia Telluride SX Prestige X-Pro AWD", "seller_name": "Transitowne Kia", "seller_location": "Williamsville, New York", "stock_number": "K5991P", "vin": "5XYP5DGC0RG414720",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "sold", "model_year": 2024, "make": "Kia", "model": "Telluride", "trim": "SX Prestige X-Pro", "drivetrain": "AWD", "powertrain": "gas", "mileage": 31250, "listed_price": 42561,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "seller_market", "amount": -500, "reason": "Normalize nonlocal dealer ask toward national delivery market."}], "notes": "Dealer page redirected on recheck; marked sold/expired."
    },
    {
        "price_record_id": "PRC-0007", "vehicle_id": "VEH-HONDA-PILOT-2024-ELITE-AWD", "price_type": "live_listing", "source_id": "SRC-0057", "source_domain": "carmax.com",
        "source_url": "https://www.carmax.com/car/28666081", "listing_title": "2024 Honda Pilot Elite AWD", "seller_name": "CarMax", "seller_location": "United States / delivery market", "stock_number": "28666081", "vin": "5FNYG1H85RB029703",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "unknown", "model_year": 2024, "make": "Honda", "model": "Pilot", "trim": "Elite", "drivetrain": "AWD", "powertrain": "gas", "mileage": 42100, "listed_price": 41998,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "mileage", "amount": 1000, "reason": "Normalize toward mid-band mileage."}], "notes": "Direct listing URL retained."
    },
    {
        "price_record_id": "PRC-0008", "vehicle_id": "VEH-HONDA-PILOT-2024-ELITE-AWD", "price_type": "live_listing", "source_id": "SRC-0058", "source_domain": "carvana.com",
        "source_url": "https://www.carvana.com/vehicle/4558078", "listing_title": "2024 Honda Pilot Elite AWD", "seller_name": "Carvana", "seller_location": "Online delivery", "stock_number": None, "vin": None,
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "reserved", "model_year": 2024, "make": "Honda", "model": "Pilot", "trim": "Elite", "drivetrain": "AWD", "powertrain": "gas", "mileage": 12705, "listed_price": 47590,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "mileage", "amount": -2500, "reason": "Low-mile premium normalized toward expected 25k-35k purchase mileage."}], "notes": "Purchase in progress at retrieval."
    },
    {
        "price_record_id": "PRC-0009", "vehicle_id": "VEH-HONDA-PILOT-2024-ELITE-AWD", "price_type": "live_listing", "source_id": "SRC-0059", "source_domain": "communityhondacars.com",
        "source_url": "https://www.communityhondacars.com/search/used-honda-pilot-cedar-falls-ia/?cy=50614&md=133&tp=used", "listing_title": "2024 Honda Pilot Elite AWD inventory observation", "seller_name": "Community Honda", "seller_location": "Cedar Falls, Iowa", "stock_number": "H15203A", "vin": "5FNYG1H87RB041884",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "unknown", "model_year": 2024, "make": "Honda", "model": "Pilot", "trim": "Elite", "drivetrain": "AWD", "powertrain": "gas", "mileage": 17440, "listed_price": 47140,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "mileage", "amount": -2000, "reason": "Low-mile premium adjustment."}, {"type": "source_precision", "amount": 0, "reason": "Search result rather than stable detail page; lowers confidence."}], "notes": "Third comparable is a dealer inventory result, so price confidence is medium-low."
    },
    {
        "price_record_id": "PRC-0010", "vehicle_id": "VEH-FORD-EXPLORER-2024-PLATINUM-4WD", "price_type": "live_listing", "source_id": "SRC-0060", "source_domain": "carmax.com",
        "source_url": "https://www.carmax.com/car/29064605", "listing_title": "2024 Ford Explorer Platinum 4WD", "seller_name": "CarMax", "seller_location": "United States / delivery market", "stock_number": "29064605", "vin": "1FM5K8HC8RGA01264",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "unknown", "model_year": 2024, "make": "Ford", "model": "Explorer", "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas", "mileage": 15184, "listed_price": 44998,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "mileage", "amount": -2000, "reason": "Low-mile premium adjustment."}], "notes": "Direct listing URL retained."
    },
    {
        "price_record_id": "PRC-0011", "vehicle_id": "VEH-FORD-EXPLORER-2024-PLATINUM-4WD", "price_type": "live_listing", "source_id": "SRC-0061", "source_domain": "carvana.com",
        "source_url": "https://www.carvana.com/vehicle/4493520", "listing_title": "2024 Ford Explorer Platinum 4WD", "seller_name": "Carvana", "seller_location": "Online delivery", "stock_number": None, "vin": None,
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "available", "model_year": 2024, "make": "Ford", "model": "Explorer", "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas", "mileage": 34686, "listed_price": 40590,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [], "notes": "Available at retrieval."
    },
    {
        "price_record_id": "PRC-0012", "vehicle_id": "VEH-FORD-EXPLORER-2024-PLATINUM-4WD", "price_type": "certified_pre_owned", "source_id": "SRC-0062", "source_domain": "spitzerfordhartville.com",
        "source_url": "https://www.spitzerfordhartville.com/inventory/certified-used-2024-ford-explorer-platinum-4wd-4d-sport-utility-1fm5k8hc3rga84909/", "listing_title": "Certified 2024 Ford Explorer Platinum 4WD", "seller_name": "Spitzer Ford Hartville", "seller_location": "Hartville, Ohio", "stock_number": "18299HV", "vin": "1FM5K8HC3RGA84909",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "sold", "model_year": 2024, "make": "Ford", "model": "Explorer", "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas", "mileage": 16761, "listed_price": 43616,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "certification_and_mileage", "amount": -1500, "reason": "CPO and low-mile premium adjustment."}], "notes": "Dealer page redirected on recheck."
    },
    {
        "price_record_id": "PRC-0013", "vehicle_id": "VEH-NISSAN-PATHFINDER-2024-PLATINUM-4WD-POSTNOV23", "price_type": "live_listing", "source_id": "SRC-0063", "source_domain": "carmax.com",
        "source_url": "https://www.carmax.com/car/70112041", "listing_title": "2024 Nissan Pathfinder Platinum 4WD", "seller_name": "CarMax", "seller_location": "United States / delivery market", "stock_number": "70112041", "vin": "5N1DR3DJXRC280416",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "unknown", "model_year": 2024, "make": "Nissan", "model": "Pathfinder", "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas", "mileage": 13557, "listed_price": 36998,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "mileage", "amount": -1000, "reason": "Low-mile premium adjustment."}], "notes": "Build date not provided; eligibility requires certification-label verification."
    },
    {
        "price_record_id": "PRC-0014", "vehicle_id": "VEH-NISSAN-PATHFINDER-2024-PLATINUM-4WD-POSTNOV23", "price_type": "live_listing", "source_id": "SRC-0064", "source_domain": "carmax.com",
        "source_url": "https://www.carmax.com/car/28886620", "listing_title": "2024 Nissan Pathfinder Platinum 4WD", "seller_name": "CarMax", "seller_location": "United States / delivery market", "stock_number": "28886620", "vin": "5N1DR3DJ1RC239950",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "unknown", "model_year": 2024, "make": "Nissan", "model": "Pathfinder", "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas", "mileage": 35267, "listed_price": 35998,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [], "notes": "Build date not provided; eligibility requires verification."
    },
    {
        "price_record_id": "PRC-0015", "vehicle_id": "VEH-NISSAN-PATHFINDER-2024-PLATINUM-4WD-POSTNOV23", "price_type": "certified_pre_owned", "source_id": "SRC-0065", "source_domain": "nissanusa.com",
        "source_url": "https://www.nissanusa.com/shopping-tools/search-inventory/certified-pre-owned/vehicle-details/5N1DR3DK4RC234041", "listing_title": "Certified 2024 Nissan Pathfinder Platinum 4WD", "seller_name": "Nissan Certified seller", "seller_location": "United States", "stock_number": None, "vin": "5N1DR3DK4RC234041",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "available", "model_year": 2024, "make": "Nissan", "model": "Pathfinder", "trim": "Platinum", "drivetrain": "4WD", "powertrain": "gas", "mileage": None, "listed_price": 37500,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "missing_mileage", "amount": 0, "reason": "Mileage unavailable; lowers confidence."}], "notes": "Exact build date and mileage unresolved."
    },
    {
        "price_record_id": "PRC-0016", "vehicle_id": "VEH-KIA-EV9-2024-LAND-AWD-POSTJAN24", "price_type": "certified_pre_owned", "source_id": "SRC-0066", "source_domain": "kiacerritos.com",
        "source_url": "https://www.kiacerritos.com/inventory/certified-used-2024-kia-ev9-land-awd-4d-sport-utility-kndadfs54r6029435/", "listing_title": "Certified 2024 Kia EV9 Land AWD", "seller_name": "Kia of Cerritos", "seller_location": "Cerritos, California", "stock_number": "5P462", "vin": "KNDADFS54R6029435",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "available", "model_year": 2024, "make": "Kia", "model": "EV9", "trim": "Land", "drivetrain": "AWD", "powertrain": "electric", "mileage": 14956, "listed_price": 46112,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [], "notes": "Active direct CPO listing at retrieval; build date and campaign closure still require VIN-level confirmation."
    },
    {
        "price_record_id": "PRC-0017", "vehicle_id": "VEH-KIA-EV9-2024-LAND-AWD-POSTJAN24", "price_type": "live_listing", "source_id": "SRC-0067", "source_domain": "kiasantamonica.com",
        "source_url": "https://www.kiasantamonica.com/auto/preowned-2024-kia-ev9-land-near-los-angeles-ca/121571693/", "listing_title": "2024 Kia EV9 Land AWD", "seller_name": "Kia Santa Monica", "seller_location": "Santa Monica, California", "stock_number": "R6035478P", "vin": "KNDADFS58R6035478",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "sold", "model_year": 2024, "make": "Kia", "model": "EV9", "trim": "Land", "drivetrain": "AWD", "powertrain": "electric", "mileage": 17361, "listed_price": 44240,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [], "notes": "Sold/redirected comparable retained as low-range observation."
    },
    {
        "price_record_id": "PRC-0018", "vehicle_id": "VEH-KIA-EV9-2024-LAND-AWD-POSTJAN24", "price_type": "certified_pre_owned", "source_id": "SRC-0068", "source_domain": "towbinkia.com",
        "source_url": "https://www.towbinkia.com/inventory/certified-used-2024-kia-ev9-land-awd-4d-sport-utility-kndadfs53r6028891/", "listing_title": "Certified 2024 Kia EV9 Land AWD", "seller_name": "Towbin Kia", "seller_location": "Henderson, Nevada", "stock_number": "KHP028891", "vin": "KNDADFS53R6028891",
        "retrieved_at": "2026-08-24T00:00:00Z", "listing_status_at_retrieval": "sold", "model_year": 2024, "make": "Kia", "model": "EV9", "trim": "Land", "drivetrain": "AWD", "powertrain": "electric", "mileage": 18879, "listed_price": 48291,
        "destination_charge": None, "required_packages": [], "dealer_accessories": [], "dealer_markup": None, "dealer_discount": None, "conditional_discount": None, "verified_incentives": [], "estimated_taxes_and_fees": None, "estimated_out_the_door_price": None,
        "normalization_adjustments": [{"type": "certification", "amount": -1000, "reason": "CPO premium adjustment."}], "notes": "Sold/redirected comparable retained as high-range observation."
    },
]

ELIMINATION_RULES = {
    "VEH-VOLKSWAGEN-ATLAS-2024-SEL-PREMIUM-RLINE-4MOTION": ("row3_complete_latch", "fail", "IIHS maps both third-row seats as tether-only, not complete lower-anchor-plus-tether positions.", ["SRC-0007"]),
    "VEH-BUICK-ENCLAVE-2024-AVENIR-AWD": ("iihs_award", "fail", "No exact-year IIHS Top Safety Pick or Top Safety Pick+ award.", ["SRC-0011"]),
    "VEH-ACURA-MDX-2024-ADVANCE-SHAWD": ("nhtsa_overall", "fail", "Exact SH-AWD variant is not rated; configured unrated policy is conditional-not-pass.", ["SRC-0012"]),
    "VEH-LINCOLN-AVIATOR-2024-RESERVE-AWD": ("iihs_award", "fail", "No qualifying exact-year IIHS award.", ["SRC-0074"]),
    "VEH-GMC-ACADIA-2024-DENALI-AWD": ("iihs_award", "fail", "No qualifying exact-year IIHS award.", ["SRC-0075"]),
    "VEH-CHEVROLET-TRAVERSE-2024-Z71-AWD": ("iihs_award", "fail", "No qualifying exact-year IIHS award.", ["SRC-0076"]),
    "VEH-TOYOTA-GRAND-HIGHLANDER-2024-HYBRID-LIMITED-AWD": ("iihs_award", "fail", "No qualifying exact-year IIHS award under the frozen gate.", ["SRC-0077"]),
    "VEH-TOYOTA-HIGHLANDER-2024-HYBRID-PLATINUM-AWD": ("row3_complete_latch", "fail", "No complete lower-anchor-plus-tether position in row 3.", ["SRC-0078"]),
    "VEH-MAZDA-CX90-2024-PHEV-PREMIUMPLUS-AWD": ("cargo_behind_row3", "fail", "Published volume is below 16 cubic feet.", ["SRC-0079", "SRC-0087"]),
    "VEH-VOLVO-XC90-2024-RECHARGE-PLUS-AWD": ("cargo_behind_row3", "fail", "Published volume is approximately 15.8 cubic feet, below threshold.", ["SRC-0080", "SRC-0087"]),
    "VEH-AUDI-Q7-2024-PRESTIGE-QUATTRO": ("cargo_behind_row3", "fail", "Published volume is below 16 cubic feet.", ["SRC-0081", "SRC-0087"]),
    "VEH-INFINITI-QX60-2024-AUTOGRAPH-AWD": ("cargo_behind_row3", "fail", "Published volume is below 16 cubic feet.", ["SRC-0082", "SRC-0087"]),
    "VEH-HYUNDAI-SANTAFE-2024-CALLIGRAPHY-AWD": ("cargo_behind_row3", "fail", "Published volume is below 16 cubic feet.", ["SRC-0083", "SRC-0087"]),
    "VEH-MITSUBISHI-OUTLANDER-2024-PHEV-SEL-PREMIUM-AWD": ("cargo_behind_row3", "fail", "Third-row cargo and usability do not meet the configured threshold.", ["SRC-0084", "SRC-0087"]),
    "VEH-JEEP-GRANDCHEROKEEL-2024-SUMMIT-4X4": ("iihs_award", "fail", "No qualifying exact-year IIHS award.", ["SRC-0085"]),
    "VEH-RIVIAN-R1S-2024-DUAL-AWD": ("nhtsa_overall", "fail", "Exact AWD NHTSA overall score is not available; unrated is not a pass.", ["SRC-0086"]),
}

RESERVE_SCREEN = {
    "VEH-HYUNDAI-PALISADE-2024-CALLIGRAPHY-AWD": {
        "overall": "conditional_pass", "note": "Preliminary hard filters pass, but Poor updated moderate-overlap result and sibling overlap reduced deep-research priority.", "source_ids": ["SRC-0008"]
    },
    "VEH-SUBARU-ASCENT-2024-TOURING-AWD": {
        "overall": "pass", "note": "Preliminary hard filters pass; retained as a live reserve.", "source_ids": ["SRC-0009"]
    },
    "VEH-CHRYSLER-PACIFICA-2024-LIMITED-AWD": {
        "overall": "conditional_pass", "note": "Preliminary hard filters pass; exact AWD price and row-3 LATCH/VIN verification required before promotion.", "source_ids": ["SRC-0010"]
    },
}
